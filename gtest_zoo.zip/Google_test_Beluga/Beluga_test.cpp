#include "Beluga.h"
#include<gtest/gtest.h>

class BelugaTest : public ::testing::Test {
  protected:
    BelugaTest(){}
};

TEST(BelugaTest, Render) {
  Beluga beluga(50,0,0);
  ASSERT_EQ('B', beluga.Render());
}

TEST(BelugaTest, GetBerat) {
  Beluga beluga(50,0,0);
  ASSERT_EQ(50, beluga.GetBerat());
}

TEST(BelugaTest, GetAbsis) {
  Beluga beluga(50,0,0);
  ASSERT_EQ(0, beluga.GetKoordinat().GetAbsis());
}

TEST(BelugaTest, GetOrdinat) {
  Beluga beluga(50,0,0);
  ASSERT_EQ(0, beluga.GetKoordinat().GetOrdinat());
}

//TEST(BelugaTest, IsLivable) {
//  Beluga beluga(50,0,0);
//  ASSERT_EQ(50, beluga.GetKoordinat());
//}

TEST(BelugaTest, IsLandAnimal) {
  Beluga beluga(50,0,0);
  ASSERT_EQ(false, beluga.IsLandAnimal());
}

TEST(BelugaTest, IsWaterAnimal) {
  Beluga beluga(50,0,0);
  ASSERT_EQ(true, beluga.IsWaterAnimal());
}

TEST(BelugaTest, IsAirAnimal) {
  Beluga beluga(50,0,0);
  ASSERT_EQ(false, beluga.IsAirAnimal());
}

TEST(BelugaTest, IsJinak) {
  Beluga beluga(50,0,0);
  ASSERT_EQ(true, beluga.IsJinak());
}

TEST(BelugaTest, GetMakanan) {
  Beluga beluga(50,0,0);
  ASSERT_EQ(2, beluga.GetMakanan());
}
