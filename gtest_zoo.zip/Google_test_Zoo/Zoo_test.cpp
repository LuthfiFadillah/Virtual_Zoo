#include "Zoo.h"
#include<gtest/gtest.h>

class ZooTest : public ::testing::Test {
  protected:
    ZooTest(){}
};

TEST(ZooTest, IsInteractable) {
  Zoo zoo;
  Indices i1(4,3);
  Indices i2(4,0);
  ASSERT_EQ(true, zoo.IsInteractable(i2,zoo.GetKandang()[0]));
  ASSERT_EQ(false, zoo.IsInteractable(i1,zoo.GetKandang()[0]));
}
