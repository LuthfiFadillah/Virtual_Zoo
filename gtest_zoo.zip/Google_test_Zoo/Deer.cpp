#include "Artiodactyls.h"
#include "Animals.h"
#include "Deer.h"
#include "Indices.h"
#include <iostream>
using namespace std;

	//ctor with param
	Deer::Deer(int bb,int x, int y): Artiodactyls(true,x,y){
		SetBerat(bb);
	}

	void Deer::Interact(){
		cout<< "Do you know where is santa house??" << endl;
	}

	char Deer::Render() {
		return 'D';
	}
