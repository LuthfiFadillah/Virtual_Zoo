#include "Cetacea.h"
#include "Animals.h"
#include "Orca.h"
#include "Indices.h"
#include <iostream>
using namespace std;

	//ctor with param
	Orca::Orca(int bb, int x, int y): Cetacea(false, x,y) {
		SetBerat(bb);
	}
	
	//polymorphism interaksi
	void Orca::Interact(){
		cout << "*WWUSHHHO" << endl;
		}

	char Orca::Render() {
		return '$';
	}
