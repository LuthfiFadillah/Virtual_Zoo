#include "Lemur.h"
#include "Primates.h"
#include "Animals.h"
#include "Indices.h"
#include <iostream>
using namespace std;	

	//ctor with param
	Lemur::Lemur(int bb, int x, int y) : Primates (true,x,y){
		SetBerat(bb);
	}
	//destructor
	//polymorphism interaksi
	void Lemur::Interact(){
		cout<<"*chirps*"<<endl;
	}

	char Lemur::Render() {
		return 'E';
	}
