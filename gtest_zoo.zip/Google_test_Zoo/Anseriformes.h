#ifndef ANSERIFORMES_H
#define ANSERIFORMES_H
#include "Animals.h"
#include "Indices.h"
class Anseriformes: public Animals{
//method
public:
	//ctor
	Anseriformes(bool kejinakan, int x, int y);
	
};
#endif
