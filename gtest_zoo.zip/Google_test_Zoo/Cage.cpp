#include "Cage.h"
#include "Animals.h"
//#include "Habitat.h"
#include "Indices.h"
#include <iostream>
using namespace std;

	Cage::Cage() {
		
	}
	
	Cage::Cage(Indices *I,int Neff){
		wilayah = new Indices[Neff];
		for (int i=0; i< Neff; i++) {
			wilayah[i] = I[i];
		}
		luas = Neff;
		banyak_hewan = 0;
		data_animals = new Animals*[(Neff*3)/10];
	}
	
	Cage::~Cage(){
		//delete [] wilayah;
		//delete [] data_animals;
		luas =0;
	}

    Cage& Cage::operator= (const Cage& C){
        int i;
        luas = C.luas;
        banyak_hewan = C.banyak_hewan;
        if (this != &C) {
            //delete [] wilayah;
            wilayah = new Indices[luas];
            for (i=0; i<luas; i++) {
                wilayah[i] = C.wilayah[i];
            }
            //delete [] data_animals;
            data_animals = new Animals* [banyak_hewan];
            for (i=0; i<banyak_hewan; i++) {
                data_animals[i] = C.data_animals[i];
            }
        }
        return *this;
    }

	bool Cage::IsHostOf(Indices I){
		bool ketemu = false;
		int i=0;
		
		while ((i<luas) && (!(ketemu))) {
			ketemu = (I.IsEqual(wilayah[i]));
			i++; 
		}
		
		return ketemu;
	}
	
	bool Cage::Spacious() {
		return (banyak_hewan <= (luas*3)/10) ;
	}
	
	void Cage::AddAnimal(Animals* A){
		Indices I(A->GetKoordinat().GetAbsis(), A->GetKoordinat().GetOrdinat());
		if (IsHostOf(I)) {
			if (Spacious()) {
				if (!(A->IsJinak())) {
					if (banyak_hewan == 0) {
						data_animals[banyak_hewan] = A;
						banyak_hewan++;
					} else {
						if (A->Render() == data_animals[0]->Render()) {
							data_animals[banyak_hewan] = A;
							banyak_hewan++;
						}
					}
				} else {
					data_animals[banyak_hewan] = A;
					banyak_hewan++;
				}
			} else {
				cout<< "Penuh couyyy" << endl;
			}
		}
	}
	
	void Cage::Inter()  {
		for (int i=0; i<banyak_hewan; i++) {
			data_animals[i]->Interact();
		}
	}
	
	bool Cage::IsCageOf(Animals* A) {
		int i = 0;
		bool ketemu = (data_animals[i] == A);
		while (!ketemu && (i<banyak_hewan)) {
			ketemu = (data_animals[i] == A);
			i++;
		}
        return ketemu;
	}

Animals ** Cage::GetAnimals(){
    return data_animals;
}
int Cage::GetLuas(){
    return luas;
}
int Cage::GetBanyakHewan(){
    return banyak_hewan;
}
