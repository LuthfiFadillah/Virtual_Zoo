#include "WaterHabitat.h"
#include <gtest/gtest.h>

class WaterHabitatTest : public ::testing::Test {
  protected:
    WaterHabitatTest(){}
};

TEST(WaterHabitatTest, Render) {
  Indices I(0,0);
  WaterHabitat water_habitat(I);
  ASSERT_EQ('w', water_habitat.Render());
}

TEST(WaterHabitatTest, IsWater) {
  Indices I(0,0);
  WaterHabitat water_habitat(I);
  ASSERT_EQ(true, water_habitat.IsWater());
}

TEST(WaterHabitatTest, IsLand) {
  Indices I(0,0);
  WaterHabitat water_habitat(I);
  ASSERT_EQ(false, water_habitat.IsLand());
}

TEST(WaterHabitatTest, IsAir) {
  Indices I(0,0);
  WaterHabitat water_habitat(I);
  ASSERT_EQ(false, water_habitat.IsAir());
}

TEST(WaterHabitatTest, GetKoordinat) {
  Indices I(0,0);
  WaterHabitat water_habitat(I);
  ASSERT_EQ(0, water_habitat.GetKoordinat().GetAbsis());
  ASSERT_EQ(0, water_habitat.GetKoordinat().GetOrdinat());
}

TEST(WaterHabitatTest, IsHabitat) {
  Indices I(0,0);
  WaterHabitat water_habitat(I);
  ASSERT_EQ(true, water_habitat.IsHabitat());
}

TEST(WaterHabitatTest, IsFacility) {
  Indices I(0,0);
  WaterHabitat water_habitat(I);
  ASSERT_EQ(false, water_habitat.IsFacility());
}

TEST(WaterHabitatTest, GetCode) {
  Indices I(0,0);
  WaterHabitat water_habitat(I);
  ASSERT_EQ('w', water_habitat.GetCode());
}
