#include "Duck.h"
#include "Indices.h"
#include <iostream>
using namespace std;


	//ctor with param
	Duck::Duck(int bb,int x, int y) :Anseriformes(true,x,y) {
		SetBerat(bb);
	}
	
	//polymorphism interaksi
	void Duck::Interact() {
		cout << "Qwekk Qwekk\n";
	}

	char Duck::Render() {
		return 'U';
	}
