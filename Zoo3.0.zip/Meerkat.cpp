#include "Meerkat.h"
#include "Carnivora.h"
#include "Animals.h"
#include "Indices.h"
#include <iostream>
using namespace std;

//class Meerkat: public Carnivora {
//method

	//ctor with param
	Meerkat::Meerkat(int bb, int x, int y) : Carnivora(true,x,y) {
		SetBerat(bb);
	}
	//destructor
	//polymorphism interaksi
	void Meerkat::Interact() {
		cout << "*suddenly standing*" << endl;
	}
	char Meerkat::Render() {
		return 'M';
	}
