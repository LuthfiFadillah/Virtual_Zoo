#include "big_horn_sheep.h"
#include <iostream>
using namespace std;
  /** @brief Constructor dari Big Horn Sheep
    * Menghidupkan hewan Big Horn Sheep
    *
    * @param x integer adalah letak absis Big Horn Sheep yang dihidupkan
    * @param y integer adalah letak ordinat Big Horn Sheep yang dihidupkan
    * @param bb integer adalah berat badan Big Horn Sheep yang dihidupkan
    */
  BigHornSheep::BigHornSheep(int bb, int x, int y) :
                             Artiodactyls(false, x , y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Big Horn Sheep
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Big Horn Sheep ke layar
    */
  void BigHornSheep::Interact() {
    cout << "Mbeeekkkk" << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Big Horn Sheep
    * Character ini nantinya yang siap dicetak ke layar
    */
  char BigHornSheep::Render() {
    return 'S';
  }