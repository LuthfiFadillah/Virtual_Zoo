#ifndef GORILLA_H
#define GORILLA_H
#include "primates.h"
class Gorilla : public Primates {
public:
  /** @brief Constructor dari Gorilla
    * Menghidupkan hewan Gorilla
    *
    * @param x integer adalah letak absis Gorilla yang dihidupkan
    * @param y integer adalah letak ordinat Gorilla yang dihidupkan
    * @param bb integer adalah berat badan Gorilla yang dihidupkan
    */
  Gorilla(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Gorilla
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Gorilla ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Gorilla
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif