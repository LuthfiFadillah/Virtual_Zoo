#ifndef CHAMELEON_H
#define CHAMELEON_H
#include "squamata.h"

class Chameleon : public Squamata {
public:
  /** @brief Constructor dari Chameleon
    * Menghidupkan hewan Chameleon
    *
    * @param x integer adalah letak absis Chameleon yang dihidupkan
    * @param y integer adalah letak ordinat Chameleon yang dihidupkan
    * @param bb integer adalah berat badan Chameleon yang dihidupkan
    */
  Chameleon(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Chameleon
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Chameleon ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Chameleon
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif