#include "selacimorpha.h"
  /** @brief Constructor dari Selacimorpha
    * Menghidupkan hewan Ordo Selacimorpha
    *
    * @param x integer adalah letak absis Selacimorpha yang dihidupkan
    * @param y integer adalah letak ordinat Selacimorpha yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Selacimorpha::Selacimorpha(bool kejinakan, int x, int y) :
                             Animals(2, false, true, false, kejinakan, x, y) {}