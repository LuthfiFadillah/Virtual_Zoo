#ifndef GIRAFFE_H
#define GIRAFFE_H
#include "artiodactyls.h"
class Giraffe : public Artiodactyls {
public:
  /** @brief Constructor dari Giraffe
    * Menghidupkan hewan giraffe
    *
    * @param x integer adalah letak absis giraffe yang dihidupkan
    * @param y integer adalah letak ordinat giraffe yang dihidupkan
    * @param bb integer adalah berat badan giraffe yang dihidupkan
    */
  Giraffe(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Giraffe
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi giraffe ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Giraffe
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif