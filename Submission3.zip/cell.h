#ifndef CELL_H
#define CELL_H
#include "renderable.h"
#include "indices.h"
class Cell : public Renderable {
public:
  /** @brief Constructor dari Cell
    * Menghidupkan cell
    *
    * @param I Indices adalah alamat dimana cell dihidupkan
    * @param Type integer adalah kode dari cell dimana 0=Habitat, 1=Facility
    * @param Code character adalah suatu huruf untuk merepresentasikan cell di layar.
    */
  Cell(Indices ind, int t, char c);
  /** @brief Destructor dari Cell
    * Menghilangkan alokasi memori cell
    */
  ~Cell();
  /** @brief Mengembalikan nilai character render dari objek Cell
    * Character ini nantinya yang siap di Print ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai Indices dimana cell berada
    */
  Indices GetKoordinat();
  /** @brief Mengembalikan nilai boolean apakah cell adalah habitat
    */
  bool IsHabitat();
  /** @brief Mengembalikan nilai boolean apakah cell adalah fasilitas
    */
  bool IsFacility();
  /** @brief Mengembalikan nilai char code yang adalah atribut cell
    */
  char GetCode();
protected:
  /** @brief Attribut Koordinat yang adalah Indices letak cell
    */
  Indices koordinat;
  /** @brief Attribut type yang adalah type dari Cell
    */
  const int type;
  /** @brief Attribut code yang adalah code dari Cell
    */
  const char code;
};
#endif