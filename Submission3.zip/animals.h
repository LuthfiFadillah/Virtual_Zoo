#ifndef ANIMALS_H
#define ANIMALS_H
#include "renderable.h"
#include "land_habitat.h"
#include "water_habitat.h"
#include "air_habitat.h"
#include "cell.h"
#include "indices.h"
class Animals: public Renderable {
public:
  /** @brief Constructor dari Hewan
    * Menghidupkan hewan
    *
    * @param makan integer adalah kode jenis makanan hewan dimana Herbivore=0, Omnivore=1, Carnivore=2
    * @param land bool menyatakan apakah hewan dapat hidup di darat
    * @param water bool menyatakan apakah hewan dapat hidup di air
    * @param air bool menyatakan apakah hewan dapat hidup di udara
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    * @param x integer adalah letak absis hewan yang dihidupk
    * @param y integer adalah letak ordinat hewan yang dihidupkan
    */
  Animals(int makan, bool land, bool water, bool air,
	        bool kejinakan, int x, int y);
  /** @brief Destructor dari Animals
    * Menghilangkan alokasi memori Animals
    */
  ~Animals();
  /** @brief prosedur virtual interact dari hewan
    * I.S hewan telah dihidupkan
    * F.S Mencetak suara hewan kelayar
    * Diimplementasikan pada masing22 class real tiap spesies hewan
    */
  virtual void Interact() = 0;
  /** @brief GetBerat dari hewan
    * Mengembalikan nilai integer berat dari hewan
    */
  int GetBerat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief GetKoordinat dari hewan
    * Mengembalikan nilai Indices ordinat hewan
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetKoordinat  dari hewan
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai Koordinat dari hewan
    *
    * @param x integer menyatakan absis yang ingin di set
    * @param y integer menyatakan ordinat yang ingin di set
    */
	void SetKoordinat(int x, int y);
  /** @brief Mengembalikan nilai boolean apakah hewan dapat hidup di Land
    */
	bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah hewan dapat hidup di Water
    */
	bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah hewan dapat hidup di Air
    */ 
	bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah hewan jinak
    */
	bool IsJinak();
  /** @brief Mengembalikan nilai boolean apakah hewan dapat tinggal pada Cell C
    * 
    * @param C Cell yang dicek untuk hewan dapat tinggal atau tidak
    */
  bool IsLivable(Cell c);
  /** @brief Mengembalikan nilai integer keterangan makanan hewan
    */
	int GetMakanan();
protected:
  /** @brief Atribut berat_badan  menyatakan berapa berat hewan tersebut
    */
	int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana hewan berada
    */
	Indices koordinat;
  /** @brief Atribut makanan adalah keterangan klasifikasi hewan berdasarkan makanan dimana Herbivore=0, Omnivore=1, Carnivore=2
    */
	const int makanan;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah hewan tinggal di darat
    */
	const bool land_animal;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah hewan tinggal di air
    */
	const bool water_animal;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah hewan tinggal di udara
    */
	const bool air_animal;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya hewan
    */
	const bool jinak;
};
#endif