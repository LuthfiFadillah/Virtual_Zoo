#include "casuariformes.h"

  /** @brief Constructor dari Casuariformes
    * Menghidupkan hewan Ordo Casuariformes
    *
    * @param x integer adalah letak absis Casuariformes yang dihidupkan
    * @param y integer adalah letak ordinat Casuariformes yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Casuariformes::Casuariformes(bool kejinakan, int x, int y) :
	                             Animals(1, true, false, false,
	                             kejinakan, x, y) {}