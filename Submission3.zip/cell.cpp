#include "cell.h"

  /** @brief Constructor dari Cell
    * Menghidupkan cell
    *
    * @param I Indices adalah alamat dimana cell dihidupkan
    * @param Type integer adalah kode dari cell dimana 0=Habitat, 1=Facility
    * @param Code character adalah suatu huruf untuk merepresentasikan cell di layar.
    */
  Cell::Cell(Indices ind, int t, char c) :
             Renderable(0), type(t), code(c) { koordinat = ind; }
  /** @brief Destructor dari Cell
    * Menghilangkan alokasi memori cell
    */
  Cell::~Cell() {

  }
  /** @brief Mengembalikan nilai character render dari objek Cell
    * Character ini nantinya yang siap di Print ke layar
    */
  char Cell::Render() {
  	return '.';
  }
  /** @brief Mengembalikan nilai Indices dimana cell berada
    */
  Indices Cell::GetKoordinat() {
  	return koordinat;
  }
  /** @brief Mengembalikan nilai boolean apakah cell adalah habitat
    */
  bool Cell::IsHabitat() {
  	return (type == 0);
  }
  /** @brief Mengembalikan nilai boolean apakah cell adalah fasilitas
    */
  bool Cell::IsFacility() {
  	return (type == 1);
  }
  /** @brief Mengembalikan nilai char code yang adalah atribut cell
    */
  char Cell::GetCode() {
  	return code;
  }