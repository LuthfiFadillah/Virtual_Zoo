#ifndef FACILITY_H
#define FACILITY_H
#include "cell.h"
class Facility : public Cell {
public:
  /** @brief Constructor dari Facility
    * Menghidupkan fasilitas
    *
    * @param I Indices adalah alamat dimana fasilitas dihidupkan
    * @param type integer adalah kode dari fasilitas dimana 0=Road, 1=Park, 2=Restaurant
    * @param code character adalah suatu huruf untuk merepresentasikan fasilitas di layar.
    */
  Facility(Indices ind, int type, char code);
  /** @brief Mengembalikan nilai boolean apakah fasilitas adalah road
    */
  bool IsRoad();
  /** @brief Mengembalikan nilai boolean apakah fasilitas adalah park
    */
  bool IsPark();
  /** @brief Mengembalikan nilai boolean apakah fasilitas adalah restaurant
    */
  bool IsRestaurant();
protected:
  /** @brief Attribut Ftype yang adalah type dari fasilitas
    */
  const int fType;
};
#endif