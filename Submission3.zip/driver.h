#ifndef DRIVER_H
#define DRIVER_h
#include "zoo.h"

class Driver{
public:
  /** @brief Menampilkan MainMenu
    */
  void MainMenu();
  /** @brief Menampilkan Virtual Zoo
    */
  void DisplayVirtualZoo(int x1, int y1, int x2, int y2);
  /** @brief Melakukan tour pada virtual zoo
    */
  void TourVirtualZoo();
  /** @brief Menampilkan jumlah makanan
    * yang dibutuhkan di kebun binatang dalam satu hari
    */
  void DisplayMakanan();
private:
  Zoo Z;
};

#endif