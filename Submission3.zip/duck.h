#ifndef DUCK_H
#define DUCK_H
#include "anseriformes.h"
class Duck : public Anseriformes {
public:
  /** @brief Constructor dari Duck
    * Menghidupkan hewan Duck
    *
    * @param x integer adalah letak absis Duck yang dihidupkan
    * @param y integer adalah letak ordinat Duck yang dihidupkan
    * @param bb integer adalah berat badan Duck yang dihidupkan
    */
  Duck(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Duck
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Duck ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Duck
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif