#include "meerkat.h"
#include <iostream>
using namespace std;

  /** @brief Constructor dari Meerkat
    * Menghidupkan hewan Meerkat
    *
    * @param x integer adalah letak absis Meerkat yang dihidupkan
    * @param y integer adalah letak ordinat Meerkat yang dihidupkan
    * @param bb integer adalah berat badan Meerkat yang dihidupkan
    */
  Meerkat::Meerkat(int bb, int x, int y) : Carnivora(true, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Meerkat
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Meerkat ke layar
    */
  void Meerkat::Interact() {
    cout << "*suddenly standing*" << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Meerkat
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Meerkat::Render() {
    return 'M';
  }