#ifndef DOLPHIN_H
#define DOLPHIN_H
#include "cetacea.h"
class Dolphin : public Cetacea {
public:
  /** @brief Constructor dari Dolphin
    * Menghidupkan hewan Dolphin
    *
    * @param x integer adalah letak absis Dolphin yang dihidupkan
    * @param y integer adalah letak ordinat Dolphin yang dihidupkan
    * @param bb integer adalah berat badan Dolphin yang dihidupkan
    */
  Dolphin(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Dolphin
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Dolphin ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Dolphin
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif