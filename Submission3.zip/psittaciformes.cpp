#include "psittaciformes.h"
  /** @brief Constructor dari Psittaciformes
    * Menghidupkan hewan Ordo Psittaciformes
    *
    * @param x integer adalah letak absis Psittaciformes yang dihidupkan
    * @param y integer adalah letak ordinat Psittaciformes yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Psittaciformes::Psittaciformes(bool kejinakan, int x, int y) : 
                                 Animals(1, false, false,
                                 true, kejinakan ,x,y) {

  }