#ifndef LANDHABITAT_H
#define LANDHABITAT_H
#include "habitat.h"
class LandHabitat : public Habitat {
public:
  /** @brief Constructor dari Land Habitat
    * Menghidupkan habitat darat
    *
    * @param I Indices adalah alamat dimana habitat dihidupkan
    */
  LandHabitat(Indices ind);
  /** @brief Mengembalikan nilai character kode dari objek Land Habitat
    * Character ini nantinya yang siap di Print ke layar
    */
  char Render();
};
#endif