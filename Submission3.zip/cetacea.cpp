#include "cetacea.h"
  /** @brief Constructor dari Cetacea
    * Menghidupkan hewan Ordo Cetacea
    *
    * @param x integer adalah letak absis Cetacea yang dihidupkan
    * @param y integer adalah letak ordinat Cetacea yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Cetacea::Cetacea (bool kejinakan, int x, int y) :
                   Animals(2, false, true, false, kejinakan, x, y) {}