#ifndef PARROTS_H
#define PARROTS_H
#include "psittaciformes.h"
class Parrots : public Psittaciformes {
public:
  /** @brief Constructor dari Parrots
    * Menghidupkan hewan Parrots
    *
    * @param x integer adalah letak absis Parrots yang dihidupkan
    * @param y integer adalah letak ordinat Parrots yang dihidupkan
    * @param bb integer adalah berat badan Parrots yang dihidupkan
    */
  Parrots(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Parrots
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Parrots ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Parrots
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif