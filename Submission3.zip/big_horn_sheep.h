#ifndef BIGHORNSHEEP_H
#define BIGHORNSHEEP_H
#include "artiodactyls.h"
class BigHornSheep : public Artiodactyls {
public:
  /** @brief Constructor dari Big Horn Sheep
    * Menghidupkan hewan Big Horn Sheep
    *
    * @param x integer adalah letak absis Big Horn Sheep yang dihidupkan
    * @param y integer adalah letak ordinat Big Horn Sheep yang dihidupkan
    * @param bb integer adalah berat badan Big Horn Sheep yang dihidupkan
    */
  BigHornSheep(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Big Horn Sheep
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Big Horn Sheep ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Big Horn Sheep
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif