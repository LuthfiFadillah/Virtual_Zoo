#include "water_habitat.h"
  /** @brief Constructor dari Water Habitat
    * Menghidupkan habitat air
    *
    * @param I Indices adalah alamat dimana habitat dihidupkan
    */
  WaterHabitat::WaterHabitat(Indices ind) : Habitat(ind, 1, 'w') {

  }
  /** @brief Mengembalikan nilai character kode dari objek Water Habitat
    * Character ini nantinya yang siap dicetak ke layar
    */
  char WaterHabitat::Render() {
    return 'w';
  }