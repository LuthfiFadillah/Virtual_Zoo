#include "road.h"
  /** @brief Constructor dari Road
    * Menghidupkan fasilitas jalan
    *
    * @param I Indices adalah alamat di mana fasilitas dihidupkan
    */
  Road::Road(Indices ind, int rtype) : Facility(ind, 0, 's'), rtype(rtype) {

  }
  /** @brief Mengembalikan nilai character kode dari objek Road
    * Character ini nantinya yang siap di Print ke layar
    */
  char Road::Render() {
    if (rtype == 0) {
      return '-';
    }
    else if (rtype == 1){
      return '+';
    }
    else if (rtype == 2){
      return '=';
    }
  }