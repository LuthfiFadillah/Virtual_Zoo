#include "driver.h"
#include <iostream>
using namespace std;

/** @brief Menampilkan MainMenu
  */
void Driver::MainMenu() {
  int x1, y1, x2, y2;
  int input;
  char n;
  bool keluar = false;
  while(!keluar){
    cout << "Selamat Datang Di Virtual Zoo" << endl << endl;
    cout << "Menu: " << endl;
   // cout << "1. Display Virtual Zoo (Partial)" << endl;
    cout << "2. Display Virtual Zoo (Full)" << endl;
  //  cout << "3. Tour di Virtual Zoo" << endl;
  //  cout << "4. Menampilkan Banyak Makanan" << endl;
    cout << "5. Keluar" << endl << endl;

    cout << "Input: "; cin >> input;
    switch (input){
      //case 1 :
        //  cout << "Masukkan koordinat atas-kiri "; cin >> x1 >> y1;
          //cout << "Masukkan koordinat bawah-kanan "; cin >> x2 >> y2;
          //cout << x1 << y1 << x2 << y2 << endl;
         // DisplayVirtualZoo(x1,y1,x2,y2);
         // break;
     // case 3 :
       //   TourVirtualZoo();
         // break;
      //case 4 :
        //  DisplayMakanan();
          //break;
      case 5 :
          cout << "See ya!" << endl;
          keluar = true;
          break;
      case 2 :
          
      //      Z.Move();
            Z.Print();
            cout << endl;
            cout << "Legend" << endl;
            cout << "B: Beluga" << "\t" << "S: Big Horn Sheep" << "\t" << "C: Cassowary" << "\t" << "H: Chameleon\t" << "T: Cheetah" << endl;
            cout << "O: Cockatoo" << "\t" << "D: Deer\t\t\t" << "N: Dolphin" << "\t" << "U: Duck\t\t" << "G: Giraffe" << endl;
            cout << "J: Gorilla\tK: Great White Shark\tE: Lemur\tI: Lion\t\tM: Meerkat" << endl;
            cout << "Y: Monkey\t$: Orca\t\t\tZ: Owl\t\tX: Parrots\tV: Python" << endl;
            cout << "Q: Swan\t\tF: Tarsier\t\t@: Wolf\t\tP: Park\t\tR: Restaurant" << endl;
            cout << "L: Land Habitat\tW: Water Habitat\tA: Air Habitat\t-: Road\t\t+: Entrance" << endl;
            cout << "=: Exit" << endl << endl;
            //cout << "Move? (y/n) "; cin >> n;
          break;
      default :
          cout << "Masukan salah" << endl;
    }
  }
}
/** @brief Menampilkan Virtual Zoo
  */
void Driver::DisplayVirtualZoo(int x1, int y1, int x2, int y2) {
  if ((x1 >= x2) || (y1 >= y2)) {
    cout << "Masukan koordinat salah" << endl;
  } else {
    for (int i = x1; i <= x2; i++) {
      for (int j = y1; j <= y2; j++) {
        cout << Z.GetPrint()[i][j] << " ";
      }
      cout << endl;
    }
    cout << endl;
    cout << "Legend" << endl;
    cout << "B: Beluga" << "\t" << "S: Big Horn Sheep" << "\t" << "C: Cassowary" << "\t" << "H: Chameleon\t" << "T: Cheetah" << endl;
    cout << "O: Cockatoo" << "\t" << "D: Deer\t\t\t" << "N: Dolphin" << "\t" << "U: Duck\t\t" << "G: Giraffe" << endl;
    cout << "J: Gorilla\tK: Great White Shark\tE: Lemur\tI: Lion\t\tM: Meerkat" << endl;
    cout << "Y: Monkey\t$: Orca\t\t\tZ: Owl\t\tX: Parrots\tV: Python" << endl;
    cout << "Q: Swan\t\tF: Tarsier\t\t@: Wolf\t\tP: Park\t\tR: Restaurant" << endl;
    cout << "L: Land Habitat\tW: Water Habitat\tA: Air Habitat\t-: Road\t\t+: Entrance" << endl;
    cout << "=: Exit" << endl << endl;
  }
}
/** @brief Melakukan tour pada virtual zoo
  */
void Driver::TourVirtualZoo() {
  Z.Tour();
}
/** @brief Menampilkan jumlah makanan
  * yang dibutuhkan di kebun binatang dalam satu hari
  */
/*void Driver::DisplayMakanan() {
  Z.HitungMakanan();
}*/
