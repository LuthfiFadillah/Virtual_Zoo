#ifndef DEER_H
#define DEER_H
#include "artiodactyls.h"

class Deer : public Artiodactyls {
public:
  /** @brief Constructor dari Deer
    * Menghidupkan hewan Deer
    *
    * @param x integer adalah letak absis Deer yang dihidupkan
    * @param y integer adalah letak ordinat Deer yang dihidupkan
    * @param bb integer adalah berat badan Deer yang dihidupkan
    */
  Deer(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Deer
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Deer ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Deer
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};

#endif