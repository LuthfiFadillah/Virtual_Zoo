#ifndef LION_H
#define LION_H
#include "carnivora.h"
class Lion : public Carnivora {
public:
  /** @brief Constructor dari Lion
    * Menghidupkan hewan Lion
    *
    * @param x integer adalah letak absis Lion yang dihidupkan
    * @param y integer adalah letak ordinat Lion yang dihidupkan
    * @param bb integer adalah berat badan Lion yang dihidupkan
    */
  Lion(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Lion
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Lion ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Lion
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif