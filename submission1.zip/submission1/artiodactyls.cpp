#include "artiodactyls.h"
  
  /** @brief Constructor dari Artiodactyls
    * Menghidupkan hewan Ordo Artiodactyls
    *
    * @param x integer adalah letak absis Artiodactyls yang dihidupkan
    * @param y integer adalah letak ordinat Artiodactyls yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Artiodactyls::Artiodactyls(bool kejinakan, int x, int y) :
                             Animals(0, true, false, false,kejinakan, x,y) {}