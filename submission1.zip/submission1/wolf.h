#ifndef WOLF_H
#define WOLF_H
#include "carnivora.h"
class Wolf : public Carnivora {
public:
  /** @brief Constructor dari Wolf
    * Menghidupkan hewan Wolf
    *
    * @param x integer adalah letak absis Wolf yang dihidupkan
    * @param y integer adalah letak ordinat Wolf yang dihidupkan
    * @param bb integer adalah berat badan Wolf yang dihidupkan
    */
  Wolf(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Wolf
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Wolf ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Wolf
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif