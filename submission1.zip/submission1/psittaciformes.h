#ifndef PSITTACIFORMES_H
#define PSITTACIFORMES_H
#include "animals.h"
class Psittaciformes : public Animals {
public:
  /** @brief Constructor dari Psittaciformes
    * Menghidupkan hewan Ordo Psittaciformes
    *
    * @param x integer adalah letak absis Psittaciformes yang dihidupkan
    * @param y integer adalah letak ordinat Psittaciformes yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Psittaciformes(bool kejinakan, int x, int y);
};
#endif