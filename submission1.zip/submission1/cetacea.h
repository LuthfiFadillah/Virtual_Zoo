#ifndef CETACEA_H
#define CETACEA_H
#include "animals.h"

class Cetacea : public Animals {
public:
  /** @brief Constructor dari Cetacea
    * Menghidupkan hewan Ordo Cetacea
    *
    * @param x integer adalah letak absis Cetacea yang dihidupkan
    * @param y integer adalah letak ordinat Cetacea yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Cetacea(bool kejinakan, int x, int y);
};
#endif