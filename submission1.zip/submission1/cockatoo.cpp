#include "psittaciformes.h"
#include "cockatoo.h"
#include <iostream>
using namespace std;
  
  /** @brief Constructor dari Cockatoo
    * Menghidupkan hewan Cockatoo
    *
    * @param x integer adalah letak absis Cockatoo yang dihidupkan
    * @param y integer adalah letak ordinat Cockatoo yang dihidupkan
    * @param bb integer adalah berat badan Cockatoo yang dihidupkan
    */
  Cockatoo::Cockatoo(int bb, int x, int y): Psittaciformes(true, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Cockatoo
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Cockatoo ke layar
    */
  void Cockatoo::Interact(){
    cout << "Cockatooo... Cockatooo..." << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Cockatoo
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Cockatoo::Render() {
    return 'O';
  }