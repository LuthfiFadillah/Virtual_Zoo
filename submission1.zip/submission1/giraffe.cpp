#include "giraffe.h"
#include <iostream>
using namespace std;

  /** @brief Constructor dari Giraffe
    * Menghidupkan hewan giraffe
    *
    * @param x integer adalah letak absis giraffe yang dihidupkan
    * @param y integer adalah letak ordinat giraffe yang dihidupkan
    * @param bb integer adalah berat badan giraffe yang dihidupkan
    */
  Giraffe::Giraffe(int bb, int x, int y): Artiodactyls(true, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Giraffe
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi giraffe ke layar
    */
  void Giraffe::Interact(){
    cout <<
    "where are u? i cant see you! are you down there?? please come up!"
    << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Giraffe
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Giraffe::Render() {
    return 'G';
  }