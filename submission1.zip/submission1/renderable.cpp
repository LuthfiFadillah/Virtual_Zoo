#include "renderable.h"
  /** @brief Constructor Renderable dengan jenisnya
    */
  Renderable::Renderable(int t) : ty(t) {}
  /** @brief Mengembalikan bool apakah suatu objek Renderable merupakan Cell
    */
  bool Renderable::IsCell() {
    return (ty == 0);
  }
  /** @brief Mengembalikan bool apakah suatu objek Renderable merupakan Animal
    */
  bool Renderable::IsAnimal() {
    return (ty == 1);
  }