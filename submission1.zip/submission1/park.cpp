#include "park.h"
  /** @brief Constructor dari Park
    * Menghidupkan fasilitas taman
    *
    * @param I Indices adalah alamat dimana fasilitas dihidupkan
    */
  Park::Park(Indices ind) : Facility(ind, 1, 'p') {

  }
  /** @brief Mengembalikan nilai character kode dari objek Park
  * Character ini nantinya yang siap dicetak ke layar
  */
  char Park::Render() {
    return 'P';
  }