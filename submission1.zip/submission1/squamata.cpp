#include "squamata.h"

  /** @brief Constructor dari Squamata
    * Menghidupkan hewan Ordo Squamata
    *
    * @param x integer adalah letak absis Squamata yang dihidupkan
    * @param y integer adalah letak ordinat Squamata yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */    
  Squamata::Squamata(bool kejinakan, int x, int y) :
                     Animals(2, true, false, false, kejinakan, x, y) {

  }