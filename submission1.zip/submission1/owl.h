#ifndef OWL_H
#define OWL_H
#include "strigiformes.h"
class Owl : public Strigiformes {
public:
  /** @brief Constructor dari Owl
    * Menghidupkan hewan Owl
    *
    * @param x integer adalah letak absis Owl yang dihidupkan
    * @param y integer adalah letak ordinat Owl yang dihidupkan
    * @param bb integer adalah berat badan Owl yang dihidupkan
    */
  Owl(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Owl
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Owl ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Owl
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif