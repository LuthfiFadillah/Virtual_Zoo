#include "cheetah.h"
#include <iostream>
using namespace std;
  
  /** @brief Constructor dari Cheetah
    * Menghidupkan hewan Cheetah
    *
    * @param x integer adalah letak absis Cheetah yang dihidupkan
    * @param y integer adalah letak ordinat Cheetah yang dihidupkan
    * @param bb integer adalah berat badan Cheetah yang dihidupkan
    */
  Cheetah::Cheetah(int bb, int x, int y) : Carnivora(false, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Cheetah
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Cheetah ke layar
    */
  void Cheetah::Interact() {
    cout << "*run fast*" << endl;
  } 
  /** @brief Mengembalikan nilai character kode dari objek Cheetah
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Cheetah::Render() {
    return 'T';
  }