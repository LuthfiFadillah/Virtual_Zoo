//file: Zoo.h
#ifndef ZOO_H
#define ZOO_H
#include "Cell.h"
#include "Cage.h"

class Zoo {
public:
	Zoo();
	~Zoo();
    void Move();
    void Print();
    void Populate();

private:
	Cell* **Map;
	Cage *DaftarKandang;
	int Lebar;
	int Panjang;
	int BykKandang;
    char **ready_to_print;
	char **base_map;
	int DEFSIZE=20;
};

#endif
