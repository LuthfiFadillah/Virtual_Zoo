#include "wolf.h"
#include "carnivora.h"
#include "animals.h"
#include <iostream>
using namespace std;

//class Wolf: public Carnivora {
//method

	//ctor with param
	Wolf::Wolf(int bb, int x, int y): Carnivora(false, x, y) {
		SetBerat(bb);
	}
	//destructor
	//polymorphism interaksi
	void Wolf::Interact() {
		cout << "AUUUUUUU" << endl;
	}
	char Wolf::Render() {
		return '@';
	}
