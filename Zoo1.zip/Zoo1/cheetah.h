#ifndef CHEETAH_H
#define CHEETAH_H
#include "carnivora.h"
#include "animals.h"
#include "indices.h"
class Cheetah : public Carnivora {
public:
  Cheetah(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif