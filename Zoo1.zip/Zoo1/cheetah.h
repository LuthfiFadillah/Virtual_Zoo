#ifndef CHEETAH_H
#define CHEETAH_H
#include "carnivora.h"
#include "animals.h"
#include "indices.h"

class Cheetah:public Carnivora{
//method
public:
	//ctor with param
	Cheetah(int bb,int x, int y);
	//destructor
	//polymorphism interaksi
	void Interact();
	char Render();
};
#endif
