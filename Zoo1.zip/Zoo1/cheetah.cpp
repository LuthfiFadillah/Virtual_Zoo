#include "cheetah.h"
#include "carnivora.h"
#include "indices.h"
#include "animals.h"
#include <iostream>
using namespace std;
  Cheetah::Cheetah(int bb, int x, int y) : Carnivora(false, x, y) {
    SetBerat(bb);
  }
  void Cheetah::Interact() {
    cout << "*run fast*" << endl;
  } 
  char Cheetah::Render() {
    return 'T';
  }