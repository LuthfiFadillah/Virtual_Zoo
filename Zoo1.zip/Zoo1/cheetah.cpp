#include "cheetah.h"
#include "carnivora.h"
#include "indices.h"
#include "animals.h"
#include <iostream>
using namespace std;

//class Cheetah: public Carnivora {
//method

	//ctor with param
	Cheetah::Cheetah(int bb,int x, int y) : Carnivora(false,x,y) {
		SetBerat(bb);
	}
	//destructor
	//polymorphism interaksi
	void Cheetah::Interact() {
		cout << "*run fast*" << endl;
	}
	char Cheetah::Render() {
		return 'T';
	}
