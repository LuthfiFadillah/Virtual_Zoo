#ifndef PYTHON_H
#define PYTHON_H
#include "squamata.h"
#include "indices.h"
class Python: public Squamata{
//method
public:
	//ctor with param
	Python(int bb,int x, int y);
	//destructor
	//polymorphism interaksi
	void Interact();
	char Render();
};
#endif
