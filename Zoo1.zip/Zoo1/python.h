#ifndef PYTHON_H
#define PYTHON_H
#include "squamata.h"
#include "indices.h"
class Python : public Squamata {
public:
  Python(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif