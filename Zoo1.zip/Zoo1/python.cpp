#include "python.h"
#include <iostream>
#include "indices.h"
using namespace std;
  Python::Python(int bb, int x, int y) : Squamata(false, x, y) {
    SetBerat(bb);
  }
  void Python::Interact() {
    cout << "Ssshhh\n" << endl;
  }
  char Python::Render() {
    return 'V';
  }