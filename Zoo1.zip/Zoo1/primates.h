#ifndef PRIMATES_H
#define PRIMATES_H
#include "animals.h"
#include "indices.h"
class Primates: public Animals {
public:
  Primates(bool kejinakan, int x, int y);
};
#endif