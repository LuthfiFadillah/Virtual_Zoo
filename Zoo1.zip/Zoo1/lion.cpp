#include "lion.h"
#include "carnivora.h"
#include "animals.h"
#include "indices.h"
#include <iostream>
using namespace std;
  Lion::Lion(int bb, int x, int y) : Carnivora (false, x, y) {
    SetBerat(bb);
  }
  void Lion::Interact() {
    cout << "ROAR" << endl;
  }
  char Lion::Render() {
    return 'I';
  }