#include "lion.h"
#include "carnivora.h"
#include "animals.h"
#include "indices.h"
#include <iostream>
using namespace std;

//class Lion: public Carnivora {
//method

	//ctor with param
	Lion::Lion(int bb,int x, int y) : Carnivora (false,x,y) {
		SetBerat(bb);
	}
	//destructor
	//polymorphism interaksi
	void Lion::Interact() {
		cout << "ROAR" << endl;
	}
	char Lion::Render() {
		return 'I';
	}
