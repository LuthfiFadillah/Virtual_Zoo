#ifndef WATERHABITAT_H
#define WATERHABITAT_H
#include "cell.h"
#include "habitat.h"
#include "indices.h"
class WaterHabitat : public Habitat {
public:
  WaterHabitat(Indices ind);
  ~WaterHabitat();
  char Render();
};
#endif