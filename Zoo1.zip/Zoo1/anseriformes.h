#ifndef ANSERIFORMES_H
#define ANSERIFORMES_H
#include "animals.h"
#include "indices.h"
class Anseriformes : public Animals {
public:
  /**@brief ctor
	*@param kejinakan, absis, ordinat
	*/
  Anseriformes(bool kejinakan, int x, int y);
};
#endif