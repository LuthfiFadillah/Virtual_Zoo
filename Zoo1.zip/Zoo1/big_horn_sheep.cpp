#include "artiodactyls.h"
#include "animals.h"
#include "big_horn_sheep.h"
#include "indices.h"
#include <iostream>
using namespace std;
  /**@brief ctor
	*@param berat badan, absis, ordinat
	*/
  BigHornSheep::BigHornSheep(int bb, int x, int y) :
                             Artiodactyls(false, x , y) {
    SetBerat(bb);
  }
  /**@brief polymorphism interaksi		
    */
  void BigHornSheep::Interact() {
    cout << "Mbeeekkkk" << endl;
  }
  char BigHornSheep::Render() {
    return 'S';
  }