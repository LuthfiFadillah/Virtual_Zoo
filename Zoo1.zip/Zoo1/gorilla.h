#ifndef GORILLA_H
#define GORILLA_H
#include "primates.h"
#include "animals.h"
#include "iondices.h"

class Gorilla:public Primates{
//method	
public:
	//ctor with param
	Gorilla(int bb,int x, int y);
	//destructor
	//polymorphism interaksi
	void Interact();
	char Render();
	
};
#endif
