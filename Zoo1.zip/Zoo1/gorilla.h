#ifndef GORILLA_H
#define GORILLA_H
#include "primates.h"
#include "animals.h"
#include "indices.h"
class Gorilla : public Primates {
public:
  Gorilla(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif