#include "selacimorpha.h"
#include "animals.h"
#include "indices.h"
  Selacimorpha::Selacimorpha(bool kejinakan, int x, int y) :
                             Animals(2, false, true, false, kejinakan, x, y) {}