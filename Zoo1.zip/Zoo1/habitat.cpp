#include "cell.h"
#include "habitat.h"
#include "indices.h"
  Habitat::Habitat(Indices ind, int type, char code) :
                   Cell(ind, 0, code), hType(type) {}
  bool Habitat::IsLand(){ return hType == 0;}
  bool Habitat::IsWater(){ return hType == 1;}
  bool Habitat::IsAir(){ return hType == 2;}