//file Road.cpp
#include "cell.h"
#include "facility.h"
#include "road.h"
#include "indices.h"
#include <iostream>
using namespace std;

	//Road::Road(): Facility() {}
	Road::Road(Indices ind): Facility(ind, 0, 's') {}
	//Road::Road(Road& R): Facility(R.GetKoordinat()) {}
	Road::~Road() {}
	//Road& Road::operator= (Road& R) {}
	char Road::Render() {
		return '-';
	}
