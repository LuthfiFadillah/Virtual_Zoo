#include "cell.h"
#include "facility.h"
#include "road.h"
#include "indices.h"
#include <iostream>
using namespace std;
  Road::Road(Indices ind) : Facility(ind, 0, 's') {}
  Road::~Road() {}
  char Road::Render() {
    return '-';
  }