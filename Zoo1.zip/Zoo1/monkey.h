#ifndef MONKEY_H
#define MONKEY_H
#include "primates.h"
#include "monkey.h"
#include "indices.h"
class Monkey : public Primates {
public:
  Monkey(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif