#ifndef MONKEY_H
#define MONKEY_H
#include "primates.h"
#include "monkey.h"
#include "indices.h"

class Monkey:public Primates{
//method	
public:
	//ctor with param
	Monkey(int bb,int x, int y);
	//destructor
	//polymorphism interaksi
	void Interact();
	char Render();
};
#endif
