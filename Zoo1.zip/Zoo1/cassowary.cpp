#include "cassowary.h"
#include "casuariformes.h"
#include "animals.h"
#include "indices.h"
#include <iostream>
using namespace std;
  /**@brief ctor
    *@param berat badan, absis, ordinat		
    */
  Cassowary::Cassowary(int bb, int x, int y): Casuariformes(true, x, y) {
    Cassowary::SetBerat(bb);
  }
  /**@brief polymorphism interaksi
    */
  void Cassowary::Interact() {
    cout << "I can't fly :(" << endl;
  }
  char Cassowary::Render() {
    return 'C';
  }