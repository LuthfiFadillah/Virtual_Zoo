#include "cassowary.h"
#include "casuariformes.h"
#include "animals.h"
#include "indices.h"
#include <iostream>
using namespace std;

//class Casuari: public Casuariformes {
//method

	//ctor with param
	Cassowary::Cassowary(int bb, int x, int y): Casuariformes(true, x, y) {
		Cassowary::SetBerat(bb);
	}
	//destructor
	//polymorphism interaksi
	void Cassowary::Interact() {
		cout << "I can't fly :(" << endl;
	}

	char Cassowary::Render() {
		return 'C';
	}
