#include "cetacea.h"
#include "animals.h"
#include "indices.h"

Cetacea::Cetacea(bool kejinakan, int x, int y): Animals(2,false,true,false,kejinakan, x,y) {}

//void move(bool water_habitat, bool land_habitat, bool air_habitat, point animal_koordinat, map);

