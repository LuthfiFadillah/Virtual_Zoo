//file mcage.cpp
#include "Cage.h"
#include "Indices.h"
#include "Cassowary.h"
#include <iostream>
using namespace std;

int main() {
	Indices wil[10];
	int k=0;
	Indices ind;
	for (int i=0; i<2; i++) {
		for (int j=0; j<5; j++) {	
			ind.set_absis(i+1); ind.set_ordinat(j+1);
			wil[k] = ind;
			k++;
		}
	}
	Cage c1(Wil, 10);
	Cassowary *pc;
	Cassowary *pc2;
	pc = new Cassowary(30,1,4);
	pc2 = new Cassowary(30,0,4);
	c1.AddAnimal(Pc);
	a1.AddAnimal(Pc2);
	Indices it(1,3);
	if (c1.IsHostOf(it)) {
		cout << "Daymn we did it\n";
	} else {
		cout << "Ayo semangat...\n";
	}
	
	cout << endl;
	c1.Inter();
	
	return 0;
}
