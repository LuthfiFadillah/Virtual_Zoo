#include "psittaciformes.h"
#include "animals.h"
#include "indices.h"


Psittaciformes::Psittaciformes(bool kejinakan, int x, int y) : Animals(1,false,false,true, kejinakan ,x,y) {}

//void move(bool water_habitat, bool land_habitat, bool air_habitat, point animal_koordinat, map);

