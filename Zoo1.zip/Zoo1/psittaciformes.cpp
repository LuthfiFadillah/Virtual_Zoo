#include "psittaciformes.h"
#include "animals.h"
#include "indices.h"
  Psittaciformes::Psittaciformes(bool kejinakan, int x, int y) : 
                                 Animals(1, false, false,
                                 true, kejinakan ,x,y) {}