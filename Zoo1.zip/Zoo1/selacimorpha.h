#ifndef SELACIMORPHA_H
#define SELACIMORPHA_H
#include "animals.h"
#include "indices.h"
class Selacimorpha : public Animals {
public:
  Selacimorpha(bool kejinakan, int x, int y);	
};
#endif