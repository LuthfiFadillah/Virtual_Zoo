#ifndef CARNIVORA_H
#define CARNIVORA_H
#include "animals.h"
#include "indices.h"
class Carnivora : public Animals {
public:
  /**@brief ctor
    *@param kejinakan, absis, ordinat
    */
  Carnivora(bool kejinakan, int x, int y);
};
#endif