#include "monkey.h"
#include "primates.h"
#include "indices.h"
#include "animals.h"
#include <iostream>
using namespace std;
  Monkey::Monkey(int bb, int x, int y) : Primates(true, x, y) {
    SetBerat(bb);
  }
  void Monkey::Interact(){
    cout << "uuuk aaak aaak" << endl;
  }
  char Monkey::Render() {
    return 'Y';
  }