#include "monkey.h"
#include "primates.h"
#include "indices.h"
#include "animals.h"
#include <iostream>
using namespace std;	

	//ctor with param
	Monkey::Monkey(int bb,int x, int y) : Primates(true,x,y){
		SetBerat(bb);
	}
	//destructor
	//polymorphism interaksi
	void Monkey::Interact(){
		cout<<"uuuk aaak aaak"<<endl;
	}
	char Monkey::Render() {
		return 'Y';
	}
