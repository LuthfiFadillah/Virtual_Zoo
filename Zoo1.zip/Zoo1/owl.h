#ifndef OWL_H
#define OWL_H
#include "strigiformes.h"
#include "animals.h"
#include "indices.h"
class Owl : public Strigiformes {
public:
  Owl(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif