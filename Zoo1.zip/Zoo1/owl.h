#ifndef OWL_H
#define OWL_H
#include "strigiformes.h"
#include "animals.h"
#include "indices.h"

class Owl:public Strigiformes{
//method
public:
	//ctor with param
	Owl(int bb, int x, int y);
	
	//polymorphism interaksi
	void Interact();
	char Render();
};
#endif
