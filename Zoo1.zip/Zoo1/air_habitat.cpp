#include "cell.h"
#include "habitat.h"
#include "air_habitat.h"
#include "indices.h"
#include <iostream>
using namespace std;
  AirHabitat::AirHabitat(Indices ind) : Habitat(ind, 2 , 'a') {}
  char AirHabitat::Render() {
    return 'a';
  }