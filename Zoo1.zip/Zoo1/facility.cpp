//file Facility.cpp
#include "cell.h"
#include "facility.h"
#include "indices.h"

	//Facility::Facility(): Cell() {}
	Facility::Facility(Indices ind, int type, char code): Cell(ind, 1, code), fType(type) {}
	//Facility::Facility(Facility& C): Cell(C.GetKoordinat()) {}
	Facility::~Facility() {}
	//Facility& Facility::operator= (Facility& F) {}
	//void GetKoordinat();
	bool Facility::IsRoad() { return (fType == 0); }
	bool Facility::IsPark() { return (fType == 1); }
	bool Facility::IsRestaurant() { return (fType == 2); }
