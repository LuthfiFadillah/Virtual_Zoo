#include "cell.h"
#include "facility.h"
#include "indices.h"
  Facility::Facility(Indices ind, int type, char code) :
                     Cell(ind, 1, code), fType(type) {}
  Facility::~Facility() {}
  bool Facility::IsRoad() { return (fType == 0); }
  bool Facility::IsPark() { return (fType == 1); }
  bool Facility::IsRestaurant() { return (fType == 2); }