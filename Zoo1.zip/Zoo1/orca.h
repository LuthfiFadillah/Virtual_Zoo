#ifndef ORCA_H
#define ORCA_H
#include "cetacea.h"
#include "animals.h"
#include "indices.h"

class Orca: public Cetacea{
//method
public:
	//ctor with param
	Orca(int bb, int x, int y);
	
	//polymorphism interaksi
	void Interact();
	char Render();
};
#endif
