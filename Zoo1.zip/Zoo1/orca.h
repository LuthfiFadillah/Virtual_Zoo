#ifndef ORCA_H
#define ORCA_H
#include "cetacea.h"
#include "animals.h"
#include "indices.h"
class Orca : public Cetacea {
public:
  Orca(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif