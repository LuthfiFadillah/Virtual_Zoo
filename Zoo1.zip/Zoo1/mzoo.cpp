#include "Zoo.h"
#include <iostream>
using namespace std;
int main() {
  Zoo z;
  z.Print();
  z.Move();
  cout << endl;
  z.Print();
  z.Move();
  cout << endl;
  z.Print();
  z.Move();
  cout << endl;
  z.Print();
  z.Move();
  cout << endl;
  z.Print();
  z.HitungMakanan();
  Indices ind(4,0);
  if (z.IsInteractable(ind, z.GetKandang()[0])) {
    cout << "Yeay.." << endl;
  }
  if (!Z.IsInteractable(ind, z.GetKandang()[8])) {
    cout << "Yeay..again" << endl;
  }
	return 0;
}