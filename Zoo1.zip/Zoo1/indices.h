#ifndef INDICES_H
#define INDICES_H
class Indices {
public:
  Indices();
  Indices(int absis, int ordinat);
  Indices(Indices&);
  ~Indices();
  Indices& operator= (Indices& ind);
  int GetAbsis();
  int GetOrdinat();
  void SetAbsis(int x);
  void SetOrdinat(int y);
  bool IsEqual(const Indices& ind);
protected:
  int x;
  int y;
};
#endif