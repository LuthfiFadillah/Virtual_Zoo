#include "squamata.h"
#include "animals.h"
#include "indices.h"
  Squamata::Squamata(bool kejinakan, int x, int y) :
                     Animals(2, true, false, false, kejinakan, x, y) {}