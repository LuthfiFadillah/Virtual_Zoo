#ifndef GIRAFFE_H
#define GIRAFFE_H
#include "artiodactyls.h"
#include "animals.h"
#include "indices.h"

class Giraffe:public Artiodactyls{
//method
public:
	//ctor with param
	Giraffe(int bb,int x, int y);
	void Interact();
	char Render();
};
#endif
