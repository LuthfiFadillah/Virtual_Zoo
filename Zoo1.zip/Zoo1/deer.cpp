#include "artiodactyls.h"
#include "animals.h"
#include "deer.h"
#include "indices.h"
#include <iostream>
using namespace std;
  Deer::Deer(int bb, int x, int y): Artiodactyls(true, x, y) {
    SetBerat(bb);
  }
  void Deer::Interact(){
    cout << "Do you know where is santa house??" << endl;
  }
  char Deer::Render() {
    return 'D';
  }