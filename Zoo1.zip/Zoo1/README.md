# Virtual_Zoo
Tugas OOP

v1.0 (24/02/2017)
- Membuat Repository di Github
- Upload Animals.h, Cetacea.h, Dolphin.h (by : Emil)

v1.1 (25/02/2017)
- Upload Psittaciformes.h, Strigiformes.h, Parrots.h, Owl.h, Orca.h, Cockatoo.h, Beluga.h (by : Alivia)
- Upload Anseriformes.h, Artiodactyls.h, Duck.h, Swan.h, Giraffe.h, BigHornSheep.h, Deer.h (by : Luthfi)
- Update Cetacea.h (by : Emil)

v1.2 (26/02/2017)
- Upload Grid.h & Grid.cpp (by : Luthfi & Alivia)

v2.0 (01/03/2017)
- Pematangan konsep kelas animals - ordo - spesies
- Upload Cassowary.h, Cassowary.cpp, Casuariformes.h, Casuariformes.cpp, Chameleon.h, Chameleon.cpp, GreatWhiteShark.h, GreatWhiteShark.cpp, Python.h, Python.cpp, Selacimorpha.h, Selacimorpha.cpp, Squamata.h, Squamata.cpp (by: Suzane)
- Upload Psittaciformes.cpp, Strigiformes.cpp, Parrots.cpp, Owl.cpp, Orca.cpp, Cockatoo.cpp, Beluga.cpp (by : Alivia)

v.2.1 (02/03/2017)
- Upload Primates.h, Carnivora.h, Lemur.h, Tarsier.h, Gorilla.h, Monkey.h, Meerkat.h, Cheetah.h, Lion.h, Wolf.h (by: Emil)
- Upload Primate.cpp, Carnivora.cpp, Lemur.cpp, Tarsier.cpp, Gorilla.cpp, Monkey.cpp, Meerkat.cpp, Cheetah.cpp, Lion.cpp, Wolf.cpp (by: Emil)

v2.2 (03/03/2017)
- upload Animals.cpp, Animals.h, Casuariformes.cpp, Casuariformes.h, Cassowary.cpp, dan Cassowary.h 2 versi ctor: parameter int, int (pada branch master) dan parameter Indices (pada branch WithIndices) (by: Alivia, Suzane)

v3.1 (11/03/2017)
- upload Cell.h, Cell.cpp, Facility.h, Facility.cpp, Renderable,h, Road.h, Road.cpp, Park.h, Park.cpp, Restaurant.h, Restaurant.cpp (by: Suzane)
