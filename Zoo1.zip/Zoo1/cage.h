#ifndef CAGE_H
#define CAGE_H
#include "animals.h"
#include "indices.h"
class Cage {
public:
  Cage();
  Cage(Indices *ind, int neff);
  Cage& operator= (const Cage& c);
  ~Cage();
  bool IsHostOf(Indices ind);
  bool Spacious();
  void AddAnimal(Animals* a);
  void Inter();
  bool IsCageOf(Animals* a);
  Animals ** GetAnimals();
  int GetLuas();
  int GetBanyakHewan();
private:
  Indices* wilayah;
  Animals** data_animals;
  int luas;
  int banyak_hewan;
};
#endif