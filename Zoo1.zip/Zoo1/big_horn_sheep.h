#ifndef BIGHORNSHEEP_H
#define BIGHORNSHEEP_H
#include "artiodactyls.h"
#include "animals.h"
#include "indices.h"
class BigHornSheep : public Artiodactyls {
public:
  /**@brief ctor
    *@param berat badan, absis, ordinat		
    */
  BigHornSheep(int bb, int x, int y);
  /**@brief polymorphism interaksi
	*/
  void Interact();
  char Render();
};
#endif