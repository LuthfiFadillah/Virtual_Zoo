#ifndef BIGHORNSHEEP_H
#define BIGHORNSHEEP_H
#include "artiodactyls.h"
#include "animals.h"
#include "indices.h"

class BigHornSheep:public Artiodactyls{
//method
public:
	//ctor with param
	BigHornSheep(int bb,int x, int y);

	//polymorphism interaksi
	void Interact();
	
	char Render();
};
#endif
