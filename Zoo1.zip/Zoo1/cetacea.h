#ifndef CETACEA_H
#define CETACEA_H
#include "animals.h"
#include "indices.h"
class Cetacea : public Animals {
public:
  /**@brief ctor
    *@param kejinakan, absis, ordinat
    */
  Cetacea(bool kejinakan, int x, int y);
};
#endif