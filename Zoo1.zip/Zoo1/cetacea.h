#ifndef CETACEA_H
#define CETACEA_H
#include "animals.h"
#include "indices.h"

class Cetacea: public Animals{
	
//method
public:
	Cetacea(bool kejinakan, int x, int y);
	
	//void move(bool water_habitat, bool land_habitat, bool air_habitat, point animal_koordinat, map);

};
#endif
