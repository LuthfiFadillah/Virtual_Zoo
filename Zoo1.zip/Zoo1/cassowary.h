#ifndef CASSOWARY_H
#define CASSOWARY_H
#include "casuariformes.h"
#include "animals.h"
#include "indices.h"
class Cassowary : public Casuariformes {
public:
  /**@brief ctor
    *@param berat badan, absis, ordinat
    */
  Cassowary(int bb, int x, int y);
  /**@brief polymorphism interaksi		
    */
  void Interact();
  char Render();
};
#endif