#ifndef DUCK_H
#define DUCK_H
#include "anseriformes.h"
#include "animals.h"
#include "indices.h"
class Duck:public Anseriformes{
//method
public:
	//ctor with param
	Duck(int bb,int x, int y);

	//polymorphism interaksi
	void Interact();
	
	char Render();
};
#endif
