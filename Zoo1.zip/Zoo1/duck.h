#ifndef DUCK_H
#define DUCK_H
#include "anseriformes.h"
#include "animals.h"
#include "indices.h"
class Duck : public Anseriformes {
public:
  Duck(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif