#ifndef BELUGA_H
#define BELUGA_H
#include "cetacea.h"
#include "animals.h"
#include "indices.h"

class Beluga:public Cetacea{
	
//method
public:
	//ctor with param
	Beluga(int bb, int x, int y);
	
	//polymorphism interaksi
	void Interact();
    
    char Render();

};
#endif
