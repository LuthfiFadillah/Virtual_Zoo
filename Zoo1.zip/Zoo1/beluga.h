#ifndef BELUGA_H
#define BELUGA_H
#include "cetacea.h"
#include "animals.h"
#include "indices.h"
class Beluga : public Cetacea {
public:
  /**@brief ctor
	*@param berat badan, absis, ordinat	
	*/
  Beluga(int bb, int x, int y);
  /**@brief polymorphism interaksi
	*/
  void Interact();
  char Render();
};
#endif