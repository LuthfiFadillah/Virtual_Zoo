#ifndef LANDHABITAT_H
#define LANDHABITAT_H
#include "cell.h"
#include "habitat.h"
#include "indices.h"

class LandHabitat: public Habitat {
public:
  LandHabitat(Indices ind);
  char Render();
};
#endif
