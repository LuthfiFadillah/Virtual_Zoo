#include "chameleon.h"
#include <iostream>
#include "indices.h"
using namespace std;
  Chameleon::Chameleon(int bb, int x, int y) : Squamata(false, x, y) {
    SetBerat(bb);
  }
  void Chameleon::Interact() {
    cout << "Smisshy slimi skinny\n" << endl;
  }
  char Chameleon::Render() {
   return 'H';
  }