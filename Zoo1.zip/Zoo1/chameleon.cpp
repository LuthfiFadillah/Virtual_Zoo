#include "chameleon.h"
#include <iostream>
#include "indices.h"
using namespace std;

//class Chameleon: public Squamata{
//method
//public:
	//ctor with param
	Chameleon::Chameleon(int bb,int x,int y) : Squamata(false,x,y) {
		SetBerat(bb);
	}
	//destructor
	//polymorphism interaksi
	void Chameleon::Interact() {
		cout << "Smisshy slimi skinny\n";
	}

	char Chameleon::Render() {
		return 'H';
	}
