#include "duck.h"
#include "indices.h"
#include <iostream>
using namespace std;
  Duck::Duck(int bb, int x, int y) : Anseriformes(true, x, y) {
    SetBerat(bb);
  }
  void Duck::Interact() {
    cout << "Qwekk Qwekk\n" <<endl;
  }
  char Duck::Render() {
    return 'U';
  }