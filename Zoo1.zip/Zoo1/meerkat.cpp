#include "meerkat.h"
#include "carnivora.h"
#include "animals.h"
#include "indices.h"
#include <iostream>
using namespace std;

//class Meerkat: public Carnivora {
//method

	//ctor with param
	Meerkat::Meerkat(int bb, int x, int y) : Carnivora(true,x,y) {
		SetBerat(bb);
	}
	//destructor
	//polymorphism interaksi
	void Meerkat::Interact() {
		cout << "*suddenly standing*" << endl;
	}
	char Meerkat::Render() {
		return 'M';
	}
