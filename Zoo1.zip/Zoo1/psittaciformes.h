#ifndef PSITTACIFORMES_H
#define PSITTACIFORMES_H
#include "animals.h"
#include "indices.h"

class Psittaciformes : public Animals {
	
//method
public:	
	Psittaciformes(bool kejinakan, int x, int y);
	
	//void move(bool water_habitat, bool land_habitat, bool air_habitat, point animal_koordinat, map);

	
};
#endif
