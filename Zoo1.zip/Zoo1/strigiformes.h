#ifndef STRIGIFORMES_H
#define STRIGIFORMES_H
#include "animals.h"
#include "indices.h"
class Strigiformes : public Animals {
public:
  Strigiformes(bool kejinakan, int x, int y);
};
#endif