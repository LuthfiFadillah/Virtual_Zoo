#ifndef WOLF_H
#define WOLF_H
#include "carnivora.h"
#include "animals.h"
class Wolf : public Carnivora {
public:
  Wolf(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif