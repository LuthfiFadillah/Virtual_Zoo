//file Facility.h
#ifndef FACILITY_H
#define FACILITY_H
#include "cell.h"
#include "renderable.h"
#include "indices.h"

class Facility: public Cell {
public:
	Facility(Indices ind, int type, char code);
	//Facility(Facility& C);
	~Facility();
	//Facility& operator= (Facility& F);
	bool IsRoad();
	bool IsPark();
	bool IsRestaurant();
	//virtual void render() = 0; //iya???
protected:
	const int fType; //0 = Road, 1 = Park, 2 = Restaurant
};

#endif
