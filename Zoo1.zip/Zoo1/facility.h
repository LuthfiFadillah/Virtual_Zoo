#ifndef FACILITY_H
#define FACILITY_H
#include "cell.h"
#include "renderable.h"
#include "indices.h"
class Facility : public Cell {
public:
  Facility(Indices ind, int type, char code);
  ~Facility();
  bool IsRoad();
  bool IsPark();
  bool IsRestaurant();
protected:
  const int fType;
};
#endif