#include "great_white_shark.h"
#include "indices.h"
#include <iostream>
using namespace std;
  GreatWhiteShark::GreatWhiteShark(int bb, int x, int y) :
                                   Selacimorpha(false, x, y) {
    SetBerat(bb);
  }
  void GreatWhiteShark::Interact() {
    cout << "*Big grins* heyyo" << endl;
  }
  char GreatWhiteShark::Render() {
    return 'K';
  }