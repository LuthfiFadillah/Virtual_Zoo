#ifndef LEMUR_H
#define LEMUR_H
#include "primates.h"
#include "animals.h"
#include "indices.h"
class Lemur : public Primates {
public:
  Lemur(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif