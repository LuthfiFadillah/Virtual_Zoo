#ifndef PARROTS_H
#define PARROTS_H
#include "psittaciformes.h"
#include "animals.h"
#include "indices.h"
class Parrots:public Psittaciformes{
//method
public:
	//ctor with param
	Parrots(int bb, int x, int y);
	
	//polymorphism interaksi
	void Interact();
	char Render();
};
#endif
