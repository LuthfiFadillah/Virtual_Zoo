#ifndef PARROTS_H
#define PARROTS_H
#include "psittaciformes.h"
#include "animals.h"
#include "indices.h"
class Parrots : public Psittaciformes {
public:
  Parrots(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif