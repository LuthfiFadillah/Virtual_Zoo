#include "indices.h"
#include <iostream>
using namespace std;
  Indices::Indices() {
    x=0;
    y=0;
  }
  Indices::Indices(int absis, int ordinat) {
    Indices::x = absis; Indices::y = ordinat;
  }
  Indices::Indices(Indices& ind) {
    x = ind.GetAbsis();
    y = ind.GetOrdinat();
  }
  Indices::~Indices() {}
  Indices& Indices::operator= (Indices& ind) {
    Indices::x = ind.x;
    Indices::y = ind.y;
    return *this;
  }
  int Indices::GetAbsis() {
    return x;
  }
  int Indices::GetOrdinat() {
    return y;
  }
  void Indices::SetAbsis(int absis) {
    x = absis;
  }
  void Indices::SetOrdinat(int ordinat) {
    y = ordinat;
  }	
  bool Indices::IsEqual(const Indices& ind) {
    return ((ind.x == x) && (ind.y == y));
  }