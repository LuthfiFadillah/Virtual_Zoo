#include "indices.h"
#include <iostream>
using namespace std;

	//ctor
	Indices::Indices() {
		x=0;
		y=0;
	}
	
	//ctor with param
	Indices::Indices(int absis, int ordinat) {
		Indices::x = absis; Indices::y = ordinat;
	}
	
	//cctor
	Indices::Indices(Indices& ind) {
		x = I.GetAbsis();
		y = I.GetOrdinat();
	}
	//dtor
	Indices::~Indices() {
		//cout << "tes";
		//x = 0; y = 0;
		//cout << "tes lagi\n";
	}
	//operator = 
	Indices& Indices::operator= (Indices& ind) {
		Indices::x = ind.x;
		Indices::y = ind.y;
		return *this;
	}
	//getter
	int Indices::GetAbsis() {
		return x;
	}
	int Indices::GetOrdinat() {
		return y;
	}
	//setter
	void Indices::SetAbsis(int absis) {
		//cout << absis << endl;
		x = absis;
		//cout<<x<<"lalal"<<endl;
	}
	void Indices::SetOrdinat(int ordinat) {
		y = ordinat;
	}
	
	bool Indices::IsEqual(const Indices& ind){
		return ((ind.x == x) && (ind.y == y));
	}
	//cout
	/*
	std::ostream& operator<<(std::ostream &os, Indices& I) {
		cout << "Absis: " << I.get_absis() << endl;
		cout << "Ordinat: " << I.get_ordinat() << endl;
	}
	*/
