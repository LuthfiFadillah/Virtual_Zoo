#include "cell.h"
#include "habitat.h"
#include "land_habitat.h"
#include "indices.h"
#include <iostream>
using namespace std;

LandHabitat::LandHabitat(Indices ind) : Habitat(ind,0,'l'){}
char LandHabitat::Render(){
  return 'l';
}
