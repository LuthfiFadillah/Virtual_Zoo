#include "lemur.h"
#include "primates.h"
#include "animals.h"
#include "indices.h"
#include <iostream>
using namespace std;
  Lemur::Lemur(int bb, int x, int y) : Primates (true, x, y) {
    SetBerat(bb);
  }
  void Lemur::Interact() {
    cout << "*chirps*" << endl;
  }
  char Lemur::Render() {
    return 'E';
  }