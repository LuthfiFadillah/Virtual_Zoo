#include "artiodactyls.h"
#include "animals.h"
#include "giraffe.h"
#include "indices.h"
#include <iostream>
using namespace std;

	//ctor with param
	Giraffe::Giraffe(int bb, int x, int y): Artiodactyls(true,x,y){
		SetBerat(bb);
	}

	void Giraffe::Interact(){
		cout<< "where are u? i cant see you! are you down there?? please come up!" << endl;
	}
	
	char Giraffe::Render() {
		return 'G';
	}
