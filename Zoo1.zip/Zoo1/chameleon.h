#ifndef CHAMELEON_H
#define CHAMELEON_H
#include "squamata.h"
#include "indices.h"
class Chameleon : public Squamata {
public:
  Chameleon(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif