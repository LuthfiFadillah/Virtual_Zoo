#ifndef CHAMELEON_H
#define CHAMELEON_H
#include "squamata.h"
#include "indices.h"

class Chameleon: public Squamata{
//method
public:
	//ctor with param
	Chameleon(int bb,int x, int y);
	//destructor
	//polymorphism interaksi
	void Interact();
	char Render();
};
#endif
