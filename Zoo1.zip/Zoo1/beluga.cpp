#include "cetacea.h"
#include "animals.h"
#include "beluga.h"
#include "indices.h"
#include <iostream>
using namespace std;
  /**@brief ctor
	*@param berat badan, absis, ordinat		
	*/
  Beluga::Beluga(int bb, int x, int y) : Cetacea(true,x,y) {
    SetBerat(bb);
  }
  /**@brief polymorphism interaksi		
    */
  void Beluga::Interact() {
    cout << "Ooooooooooooo..." << endl;
   }
  char Beluga::Render() {
    return 'B';
}