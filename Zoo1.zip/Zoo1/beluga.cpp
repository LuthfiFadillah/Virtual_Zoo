#include "cetacea.h"
#include "animals.h"
#include "beluga.h"
#include "indices.h"
#include <iostream>
using namespace std;

	//ctor with param
	Beluga::Beluga(int bb, int x, int y): Cetacea(true,x,y) {
		SetBerat(bb);
	}
	
	//polymorphism interaksi
	void Beluga::Interact() {
		cout << "Ooooooooooooo..." << endl;
	}
		
char Beluga::Render() {
 return 'B';
}
