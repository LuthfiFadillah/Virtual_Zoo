#ifndef SQUAMATA_H
#define SQUAMATA_H
#include "animals.h"
#include "indices.h"
class Squamata : public Animals {
public:
  Squamata(bool kejinakan, int x, int y);
};
#endif