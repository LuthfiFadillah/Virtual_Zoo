#include "cetacea.h"
#include "animals.h"
#include "dolphin.h"
#include "indices.h"
#include <iostream>
using namespace std;
  Dolphin::Dolphin(int bb, int x, int y): Cetacea(true, x, y) {
    SetBerat(bb);
  }
  void Dolphin::Interact() {
    cout << "Bermain bola? Makan dulu" << endl;
  }
  char Dolphin::Render() {
    return 'N';
  }