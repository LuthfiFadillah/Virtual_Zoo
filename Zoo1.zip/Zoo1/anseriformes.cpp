#include "anseriformes.h"
#include "animals.h"
#include "indices.h"
  /**@brief ctor
    *@param kejinakan, absis, ordinat
	*/
  Anseriformes::Anseriformes(bool kejinakan, int x, int y) :
                             Animals(1, true, true, false,kejinakan, x,y) {}