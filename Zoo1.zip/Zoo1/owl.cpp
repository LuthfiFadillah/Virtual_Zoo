#include "strigiformes.h"
#include "animals.h"
#include "owl.h"
#include "indices.h"
#include <iostream>
using namespace std;

	//ctor with param
	Owl::Owl(int bb, int x, int y): Strigiformes(true, x, y) {
		SetBerat(bb);
	}
	
	//polymorphism interaksi
	void Owl::Interact(){
		cout << "Coccooo Coccooo" << endl;
		}

	char Owl::Render() {
		return 'Z';
	}
