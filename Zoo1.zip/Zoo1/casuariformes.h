#ifndef CASUARIFORMES_H
#define CASUARIFORMES_H
#include "animals.h"
#include "indices.h"
class Casuariformes : public Animals {
public:
  /**@brief ctor
    *@param kejinakan, absis, ordinat
    */
  Casuariformes(bool kejinakan, int x, int y);
};
#endif