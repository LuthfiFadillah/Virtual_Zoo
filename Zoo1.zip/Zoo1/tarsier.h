#ifndef TARSIER_H
#define TARSIER_H
#include "primates.h"
#include "animals.h"
#include "indices.h"

class Tarsier:public Primates{
//method	
public:
	//ctor with param
	Tarsier(int bb,int x, int y);
	//destructor
	//polymorphism interaksi
	void Interact();
	char Render();
};
#endif
