#ifndef TARSIER_H
#define TARSIER_H
#include "primates.h"
#include "animals.h"
#include "indices.h"
class Tarsier : public Primates {
public:
  Tarsier(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif