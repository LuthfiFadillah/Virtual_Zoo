#include "cetacea.h"
#include "animals.h"
#include "orca.h"
#include "indices.h"
#include <iostream>
using namespace std;
  Orca::Orca(int bb, int x, int y): Cetacea(false, x, y) {
    SetBerat(bb);
  }
  void Orca::Interact() {
    cout << "*WWUSHHHO" << endl;
  }
  char Orca::Render() {
    return '$';
  }