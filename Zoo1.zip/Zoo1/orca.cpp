#include "cetacea.h"
#include "animals.h"
#include "orca.h"
#include "indices.h"
#include <iostream>
using namespace std;

	//ctor with param
	Orca::Orca(int bb, int x, int y): Cetacea(false, x,y) {
		SetBerat(bb);
	}
	
	//polymorphism interaksi
	void Orca::Interact(){
		cout << "*WWUSHHHO" << endl;
		}

	char Orca::Render() {
		return '$';
	}
