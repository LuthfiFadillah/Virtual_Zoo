#ifndef LION_H
#define LION_H
#include "carnivora.h"
#include "animals.h"
#include "indices.h"

class Lion:public Carnivora{
//method
public:
	//ctor with param
	Lion(int bb, int x, int y);
	//destructor
	//polymorphism interaksi
	void Interact();
	char Render();
	
};
#endif
