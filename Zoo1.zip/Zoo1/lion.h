#ifndef LION_H
#define LION_H
#include "carnivora.h"
#include "animals.h"
#include "indices.h"
class Lion : public Carnivora {
public:
  Lion(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif