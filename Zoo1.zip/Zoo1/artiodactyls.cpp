#include "artiodactyls.h"
#include "animals.h"
#include "indices.h"
  /**@brief ctor
     *@param kejinakan, absis, ordinat
     */
  Artiodactyls::Artiodactyls(bool kejinakan, int x, int y) :
                             Animals(0, true, false, false,kejinakan, x,y) {}