#include "artiodactyls.h"
#include "animals.h"
#include "indices.h"

//method

	//ctor
	Artiodactyls::Artiodactyls(bool kejinakan, int x, int y): Animals(0, true, false, false,kejinakan, x,y) {}
	//bergerak sesuai constrain habitat
	//void move(bool water_habitat, bool land_habitat, bool air_habitat, point animal_koordinat, map);
