#include "cell.h"
#include "habitat.h"
#include "water_habitat.h"
#include "indices.h"
#include <iostream>
using namespace std;

WaterHabitat::WaterHabitat(Indices ind) : Habitat(ind,1,'w'){}

WaterHabitat::~WaterHabitat() {}

char WaterHabitat::Render(){
  return 'w';
}
