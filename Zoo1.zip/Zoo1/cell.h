#ifndef CELL_H
#define CELL_H
#include "renderable.h"
#include "indices.h"
class Cell : public Renderable {
public:
  Cell(Indices ind, int t, char c);
  ~Cell();
  char Render();
  Indices GetKoordinat();
  bool IsHabitat();
  bool IsFacility();
  char GetCode();
protected:
  Indices koordinat;
  /**@brief 0=Habitat, 1=Facility
    */
  const int type;
  const char code;
};
#endif