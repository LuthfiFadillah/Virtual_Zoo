#include "cell.h"
#include "indices.h"
  Cell::Cell(Indices ind, int t, char c) :
             Renderable(0), type(t), code(c) { koordinat = ind; }
  Cell::~Cell() {}
  char Cell::Render() { return '.'; }
  Indices Cell::GetKoordinat() { return koordinat; }
  bool Cell::IsHabitat() { return (type == 0); }
  bool Cell::IsFacility() { return (type == 1); }
  char Cell::GetCode() { return code; }