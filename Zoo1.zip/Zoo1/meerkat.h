#ifndef MEERKAT_H
#define MEERKAT_H
#include "carnivora.h"
#include "animals.h"
#include "indices.h"

class Meerkat:public Carnivora{
//method
public:
	//ctor with param
	Meerkat(int bb,int x, int y);
	//destructor
	//polymorphism interaksi
	void Interact();
	char Render();
};
#endif
