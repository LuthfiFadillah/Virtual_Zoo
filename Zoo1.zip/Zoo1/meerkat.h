#ifndef MEERKAT_H
#define MEERKAT_H
#include "carnivora.h"
#include "animals.h"
#include "indices.h"
class Meerkat : public Carnivora {
public:
  Meerkat(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif