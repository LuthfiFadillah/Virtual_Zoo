#ifndef AIRHABITAT_H
#define AIRHABITAT_H
#include "cell.h"
#include "habitat.h"
#include "indices.h"
class AirHabitat : public Habitat {
public:
  AirHabitat(Indices ind);
  char Render();
};
#endif