#include "swan.h"
#include "indices.h"
#include <iostream>
using namespace std;
  Swan::Swan(int bb, int x, int y) : Anseriformes(true, x, y) {
    SetBerat(bb);
  }
  void Swan::Interact() {
    cout << "Qwokk Qwokk\n" << endl;
  }
  char Swan::Render() {
    return 'Q';
  }