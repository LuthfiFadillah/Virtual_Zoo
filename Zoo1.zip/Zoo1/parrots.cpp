#include "psittaciformes.h"
#include "animals.h"
#include "parrots.h"
#include "indices.h"
#include <iostream>
using namespace std;

	//ctor with param
	Parrots::Parrots(int bb,int x,int y): Psittaciformes(true,x,y) {
		SetBerat(bb);
	}
	
	//polymorphism interaksi
	void Parrots::Interact(){
		cout << "Anyeong.." << endl;
		}

	char Parrots::Render() {
		return 'X';
	}
