#include "psittaciformes.h"
#include "animals.h"
#include "parrots.h"
#include "indices.h"
#include <iostream>
using namespace std;
  Parrots::Parrots(int bb, int x, int y) : Psittaciformes(true, x, y) {
    SetBerat(bb);
  }
  void Parrots::Interact() {
    cout << "Anyeong.." << endl;
  }
  char Parrots::Render() {
    return 'X';
  }