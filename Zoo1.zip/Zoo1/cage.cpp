#include "cage.h"
#include "animals.h"
#include "indices.h"
#include <iostream>
using namespace std;
  Cage::Cage() {}
  Cage::Cage(Indices *i, int neff) {
    wilayah = new Indices[neff];
    for (int i = 0; i < neff; i++) {
	    wilayah[i] = ind[i];
    }
    luas = neff;
    banyak_hewan = 0;
    data_animals = new Animals* [(neff*3) / 10];
  }
  Cage::~Cage() {
    luas = 0;
  }
  Cage& Cage::operator= (const Cage& c) {
    int i;
    luas = c.luas;
    banyak_hewan = c.banyak_hewan;
    if (this != &c) {
      wilayah = new Indices[luas];
      for (i = 0; i < luas; i++) {
        wilayah[i] = c.wilayah[i];
      }
      data_animals = new Animals* [banyak_hewan];
      for (i = 0; i < banyak_hewan; i++) {
        data_animals[i] = c.data_animals[i];
      }
    }
      return *this;
  }
  bool Cage::IsHostOf(Indices ind) {
    bool ketemu = false;
    int i = 0;
	  while ((i < luas) && (!ketemu)) {
	    ketemu = (ind.IsEqual(wilayah[i]));
      i++;
    }
    return ketemu;
  }
  bool Cage::Spacious() {
    return (banyak_hewan <= (luas*3) / 10);
  }
  void Cage::AddAnimal(Animals* a) {
    Indices ind(a->GetKoordinat().GetAbsis(), a->GetKoordinat().GetOrdinat());
      if (IsHostOf(ind)) {
        if (Spacious()) {
          if (!(a->IsJinak())) {
            if (banyak_hewan == 0) {
              data_animals[banyak_hewan] = a;
              banyak_hewan++;
            } 
            else {
              if (a->Render() == data_animals[0]->Render()) {
                data_animals[banyak_hewan] = a;
                banyak_hewan++;
              }
		        }
		      }
		      else {
            data_Animals[banyak_hewan] = a;
            banyak_hewan++;
          }
        }
        else {
		      cout << "Penuh couyyy" << endl;
        }
      }
  }
  void Cage::Inter() {
    for (int i = 0; i < banyak_hewan; i++) {
	    data_animals[i]->Interact();
    }
  }	
  bool Cage::IsCageOf(Animals* a) {
    int i = 0;
    bool ketemu = (data_animals[i] == a);
    while (!ketemu && (i < banyak_hewan)) {
	    ketemu = (data_animals[i] == a);
      i++;
    }
    return ketemu;
  }
  Animals ** Cage::GetAnimals() {
    return data_animals;
  }
  int Cage::GetLuas() {
    return luas;
  }
  int Cage::GetBanyakHewan() {
    return banyak_hewan;
  }