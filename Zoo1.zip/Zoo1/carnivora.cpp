#include "carnivora.h"
#include "animals.h"
#include "indices.h"
  /**@brief ctor
	*@param kejinakan, absis, ordinat	
	*/
  Carnivora::Carnivora(bool kejinakan, int x, int y) :
                       Animals(2, true, false, false,kejinakan,x,y) {}