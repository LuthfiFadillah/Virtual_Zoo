#ifndef PARK_H
#define PARK_H
#include "cell.h"
#include "facility.h"
#include "indices.h"
class Park : public Facility {
public:
  Park(Indices ind);
  ~Park();
  char Render();
};
#endif