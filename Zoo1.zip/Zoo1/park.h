//file Park.h
#ifndef PARK_H
#define PARK_H
#include "cell.h"
#include "facility.h"
#include "indices.h"

class Park: public Facility {
public:
	//Road();
	Park(Indices ind);
	//Road(Road& R);
	~Park();
	//Road& operator= (Road& R);
	char Render();
};

#endif
