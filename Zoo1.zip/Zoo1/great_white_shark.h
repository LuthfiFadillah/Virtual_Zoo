#ifndef GREATWHITESHARK_H
#define GREATWHITESHARK_H
#include "selacimorpha.h"
#include "indices.h"

class GreatWhiteShark: public Selacimorpha {

//method
public:
	//ctor with param
	GreatWhiteShark(int bb,int x, int y);
	//destructor
	//polymorphism interaksi
	void Interact();
	char Render();
};
#endif
