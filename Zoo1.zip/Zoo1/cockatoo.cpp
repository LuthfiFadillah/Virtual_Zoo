#include "psittaciformes.h"
#include "animals.h"
#include "cockatoo.h"
#include <iostream>
using namespace std;
  Cockatoo::Cockatoo(int bb, int x, int y): Psittaciformes(true, x, y) {
    SetBerat(bb);
  }
  void Cockatoo::Interact(){
    cout << "Cockatooo... Cockatooo..." << endl;
  }
  char Cockatoo::Render() {
    return 'O';
  }