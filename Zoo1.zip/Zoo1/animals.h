//Animals.h
#ifndef ANIMALS_H
#define ANIMALS_H
#include "renderable.h"
#include "land_habitat.h"
#include "water_habitat.h"
#include "air_habitat.h"
#include "cell.h"
#include "indices.h"
class Animals: public Renderable {
//method
public:
	//ctor
	Animals(int makan, bool land, bool water, bool air, bool kejinakan, int x, int y);
	
	//dtor
	~Animals();
    
  //  Animals& operator= (const Animals& A);
	
	//interaksi yang dilakukan animals
	virtual void Interact() = 0;
	
	//gerakan animals
	//virtual void move() = 0;
	
	//return berat badan animals
	int GetBerat();
	
	//set berat badan animals
	void SetBerat(int bb);
	
	//return koordinat animals
	Indices GetKoordinat();
	
	//set koordinat
	void SetKoordinat(int x, int y);
	
	//habitat hewan
	bool IsLandAnimal();
	bool IsWaterAnimal();
	bool IsAirAnimal();
	
	//kejinakan
	bool IsJinak();
    
    bool IsLivable(Cell C);
    
	int GetMakanan();

//atribut
protected:
	int berat_badan;
	Indices koordinat;
	const int makanan;
	const bool land_animal;
	const bool water_animal;
	const bool air_animal;
	const bool jinak;
};

#endif
