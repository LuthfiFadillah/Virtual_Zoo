#ifndef ANIMALS_H
#define ANIMALS_H
#include "renderable.h"
#include "land_habitat.h"
#include "water_habitat.h"
#include "air_habitat.h"
#include "cell.h"
#include "indices.h"
class Animals: public Renderable {
public:
  /**@brief ctor
    */
  Animals(int makan, bool land, bool water, bool air,
	        bool kejinakan, int x, int y);
  /**@brief dtor
    */
  ~Animals();
  /**@brief interaksi yang dilakukan animals, pure virtual
    */
  virtual void Interact() = 0;
  /**@brief mengembalikan berat badan animals
    */
  int GetBerat();
  /**@brief menetapkan berat badan animals
    *@param berat badan yang ingin ditetapkan
    */
  void SetBerat(int bb);
  /**@brief mengembalikan koordinat animals
    */
  Indices GetKoordinat();
  /**@brief menetapkan koordinat animals
  	*@param koordinat untuk animals, berupa integer x dan integer y
  	*/
	void SetKoordinat(int x, int y);
	bool IsLandAnimal();
	bool IsWaterAnimal();
	bool IsAirAnimal();
	bool IsJinak();
  bool IsLivable(Cell c);
	int GetMakanan();
protected:
	int berat_badan;
	Indices koordinat;
	const int makanan;
	const bool land_animal;
	const bool water_animal;
	const bool air_animal;
	const bool jinak;
};
#endif