#include "casuariformes.h"
#include "animals.h"
#include "indices.h"
#include <iostream>
using namespace std;

//class Casuariformes: public Animals{

//method

	//ctor
	Casuariformes::Casuariformes(bool kejinakan, int x, int y): Animals(1, true, false, false, kejinakan, x, y) {}
	//bergerak sesuai constrain habitat
	//void move(bool water_habitat, bool land_habitat, bool air_habitat, point animal_koordinat, map);
