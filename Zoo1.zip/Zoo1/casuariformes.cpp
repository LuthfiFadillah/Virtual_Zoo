#include "casuariformes.h"
#include "animals.h"
#include "indices.h"
#include <iostream>
using namespace std;
  /**@brief ctor
    *@param kejinakan, absis, ordinat	
    */
	Casuariformes::Casuariformes(bool kejinakan, int x, int y) :
	                             Animals(1, true, false, false,
	                             kejinakan, x, y) {}