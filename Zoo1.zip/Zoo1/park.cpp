//file Park.cpp
#include "cell.h"
#include "facility.h"
#include "park.h"
#include "indices.h"
#include <iostream>
using namespace std;

	//Road();
	Park::Park(Indices ind): Facility(ind, 1, 'p') {}
	//Road(Road& R);
	Park::~Park() {}
	//Road& operator= (Road& R);
	char Park::Render() {
		return 'P';
	}
