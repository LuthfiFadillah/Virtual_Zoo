#include "cell.h"
#include "facility.h"
#include "park.h"
#include "indices.h"
#include <iostream>
using namespace std;
  Park::Park(Indices ind) : Facility(ind, 1, 'p') {}
  Park::~Park() {}
  char Park::Render() {
    return 'P';
  }