#include "strigiformes.h"
#include "animals.h"
#include "indices.h"

Strigiformes::Strigiformes(bool kejinakan, int x, int y) : Animals(1,true,false,false,kejinakan,x,y) {}

//void move(bool water_habitat, bool land_habitat, bool air_habitat, point animal_koordinat, map);

