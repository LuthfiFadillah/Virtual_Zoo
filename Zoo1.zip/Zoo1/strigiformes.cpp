#include "strigiformes.h"
#include "animals.h"
#include "indices.h"
Strigiformes::Strigiformes(bool kejinakan, int x, int y) : 
                           Animals(1, true, false, false, kejinakan, x, y) {}