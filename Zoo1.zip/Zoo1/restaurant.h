//file Restaurant.h
#ifndef RESTAURANT_H
#define RESTAURANT_H
#include "cell.h"
#include "facility.h"
#include "indices.h"

class Restaurant: public Facility {
public:
	//Road();
	Restaurant(Indices ind);
	//Road(Road& R);
	~Restaurant();
	//Road& operator= (Road& R);
	char Render();
};

#endif
