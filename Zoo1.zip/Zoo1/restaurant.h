#ifndef RESTAURANT_H
#define RESTAURANT_H
#include "cell.h"
#include "facility.h"
#include "indices.h"
class Restaurant : public Facility {
public:
  Restaurant(Indices ind);
  ~Restaurant();
  char Render();
};
#endif