#include "gorilla.h"
#include "primates.h"
#include "animals.h"
#include "indices.h"
#include <iostream>
using namespace std;	
  Gorilla::Gorilla(int bb, int x, int y) : Primates(true, x, y) {
    SetBerat(bb);
  }
  void Gorilla::Interact(){
    cout << "*thump thump*" << endl;
  }
  char Gorilla::Render() {
    return 'J';
  }