#include "gorilla.h"
#include "primates.h"
#include "animals.h"
#include "indices.h"
#include <iostream>
using namespace std;	

	//ctor with param
	Gorilla::Gorilla(int bb, int x, int y) : Primates(true,x,y){
		SetBerat(bb);
	}
	//destructor
	//polymorphism interaksi
	void Gorilla::Interact(){
		cout<<"*thump thump*"<<endl;
	}

	char Gorilla::Render() {
		return 'J';
	}
