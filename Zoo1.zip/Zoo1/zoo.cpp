//File: Zoo.cpp
#include "zoo.h"
#include "road.h"
#include "park.h"
#include "restaurant.h"
#include "water_habitat.h"
#include "land_habitat.h"
#include "air_habitat.h"
#include "beluga.h"
#include "big_horn_sheep.h"
#include "cassowary.h"
#include "chameleon.h"
#include "cheetah.h"
#include "cockatoo.h"
#include "deer.h"
#include "dolphin.h"
#include "duck.h"
#include "giraffe.h"
#include "gorilla.h"
#include "great_white_shark.h"
#include "lemur.h"
#include "lion.h"
#include "meerkat.h"
#include "monkey.h"
#include "orca.h"
#include "owl.h"
#include "parrots.h"
#include "python.h"
#include "swan.h"
#include "tarsier.h"
#include "wolf.h"
#include "indices.h"
#include <time.h>
#include <cstdio>
#include <string>
#include <fstream>
#include <iostream>
using namespace std;

	Zoo::Zoo() {
		ifstream filezoo;
		filezoo.open("map.txt", ios::in);
		//FILE *fp;
		string brs;
		int bwh=0;
		int samping=0;
		int bk=0;
		int i;
		Indices **temp;
		
		if (filezoo.is_open()) {
			/*
			fp = fopen("zoo.txt", "r");
			fgets(brs,sizeof(brs),fp);
			*/
			
			filezoo >> brs;
			for(i=0; i<brs.length(); i++) {
				bwh = (bwh*10)+ ((int) brs[i] -48); 
			}
			
			//fgets(brs, sizeof(brs); i++);
			filezoo >> brs;
			for (i=0; i<brs.length(); i++) {
				samping = (samping*10) + ((int) brs[i] -48);
			}
			
			//fgets(brs,sizeof(brs); i++);
			filezoo >> brs;
			for (i=0; i<brs.length(); i++) {
				bk = (bk*10) + ((int) brs[i] -48);
			}
			
			temp = new Indices *[bk];
			for (i=0; i<bk; i++){
				temp[i]= new Indices [25]; //constraint: maksimal habitat dalam satu cage adalah 25
			}
			
			lebar = bwh;
			panjang = samping;
			map = new Cell** [lebar];
			for (i=0; i<lebar; i++) {
				map[i] = new Cell* [panjang];
			}
		
			banyak_kandang = bk;
			int *neff_kandang;
			neff_kandang = new int [bk];
			for (i=0; i<banyak_kandang; i++) {
				neff_kandang[i] = 0;
			}
			char habitat;
			int code;
		
			Indices ind(0,0);
			for (int i=0; i<bwh; i++) {
				//fgets(brs, sizeof(brs),fp);
				filezoo >> brs;
				int j=0;
				int k=0;
				while (j<samping*2) {
					I.SetAbsis(k);
					I.SetOrdinat(i);
					habitat = brs[j];
					if (habitat == 'W') {
						map[i][k] = new WaterHabitat(I);
					} else
					if (habitat == 'L') {
						map[i][k] = new LandHabitat(I); 
					} else
					if (habitat == 'A') {
						map[i][k] = new AirHabitat(I);
					} else
					if (habitat == '-') {
						map[i][k] = new Road(I);
					} else
					if (habitat == '+') {
						map[i][k] = new Road(I);
					} else
					if (habitat == '=') {
						map[i][k] = new Road(I);
					} else
					if (habitat == 'P') {
						map[i][k] = new Park(I);
					} else
					if (habitat == 'R') {
						map[i][k] = new Restaurant(I); 
					} else{
						
					}
					j++;
					k++;
				
					code = ((int) brs[j] -48);
					if (code != 0) {
						temp[code-1][neff_kandang[code-1]] = I;
						neff_kandang[code-1]++;
					}
				
					j++;
				}
			}
			filezoo.close();
			daftar_kandang = new Cage[banyak_kandang];
			Indices *temp_i;
            //TempI =  new Indices [25];
			for (i=0; i<banyak_kandang; i++) {
                temp_i =  new Indices [25];
				for (int j=0; j<neff_kandang[i]; j++) {
					temp_i[j] = temp[i][j];
				}
				cout << "a";
				Cage c(temp_i,neff_kandang[i]);
				cout << "b";
				cout << "b";
				cout << "b";
				daftar_kandang[i] = c;
				cout << "c";
				c.~Cage();
                delete [] temp_i;
			}
			
			base_map = new char* [lebar];
            ready_to_print = new char *[lebar];
			for (i=0; i<lebar; i++) {
				base_map[i] = new char [panjang];
                ready_to_print[i] = new char [panjang];
			}
		
			for (i=0; i<lebar; i++) {
				for (int j=0; j<panjang; j++) {
					base_map[i][j] = map[i][j]->Render();
                    ready_to_print[i][j] = base_map[i][j];
				}
			}
			
			Animals** pa;
			pa = new Animals* [37];
			int i = 0;
			//Cage 1
			pa[i] = new Beluga(45,2,2);
			daftar_kandang[0].AddAnimal(pa[i]);
			i++;
			pa[i] = new Dolphin(45,1,1);
			daftar_kandang[0].AddAnimal(pa[i]);
			i++;
			pa[i] = new Swan(45,0,0);
			daftar_kandang[0].AddAnimal(pa[i]);
			i++;
			//Cage 2
			pa[i] = new Cockatoo(10,19,0);
			daftar_kandang[1].AddAnimal(pa[i]);
			i++;
			pa[i] = new Cockatoo(10,8,2);
			daftar_kandang[1].AddAnimal(pa[i]);
			i++;
			pa[i] = new Parrots(10,17,0);
			daftar_kandang[1].AddAnimal(pa[i]);
			i++;
			//Cage 3
			pa[i] = new Lion(100, 1, 4);
			daftar_kandang[2].AddAnimal(pa[i]);
			i++;
			pa[i] = new Lion(100, 1, 5);
			daftar_kandang[2].AddAnimal(pa[i]);
			i++;
			//Cage 4
			pa[i] = new Cassowary(70, 6, 4);
			daftar_kandang[3].AddAnimal(pa[i]);
			i++;
			pa[i] = new Monkey(30, 6, 6);
			daftar_kandang[3].AddAnimal(pa[i]);
			i++;
			pa[i] = new Deer(60, 7, 5);
			daftar_kandang[3].AddAnimal(pa[i]);
			i++;
			pa[i] = new Lemur(30,5,7);
			daftar_kandang[3]. AddAnimal(pa[i]);
			i++;
			//Cage 5
			pa[i] = new Giraffe(100,14,4);
			daftar_kandang[4].AddAnimal(pa[i]);
			i++;
			pa[i] = new Meerkat(30, 14, 6);
			daftar_kandang[4].AddAnimal(pa[i]);
			i++;
			pa[i] = new Owl(10, 16, 4);
			daftar_kandang[4].AddAnimal(pa[i]);
			i++;
			pa[i] = new Chameleon(15, 12, 6);
			daftar_kandang[4].AddAnimal(pa[i]);
			i++;
			//Cage 6
			pa[i] = new Wolf(70, 18, 8);
			daftar_kandang[5].AddAnimal(pa[i]);
			i++;
			pa[i] = new Wolf(70, 19, 6);
			daftar_kandang[5].AddAnimal(pa[i]);
			i++;			
			//Cage 7
			pa[i] = new Gorilla(100, 10, 12);
			daftar_kandang[6].AddAnimal(pa[i]);
			i++;
			pa[i] = new Duck(10, 14, 11);
			daftar_kandang[6].AddAnimal(pa[i]);
			i++;
			pa[i] = new Swan(10, 12, 12);
			daftar_kandang[6].AddAnimal(pa[i]);
			i++;
			//Cage 8
			pa[i] = new Orca(150, 5, 19);
			daftar_kandang[7].AddAnimal(pa[i]);
			i++;
			pa[i] = new Orca(150, 7, 16);
			daftar_kandang[7].AddAnimal(pa[i]);
			i++;
			//Cage 9
			pa[i] = new Python(100, 11, 18);
			daftar_kandang[8].AddAnimal(pa[i]);
			i++;
			pa[i] = new Python(100, 12, 16);
			daftar_kandang[8].AddAnimal(pa[i]);
			i++;
			pa[i] = new Python(100, 12, 19);
			daftar_kandang[8].AddAnimal(pa[i]);
			i++;
			/*
			pa[i] = new Lion(70, 0, 4);
			i++;
			daftar_kandang[2].AddAnimal(pa[3]);
			pa[i] = new Giraffe(100, 1, 4);
			daftar_kandang[2].AddAnimal(pa[4]);
			
			
			for (i=0; i<banyak_kandang; i++) {
				for (int j=0; j<daftar_kandang[i].GetBanyakHewan(); j++) {
					ready_to_print[daftar_kandang[i].GetAnimals()[j]->GetKoordinat().GetOrdinat()][daftar_kandang[i].GetAnimals()[j]->GetKoordinat().GetAbsis()] = daftar_kandang[i].GetAnimals()[j]->Render();
				}
			}
             */
		}
	}
	
	Zoo::~Zoo() {
		for (int i=0; i<lebar; i++) {
			delete [] map[i];
		}
		delete [] map;
		delete [] daftar_kandang;
		for (int i=0; i<lebar; i++) {
			delete [] base_map[i];
		}
		delete [] base_map;
	}

void Zoo::Move(){
	srand(time(NULL));
    bool move;
    Indices ind;
    int count,x,y,to,tox,toy;
    for (int i=0; i<banyak_kandang; i++) {
        for (int j=0; j<daftar_kandang[i].GetBanyakHewan(); j++) {
            move= false;
            count = 0;
            x = (daftar_kandang[i].GetAnimals()[j])->GetKoordinat().GetAbsis();
            y = (daftar_kandang[i].GetAnimals()[j])->GetKoordinat().GetOrdinat();
            to = (rand() % 3) +1;
            while ((!(move)) && (count<4)){
                tox = x; toy = y;
                count++;
                switch (to)
                {
                    case 1 : {tox++;}; break;
                    case 2 : {toy++;}; break;
                    case 3 : {tox--;}; break;
                    case 4 : {toy--;}; break;
                    
                }
                if ((toy>=0) && (toy<lebar) && (tox >=0) && (tox <panjang)) {
					ind.SetOrdinat(toy); ind.SetAbsis(tox);
					if (((daftar_kandang[i].GetAnimals()[j])->IsLivable(*map[toy][tox])) && 
					   (daftar_kandang[i].IsHostOf(ind)) &&
					   ((ready_to_print[toy][tox] == 'w') || (ready_to_print[toy][tox] == 'l') || (ready_to_print[toy][tox] == 'a'))) {
						move = true;
						(daftar_kandang[i].GetAnimals()[j])->SetKoordinat(tox, toy);
						ready_to_print[y][x] = base_map[y][x];
						ready_to_print[toy][tox] = (daftar_kandang[i].GetAnimals()[j])->Render();
					} else {
						to = (to%4) + 1;
					}
				} else {
					to = (to%4) + 1;
				}
            }        
        }
    }
}
void Zoo::Print(){
    for(int i=0; i<lebar; i++) {
        for(int j=0; j<panjang; j++) {
            cout<<ready_to_print[i][j] << " ";
        }
        cout<< endl;
    }
}

void Zoo::HitungMakanan(){
    int sayur_buah_dan_biji2an=0;
    int daging=0;
    int i,j;
    for (i = 0; i<banyak_kandang; i++) {
        for (j = 0; j<daftar_kandang[i].GetBanyakHewan(); j++) {
            if (daftar_kandang[i].GetAnimals()[j]->GetMakanan() == 0) {
                sayur_buah_dan_biji2an = sayur_buah_dan_biji2an + (daftar_kandang[i].GetAnimals()[j]->GetBerat() * 3 / 100);
            } else
            if (daftar_kandang[i].GetAnimals()[j]->GetMakanan() == 1) {
                sayur_buah_dan_biji2an = sayur_buah_dan_biji2an + (daftar_kandang[i].GetAnimals()[j]->GetBerat() * 3 / 200);
                daging = daging + (daftar_kandang[i].GetAnimals()[j]->GetBerat() * 3 / 200);
            } else
            if (daftar_kandang[i].GetAnimals()[j]->GetMakanan() == 2) {
                daging = daging + (daftar_kandang[i].GetAnimals()[j]->GetBerat() * 3 / 100);
            }
        }
    }
    
    cout << "Butuh daging sebanyak " << daging << "kg." << endl;
    cout << "Butuh sayur, buah, dan biji-bijian sebanyak " << sayur_buah_dan_biji2an << "kg." << endl;
}

Cage* Zoo::GetKandang() {
	return daftar_kandang;
}

bool Zoo::IsInteractable(Indices ind, Cage c) {
	bool iya = false;
	int i = 0;
	Indices it;
	It.SetAbsis(ind.GetAbsis()+1); it.SetOrdinat(ind.GetOrdinat());
	iya = (c.IsHostOf(it));
	if (!iya) {
		it.SetAbsis(ind.GetAbsis()-1); it.SetOrdinat(ind.GetOrdinat());
		iya = (C.IsHostOf(it));
	}
	if (!iya) {
		it.SetAbsis(ind.GetAbsis()); it.SetOrdinat(ind.GetOrdinat()+1);
		iya = (C.IsHostOf(it));
	}
	if (!iya) {
		it.SetAbsis(ind.GetAbsis()); it.SetOrdinat(ind.GetOrdinat()-1);
		iya = (C.IsHostOf(it));
	}
	return iya;
}

