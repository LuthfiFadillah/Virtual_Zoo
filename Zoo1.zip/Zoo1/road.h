//file Road.h
#ifndef ROAD_H
#define ROAD_H
#include "cell.h"
#include "facility.h"
#include "indices.h"

class Road: public Facility {
public:
	//Road();
	Road(Indices ind);
	//Road(Road& R);
	~Road();
	//Road& operator= (Road& R);
	char Render();
};

#endif
