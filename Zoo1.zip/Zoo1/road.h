#ifndef ROAD_H
#define ROAD_H
#include "cell.h"
#include "facility.h"
#include "indices.h"
class Road : public Facility {
public:
  Road(Indices ind);
  ~Road();
  char Render();
};
#endif