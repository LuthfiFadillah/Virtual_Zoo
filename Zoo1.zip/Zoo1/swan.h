#ifndef SWAN_H
#define SWAN_H
#include "anseriformes.h"
#include "animals.h"
#include "indices.h"

class Swan:public Anseriformes{
//method
public:
	//ctor with param
	Swan(int bb,int x, int y);
	//destructor
	//polymorphism interaksi
	void Interact();
	char Render();
};
#endif
