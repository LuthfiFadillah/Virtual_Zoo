#ifndef SWAN_H
#define SWAN_H
#include "anseriformes.h"
#include "animals.h"
#include "indices.h"
class Swan : public Anseriformes {
public:
  Swan(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif