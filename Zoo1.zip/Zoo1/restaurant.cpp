#include "cell.h"
#include "facility.h"
#include "restaurant.h"
#include "indices.h"
#include <iostream>
using namespace std;
  Restaurant::Restaurant(Indices ind) : Facility(ind, 2, 'r') {}
  Restaurant::~Restaurant() {}
  char Restaurant::Render() {
    return 'R';
  }