//file Restaurant.cpp
#include "cell.h"
#include "facility.h"
#include "restaurant.h"
#include "indices.h"
#include <iostream>
using namespace std;

	//Road();
	Restaurant::Restaurant(Indices ind): Facility(ind, 2, 'r') {}
	//Road(Road& R);
	Restaurant::~Restaurant() {}
	//Road& operator= (Road& R);
	char Restaurant::Render() {
		return 'R';
	}
