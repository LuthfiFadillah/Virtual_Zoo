#ifndef HABITAT_H
#define HABITAT_H
#include "cell.h"
#include "renderable.h"
#include "indices.h"
class Habitat : public Cell {
public:
  Habitat(Indices ind, int type, char code);
  bool IsLand();
  bool IsWater();
  bool IsAir();
protected:
  const int hType;
};
#endif