#ifndef DOLPHIN_H
#define DOLPHIN_H
#include "cetacea.h"
#include "animals.h"
#include "indices.h"

class Dolphin:public Cetacea{
//method
public:
	//ctor with param
	Dolphin(int bb,int x, int y);
	
	//polymorphism interaksi
	void Interact();
	
	char Render();
};
#endif
