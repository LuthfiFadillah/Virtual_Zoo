#ifndef DOLPHIN_H
#define DOLPHIN_H
#include "cetacea.h"
#include "animals.h"
#include "indices.h"
class Dolphin : public Cetacea {
public:
  Dolphin(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif