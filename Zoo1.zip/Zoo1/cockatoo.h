#ifndef COCKATOO_H
#define COCKATOO_H
#include "psittaciformes.h"
#include "animals.h"
#include "indices.h"
class Cockatoo : public Psittaciformes {
public:
  Cockatoo(int bb, int x, int y);
  void Interact();
  char Render();
};
#endif