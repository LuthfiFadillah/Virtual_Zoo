#ifndef COCKATOO_H
#define COCKATOO_H
#include "psittaciformes.h"
#include "animals.h"
#include "indices.h"

class Cockatoo:public Psittaciformes{
//method
public:
	//ctor with param
	Cockatoo(int bb,int x, int y);
	
	//polymorphism interaksi
	void Interact();
	
	char Render();

};
#endif
