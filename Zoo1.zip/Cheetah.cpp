#include "Cheetah.h"
#include "Carnivora.h"
#include "Indices.h"
#include "Animals.h"
#include <iostream>
using namespace std;

//class Cheetah: public Carnivora {
//method

	//ctor with param
	Cheetah::Cheetah(int bb,int x, int y) : Carnivora(false,x,y) {
		SetBerat(bb);
	}
	//destructor
	//polymorphism interaksi
	void Cheetah::Interact() {
		cout << "*run fast*" << endl;
	}
	char Cheetah::Render() {
		return 'T';
	}
