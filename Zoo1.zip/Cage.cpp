#include "Cage.h"
#include "Animals.h"
//#include "Habitat.h"
#include "Indices.h"
#include <iostream>
using namespace std;

	Cage::Cage() {
		
	}
	
	Cage::Cage(Indices *I,int Neff){
		Wilayah = new Indices[Neff];
		for (int i=0; i< Neff; i++) {
			Wilayah[i] = I[i];
		}
		Luas = Neff;
		BanyakHewan = 0;
		DataAnimals = new Animals*[(Neff*3)/10];
	}
	
	Cage::~Cage(){
		//delete [] Wilayah;
		//delete [] DataAnimals;
		Luas =0;
	}

    Cage& Cage::operator= (const Cage& C){
        int i;
        Luas = C.Luas;
        BanyakHewan = C.BanyakHewan;
        if (this != &C) {
            //delete [] Wilayah;
            Wilayah = new Indices[Luas];
            for (i=0; i<Luas; i++) {
                Wilayah[i] = C.Wilayah[i];
            }
            //delete [] DataAnimals;
            DataAnimals = new Animals* [BanyakHewan];
            for (i=0; i<BanyakHewan; i++) {
                DataAnimals[i] = C.DataAnimals[i];
            }
        }
        return *this;
    }

	bool Cage::IsHostOf(Indices I){
		bool ketemu = false;
		int i=0;
		
		while ((i<Luas) && (!(ketemu))) {
			ketemu = (I.IsEqual(Wilayah[i]));
			i++; 
		}
		
		return ketemu;
	}
	
	bool Cage::Spacious() {
		return (BanyakHewan <= (Luas*3)/10) ;
	}
	
	void Cage::AddAnimal(Animals* A){
		Indices I(A->GetKoordinat().GetAbsis(), A->GetKoordinat().GetOrdinat());
		if (IsHostOf(I)) {
			if (Spacious()) {
				if (!(A->IsJinak())) {
					if (BanyakHewan == 0) {
						DataAnimals[BanyakHewan] = A;
						BanyakHewan++;
					} else {
						if (A->Render() == DataAnimals[0]->Render()) {
							DataAnimals[BanyakHewan] = A;
							BanyakHewan++;
						}
					}
				} else {
					DataAnimals[BanyakHewan] = A;
					BanyakHewan++;
				}
			} else {
				cout<< "Penuh couyyy" << endl;
			}
		}
	}
	
	void Cage::Inter()  {
		for (int i=0; i<BanyakHewan; i++) {
			DataAnimals[i]->Interact();
		}
	}
	
	bool Cage::IsCageOf(Animals* A) {
		int i = 0;
		bool ketemu = (DataAnimals[i] == A);
		while (!ketemu && (i<BanyakHewan)) {
			ketemu = (DataAnimals[i] == A);
			i++;
		}
        return ketemu;
	}

Animals ** Cage::GetAnimals(){
    return DataAnimals;
}
int Cage::GetLuas(){
    return Luas;
}
int Cage::GetBanyakHewan(){
    return BanyakHewan;
}
