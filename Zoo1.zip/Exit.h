#ifndef EXIT_H
#define EXIT_H
#include "Cell.h"
#include "Facility.h"
#include "Road.h"

class Exit:public Road{
public:

protected:

};
#endif
