#include "Psittaciformes.h"
#include "Animals.h"
#include "Cockatoo.h"
#include <iostream>
using namespace std;

	//ctor with param
	Cockatoo::Cockatoo(int bb,int x, int y): Psittaciformes(true,x,y) {
		SetBerat(bb);
	}
	
	//polymorphism interaksi
	void Cockatoo::Interact(){
		cout << "Cockatooo... Cockatooo..." << endl;
		}

	char Cockatoo::Render() {
		return 'O';
	}
