//File: Zoo.cpp
#include "Zoo.h"
#include "Road.h"
#include "Park.h"
#include "Restaurant.h"
#include "WaterHabitat.h"
#include "LandHabitat.h"
#include "AirHabitat.h"
#include "Beluga.h"
#include "BigHornSheep.h"
#include "Cassowary.h"
#include "Chameleon.h"
#include "Cheetah.h"
#include "Cockatoo.h"
#include "Deer.h"
#include "Dolphin.h"
#include "Duck.h"
#include "Giraffe.h"
#include "Gorilla.h"
#include "GreatWhiteShark.h"
#include "Lemur.h"
#include "Lion.h"
#include "Meerkat.h"
#include "Monkey.h"
#include "Orca.h"
#include "Owl.h"
#include "Parrots.h"
#include "Python.h"
#include "Swan.h"
#include "Tarsier.h"
#include "Wolf.h"
#include "Indices.h"
#include <cstdio>
#include <string>
#include <fstream>
#include <iostream>
using namespace std;

	Zoo::Zoo() {
		ifstream filezoo;
		filezoo.open("/Users/aliviaprht/Desktop/Virtual_Zoo/Virtual_Zoo/map.txt", ios::in);
		//FILE *fp;
		string brs;
		int bwh=0;
		int samping=0;
		int BK=0;
		int i;
		Indices **Temp;
		
		if (filezoo.is_open()) {
			/*
			fp = fopen("zoo.txt", "r");
			fgets(brs,sizeof(brs),fp);
			*/
			
			filezoo >> brs;
			for(i=0; i<brs.length(); i++) {
				bwh = (bwh*10)+ ((int) brs[i] -48); 
			}
			
			//fgets(brs, sizeof(brs); i++);
			filezoo >> brs;
			for (i=0; i<brs.length(); i++) {
				samping = (samping*10) + ((int) brs[i] -48);
			}
			
			//fgets(brs,sizeof(brs); i++);
			filezoo >> brs;
			for (i=0; i<brs.length(); i++) {
				BK = (BK*10) + ((int) brs[i] -48);
			}
			
			Temp = new Indices *[BK];
			for (i=0; i<BK; i++){
				Temp[i]= new Indices [25]; //constraint: maksimal habitat dalam satu cage adalah 25
			}
			
			Lebar = bwh;
			Panjang = samping;
			Map = new Cell** [Lebar];
			for (i=0; i<Lebar; i++) {
				Map[i] = new Cell* [Panjang];
			}
		
			BykKandang = BK;
			int *NeffKandang;
			NeffKandang = new int [BK];
			for (i=0; i<BykKandang; i++) {
				NeffKandang[i] = 0;
			}
			char habitat;
			int code;
		
			Indices I(0,0);
			for (int i=0; i<bwh; i++) {
				//fgets(brs, sizeof(brs),fp);
				filezoo >> brs;
				int j=0;
				int k=0;
				while (j<samping*2) {
					I.set_absis(k);
					I.set_ordinat(i);
					habitat = brs[j];
					if (habitat == 'W') {
						Map[i][k] = new WaterHabitat(I);
					} else
					if (habitat == 'L') {
						Map[i][k] = new LandHabitat(I); 
					} else
					if (habitat == 'A') {
						Map[i][k] = new AirHabitat(I);
					} else
					if (habitat == '-') {
						Map[i][k] = new Road(I);
					} else
					if (habitat == '+') {
						Map[i][k] = new Road(I);
					} else
					if (habitat == '=') {
						Map[i][k] = new Road(I);
					} else
					if (habitat == 'P') {
						Map[i][k] = new Park(I);
					} else
					if (habitat == 'R') {
						Map[i][k] = new Restaurant(I); 
					} else{
						
					}
					j++;
					k++;
				
					code = ((int) brs[j] -48);
					if (code != 0) {
						Temp[code-1][NeffKandang[code-1]] = I;
						NeffKandang[code-1]++;
					}
				
					j++;
				}
			}
			filezoo.close();
			DaftarKandang = new Cage[BykKandang];
			Indices *TempI;
            //TempI =  new Indices [25];
			for (i=0; i<BykKandang; i++) {
                TempI =  new Indices [25];
				for (int j=0; j<NeffKandang[i]; j++) {
					TempI[j] = Temp[i][j];
				}
				Cage C(TempI,NeffKandang[i]);
				DaftarKandang[i] = C;
				C.~Cage();
                delete [] TempI;
			}
			
			base_map = new char* [Lebar];
            ready_to_print = new char *[Lebar];
			for (i=0; i<Lebar; i++) {
				base_map[i] = new char [Panjang];
                ready_to_print[i] = new char [Panjang];
			}
		
			for (i=0; i<Lebar; i++) {
				for (int j=0; j<Panjang; j++) {
					base_map[i][j] = Map[i][j]->Render();
                    ready_to_print[i][j] = base_map[i][j];
				}
			}
			
			Animals** PA;
			PA = new Animals* [37];
			int i = 0;
			//Cage 1
			PA[i] = new Beluga(45,2,2);
			DaftarKandang[0].AddAnimal(PA[i]);
			i++;
			PA[i] = new Dolphin(45,1,1);
			DaftarKandang[0].AddAnimal(PA[i]);
			i++;
			PA[i] = new Swan(45,0,0);
			DaftarKandang[0].AddAnimal(PA[i]);
			i++;
			//Cage 2
			PA[i] = new Cockatoo(10,19,0);
			DaftarKandang[1].AddAnimal(PA[i]);
			i++;
			PA[i] = new Parrots(10,17,0);
			DaftarKandang[1].AddAnimal(PA[i]);
			i++;
			//Cage 3
			PA[i] = new Lion(100, 1, 4);
			DaftarKandang[2].AddAnimal(PA[i]);
			i++;
			//Cage 4
			PA[i] = new Cassowary(70, 6, 4);
			DaftarKandang[3].AddAnimal(PA[i]);
			i++;
			PA[i] = new Monkey(30, 6, 6);
			DaftarKandang[3].AddAnimal(PA[i]);
			i++;
			PA[i] = new Deer(60, 7, 5);
			DaftarKandang[3].AddAnimal(PA[i]);
			i++;
			PA[i] = new Lemur(30,5,7);
			DaftarKandang[3]. AddAnimal(PA[i]);
			i++;
			//Cage 5
			PA[i] = new Giraffe(100,14,4);
			DaftarKandang[4].AddAnimal(PA[i]);
			i++;
			PA[i] = new Meerkat(30, 14, 6);
			DaftarKandang[4].AddAnimal(PA[i]);
			i++;
			PA[i] = new Owl(10, 16, 4);
			DaftarKandang[4].AddAnimal(PA[i]);
			i++;
			PA[i] = new Chameleon(15, 12, 6);
			DaftarKandang[4].AddAnimal(PA[i]);
			i++;
			//Cage 6
			PA[i] = new Wolf(70, 18, 8);
			DaftarKandang[5].AddAnimal(PA[i]);
			i++;
			//Cage 7
			PA[i] = new Gorilla(100, 10, 12);
			DaftarKandang[6].AddAnimal(PA[i]);
			i++;
			PA[i] = new Duck(10, 14, 11);
			DaftarKandang[6].AddAnimal(PA[i]);
			i++;
			//Cage 8
			PA[i] = new Orca(150, 5, 19);
			DaftarKandang[7].AddAnimal(PA[i]);
			i++;
			//Cage 9
			PA[i] = new Python(100, 11, 18);
			DaftarKandang[8].AddAnimal(PA[i]);
			i++;
			/*
			PA[i] = new Lion(70, 0, 4);
			i++;
			DaftarKandang[2].AddAnimal(PA[3]);
			PA[i] = new Giraffe(100, 1, 4);
			DaftarKandang[2].AddAnimal(PA[4]);
			
			
			for (i=0; i<BykKandang; i++) {
				for (int j=0; j<DaftarKandang[i].GetBanyakHewan(); j++) {
					ready_to_print[DaftarKandang[i].GetAnimals()[j]->get_koordinat().get_ordinat()][DaftarKandang[i].GetAnimals()[j]->get_koordinat().get_absis()] = DaftarKandang[i].GetAnimals()[j]->Render();
				}
			}
             */
		}
	}
	
	Zoo::~Zoo() {
		for (int i=0; i<Lebar; i++) {
			delete [] Map[i];
		}
		delete [] Map;
		delete [] DaftarKandang;
		for (int i=0; i<Lebar; i++) {
			delete [] base_map[i];
		}
		delete [] base_map;
	}

void Zoo::Move(){
    bool move;
    Indices I;
    int count,x,y,to,tox,toy;
    for (int i=0; i<BykKandang; i++) {
        for (int j=0; j<DaftarKandang[i].GetBanyakHewan(); j++) {
            move= false;
            count = 0;
            x = (DaftarKandang[i].GetAnimals()[j])->get_koordinat().get_absis();
            y = (DaftarKandang[i].GetAnimals()[j])->get_koordinat().get_ordinat();
            to = (rand() % 3) +1;
            while ((!(move)) && (count<4)){
                tox = x; toy = y;
                count++;
                switch (to)
                {
                    case 1 : {tox++;}; break;
                    case 2 : {toy++;}; break;
                    case 3 : {tox--;}; break;
                    case 4 : {toy--;}; break;
                    
                }
                if ((toy>=0) && (toy<Lebar) && (tox >=0) && (tox <Panjang)) {
					I.set_ordinat(toy); I.set_absis(tox);
					if (((DaftarKandang[i].GetAnimals()[j])->IsLivable(*Map[toy][tox])) && 
					   (DaftarKandang[i].IsHostOf(I))) {
						move = true;
						(DaftarKandang[i].GetAnimals()[j])->set_koordinat(tox, toy);
						ready_to_print[y][x] = base_map[y][x];
						ready_to_print[toy][tox] = (DaftarKandang[i].GetAnimals()[j])->Render();
					} else {
						to = (to%4) + 1;
					}
				} else {
					to = (to%4) + 1;
				}
            }        
        }
    }
}
void Zoo::Print(){
    for(int i=0; i<Lebar; i++) {
        for(int j=0; j<Panjang; j++) {
            cout<<ready_to_print[i][j] << " ";
        }
        cout<< endl;
    }
}
