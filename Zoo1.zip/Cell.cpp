//file Cell.cpp
#include "Cell.h"
#include "Indices.h"

	Cell::Cell(Indices I, int t, char c): Renderable(0), type(t), code(c) { koordinat = I; }
	//Cell::Cell(Cell& C) { Koordinat = C.GetKoordinat(); }
	Cell::~Cell() {}
	//Cell& Cell::operator= (Cell& C) { Koordi}
	char Cell::Render() { return '.'; }
	Indices Cell::GetKoordinat() { return koordinat; }
	bool Cell::IsHabitat() { return (type == 0); }
	bool Cell::IsFacility() { return (type == 1); }
	char Cell::GetCode() { return code; }
