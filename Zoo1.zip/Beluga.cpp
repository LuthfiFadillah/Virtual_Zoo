#include "Cetacea.h"
#include "Animals.h"
#include "Beluga.h"
#include "Indices.h"
#include <iostream>
using namespace std;

	//ctor with param
	Beluga::Beluga(int bb, int x, int y): Cetacea(true,x,y) {
		SetBerat(bb);
	}
	
	//polymorphism interaksi
	void Beluga::Interact() {
		cout << "Ooooooooooooo..." << endl;
	}
		
char Beluga::Render() {
 return 'B';
}
