#include "Zoo.h"
#include <iostream>
using namespace std;

int main() {
	/*try {
		Zoo Z;
	}
	catch (const std::bad_alloc&) {
		return -1;
	}*/
	Zoo Z;
    
    Z.Print();
    Z.Move();
    cout<<endl;
    Z.Print();
    
    Z.Move();
    cout<<endl;
    Z.Print();
    
    Z.Move();
    cout<<endl;
    Z.Print();
    
    Z.Move();
    cout<<endl;
    Z.Print();
    
	return 0;
}
