#include "primates.h"
  /** @brief Constructor dari Primates
    * Menghidupkan hewan Ordo Primates
    *
    * @param x integer adalah letak absis Primates yang dihidupkan
    * @param y integer adalah letak ordinat Primates yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Primates::Primates(bool kejinakan, int x, int y) : 
                     Animals(0, true, false, false, kejinakan, x, y) {}