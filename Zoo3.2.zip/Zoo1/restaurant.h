#ifndef RESTAURANT_H
#define RESTAURANT_H
#include "facility.h"
class Restaurant : public Facility {
public:
  /** @brief Constructor dari Restaurant
    * Menghidupkan fasilitas restauran
    *
    * @param I Indices adalah alamat dimana fasilitas dihidupkan
    */
  Restaurant(Indices ind);
  /** @brief Mengembalikan nilai character kode dari objek Restaurant
    * Character ini nantinya yang siap di Print ke layar
    */
  char Render();
};
#endif