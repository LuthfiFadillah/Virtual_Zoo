#ifndef AIRHABITAT_H
#define AIRHABITAT_H
#include "habitat.h"

class AirHabitat : public Habitat {
public:
  /** @brief Constructor dari Air Habitat
    * Menghidupkan habitat udara
    *
    * @param I Indices adalah alamat dimana habitat dihidupkan
    */
  AirHabitat(Indices ind);
  /** @brief Mengembalikan nilai character kode dari objek Air Habitat
    * Character ini nantinya yang siap di Print ke layar
    */
  char Render();
};

#endif