#include "cage.h"
  
  /** @brief Constructor tanpa parameter dari Cage
    * Menghidupkan kandang
    */
  Cage::Cage() {}
  /** @brief Constructor dengan parameter dari Cage
    * Menghidupkan kandang sesuai dengan input parameter
    *
    * @param I array of Indices menyatakan Cell dengan indices mana saja yang tergabung dalam cage
    * @param Neff integer menyatakan banyaknya Indices yang ada pada array
    */
  Cage::Cage(Indices *i, int neff) {
    wilayah = new Indices[neff];
    for (int i = 0; i < neff; i++) {
	    wilayah[i] = ind[i];
    }
    luas = neff;
    banyak_hewan = 0;
    data_animals = new Animals* [(neff*3) / 10];
  }
  /** @brief Destructor dari Cage
    * Menghilangkan alokasi memori Cage
    */
  Cage::~Cage() {
    luas = 0;
  }
  /** @brief Operator overloading = dari Cage
     * Memastikan bukan bitewise copy
     *
     * @param C menyatakan Cage yang ingin disalin
     */
  Cage& Cage::operator= (const Cage& c) {
    int i;
    luas = c.luas;
    banyak_hewan = c.banyak_hewan;
    if (this != &c) {
      wilayah = new Indices[luas];
      for (i = 0; i < luas; i++) {
        wilayah[i] = c.wilayah[i];
      }
      data_animals = new Animals* [banyak_hewan];
      for (i = 0; i < banyak_hewan; i++) {
        data_animals[i] = c.data_animals[i];
      }
    }
      return *this;
  }
  /** @brief  Mengembalikan nilai boolean apakah indices termasuk pada cangkupan cage
    *
    * @param I adalah indices yang diperiksa sebagai bagian dari cage
    */
  bool Cage::IsHostOf(Indices ind) {
    bool ketemu = false;
    int i = 0;
	  while ((i < luas) && (!ketemu)) {
	    ketemu = (ind.IsEqual(wilayah[i]));
      i++;
    }
    return ketemu;
  }
  /** @brief Mengembalikan nilai boolean apakah masih ada ruang untuk animal di cage tersebut
    */
  bool Cage::Spacious() {
    return (banyak_hewan <= (luas*3) / 10);
  }
  /** @brief Prosedur AddAnimal dari Cage
    * I.S Cage telah hidup dan Masukkan terdefinisi sebagai hewan yang hidup
    * F.S Animal A tercatat pada Data Animals Cage
    * Menambahkan Animals A pada Data Animals Cage
    *
    * @param A adalah Pointer to Animals yang ingin dimasukkan di Data Animals
    */
  void Cage::AddAnimal(Animals* a) {
    Indices ind(a->GetKoordinat().GetAbsis(), a->GetKoordinat().GetOrdinat());
    if (IsHostOf(ind)) {
      if (Spacious()) {
        if (!(a->IsJinak())) {
          if (banyak_hewan == 0) {
            data_animals[banyak_hewan] = a;
            banyak_hewan++;
          } 
          else {
            if (a->Render() == data_animals[0]->Render()) {
              data_animals[banyak_hewan] = a;
              banyak_hewan++;
            }
		      }
		    }
		    else {
          data_Animals[banyak_hewan] = a;
          banyak_hewan++;
        }
      }
    }
  }
  /** @brief Prosedur Inter dari Cage
    * I.S Cage terdefinisi
    * F.S Memanggil semua prosedur interact dari animals yang ada di Cage
    * Mencetak semua suara binatang yang ada dalam kandang
    */
  void Cage::Inter() {
    for (int i = 0; i < banyak_hewan; i++) {
	    data_animals[i]->Interact();
    }
  }
  /** @brief Mengembalikan nilai boolean apakah animals tinggal di kandang tersebut
    * 
    * @param A adalah Pointer to Animals yang diperiksa
    */
  bool Cage::IsCageOf(Animals* a) {
    int i = 0;
    bool ketemu = (data_animals[i] == a);
    while (!ketemu && (i < banyak_hewan)) {
	    ketemu = (data_animals[i] == a);
      i++;
    }
    return ketemu;
  }
  /** @brief Mengembalikan nilai atribut DataAnimals
    */
  Animals ** Cage::GetAnimals() {
    return data_animals;
  }
  /** @brief GetLuas dari cage
    * Mengembalikan nilai luas suatu kandang
    */
  int Cage::GetLuas() {
    return luas;
  }
  /** @brief GetBanyakHewan dari Cage
    * Mengembalikan nilai banyaknya hewan yang ada di suatu kandang
    */
  int Cage::GetBanyakHewan() {
    return banyak_hewan;
  }