#ifndef BELUGA_H
#define BELUGA_H
#include "cetacea.h"
class Beluga : public Cetacea {
public:
  /** @brief Constructor dari Beluga
    * Menghidupkan hewan Beluga
    *
    * @param x integer adalah letak absis Beluga yang dihidupkan
    * @param y integer adalah letak ordinat Beluga yang dihidupkan
    * @param bb integer adalah berat badan Beluga yang dihidupkan
    */
  Beluga(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Beluga
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Beluga ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Beluga
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif