#include "facility.h"

  /** @brief Constructor dari Facility
    * Menghidupkan fasilitas
    *
    * @param I Indices adalah alamat dimana fasilitas dihidupkan
    * @param type integer adalah kode dari fasilitas dimana 0=Road, 1=Park, 2=Restaurant
    * @param code character adalah suatu huruf untuk merepresentasikan fasilitas di layar.
    */
  Facility::Facility(Indices ind, int type, char code) :
                     Cell(ind, 1, code), fType(type) {

  }
  /** @brief Mengembalikan nilai boolean apakah fasilitas adalah road
    */
  bool Facility::IsRoad() {
  	return (fType == 0);
  }
  /** @brief Mengembalikan nilai boolean apakah fasilitas adalah park
    */
  bool Facility::IsPark() {
  	return (fType == 1);
  }
  /** @brief Mengembalikan nilai boolean apakah fasilitas adalah restaurant
    */
  bool Facility::IsRestaurant() {
  	return (fType == 2);
  }