#ifndef RENDERABLE_H
#define RENDERABLE_H
class Renderable {
public:
  Renderable(int t);
  virtual char Render() = 0;
  bool IsCell();
  bool IsAnimal();
  const int ty;
};
#endif