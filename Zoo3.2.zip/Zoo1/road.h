#ifndef ROAD_H
#define ROAD_H
#include "facility.h"
class Road : public Facility {
public:
  /** @brief Constructor dari Road
    * Menghidupkan fasilitas jalan
    *
    * @param I Indices adalah alamat di mana fasilitas dihidupkan
    */
  Road(Indices ind);
  /** @brief Mengembalikan nilai character kode dari objek Road
    * Character ini nantinya yang siap di Print ke layar
    */
  char Render();
private:
  /** @brief Atribut jenis Road
    */
  int rtype;
};
#endif