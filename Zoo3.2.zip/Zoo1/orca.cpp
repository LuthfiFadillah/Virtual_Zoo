#include "orca.h"
#include <iostream>
using namespace std;
  /** @brief Constructor dari Orca
    * Menghidupkan hewan Orca
    *
    * @param x integer adalah letak absis Orca yang dihidupkan
    * @param y integer adalah letak ordinat Orca yang dihidupkan
    * @param bb integer adalah berat badan Orca yang dihidupkan
    */
  Orca::Orca(int bb, int x, int y): Cetacea(false, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Orca
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Orca ke layar
    */
  void Orca::Interact() {
    cout << "*WWUSHHHO" << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Orca
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Orca::Render() {
    return '$';
  }