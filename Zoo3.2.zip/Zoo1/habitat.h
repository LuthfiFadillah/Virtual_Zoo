#ifndef HABITAT_H
#define HABITAT_H
#include "cell.h"
class Habitat : public Cell {
public:
  /** @brief Constructor dari Habitat
    * Menghidupkan habitat
    *
    * @param I Indices adalah alamat dimana habitat dihidupkan
    * @param type integer adalah kode dari habitat dimana 0=Land, 1=Water, 2=Air
    * @param code character adalah suatu huruf untuk merepresentasikan habitat di layar.
    */
  Habitat(Indices ind, int type, char code);
  /** @brief Mengembalikan nilai boolean apakah habitat adalah land
    */
  bool IsLand();
  /** @brief Mengembalikan nilai boolean apakah habitat adalah water
    */
  bool IsWater();
  /** @brief Mengembalikan nilai boolean apakah habitat adalah air
    */
  bool IsAir();
protected:
  /** @brief Attribut Htype yang adalah type dari habitat
    */
  const int hType;
};
#endif