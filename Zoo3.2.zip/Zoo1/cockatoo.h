#ifndef COCKATOO_H
#define COCKATOO_H
#include "psittaciformes.h"
class Cockatoo : public Psittaciformes {
public:
  /** @brief Constructor dari Cockatoo
    * Menghidupkan hewan Cockatoo
    *
    * @param x integer adalah letak absis Cockatoo yang dihidupkan
    * @param y integer adalah letak ordinat Cockatoo yang dihidupkan
    * @param bb integer adalah berat badan Cockatoo yang dihidupkan
    */
  Cockatoo(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Cockatoo
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Cockatoo ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Cockatoo
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif