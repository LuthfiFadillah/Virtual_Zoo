#include "chameleon.h"
#include <iostream>
using namespace std;
  
  /** @brief Constructor dari Chameleon
    * Menghidupkan hewan Chameleon
    *
    * @param x integer adalah letak absis Chameleon yang dihidupkan
    * @param y integer adalah letak ordinat Chameleon yang dihidupkan
    * @param bb integer adalah berat badan Chameleon yang dihidupkan
    */
  Chameleon::Chameleon(int bb, int x, int y) : Squamata(false, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Chameleon
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Chameleon ke layar
    */
  void Chameleon::Interact() {
    cout << "Smisshy slimi skinny\n" << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Chameleon
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Chameleon::Render() {
   return 'H';
  }