#include "air_habitat.h"

  AirHabitat::AirHabitat(Indices ind) : Habitat(ind, 2 , 'a') {}
  char AirHabitat::Render() {
    return 'a';
  }