#include "indices.h"
#include <iostream>
using namespace std;
  
  /** @brief Constructor tanpa parameter dari Indices
    * Menghidupkan indeks
    */
  Indices::Indices() {
    x=0;
    y=0;
  }
  /** @brief Constructor dengan parameter dari Indices
    * Menghidupkan indeks sesuai parameter
    *
    * @param x integer adalah absis yang akan di set
    * @param y integer adalah ordinat yang akan di set
    */
  Indices::Indices(int absis, int ordinat) {
    Indices::x = absis; Indices::y = ordinat;
  }
  /** @brief Copy Constructor dari Indices
    * Menghidupkan indeks dengan atribut yang sama seperti indeks yang lain
    */
  Indices::Indices(Indices& ind) {
    x = ind.GetAbsis();
    y = ind.GetOrdinat();
  }
  /** @brief Destructor dari Indices
    * Mengembalikan alokasi memori Indices ke sistem
    */
  Indices::~Indices() {}
  Indices& Indices::operator= (Indices& ind) {
    Indices::x = ind.x;
    Indices::y = ind.y;
    return *this;
  }
  /** @brief Operator overloading = dari Indices
    * Memastikan bukan bitewise copy
    *
    * @param I menyatakan Indices yang ingin disalin
    */
  int Indices::GetAbsis() {
    return x;
  }
  /** @brief GetAbsis dari Indices
    * Mengembalikan nilai absis dari indeks
    *
    */
  int Indices::GetOrdinat() {
    return y;
  }
  /** @brief GetOrdinat dari Indices
    * Mengembalikan nilai ordinat dari indeks
    *
    */
  void Indices::SetAbsis(int absis) {
    x = absis;
  }
  /** @brief Prosedur SetAbsis dari Indices
    * I.S Indices sudah hidup dan masukan terdefinisi
    * F.S Absis indices nilai menjadi masukan
    *
    * @param x integer adalah nilai absis yang akan di set
    */
  void Indices::SetOrdinat(int ordinat) {
    y = ordinat;
  }	
  /** @brief Prosedur SetOrdinat dari Indices
    * I.S Indices sudah hidup dan masukan terdefinisi
    * F.S Ordinat indices nilai menjadi masukan
    *
    * @param y integer adalah nilai ordinat yang akan di set
    */
  bool Indices::IsEqual(const Indices& ind) {
    return ((ind.x == x) && (ind.y == y));
  }