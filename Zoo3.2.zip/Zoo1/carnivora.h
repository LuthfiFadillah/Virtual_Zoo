#ifndef CARNIVORA_H
#define CARNIVORA_H
#include "animals.h"
class Carnivora : public Animals {
public:
  /** @brief Constructor dari Carnivora
    * Menghidupkan hewan Ordo Carnivora
    *
    * @param x integer adalah letak absis Carnivora yang dihidupkan
    * @param y integer adalah letak ordinat Carnivora yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Carnivora(bool kejinakan, int x, int y);
};
#endif