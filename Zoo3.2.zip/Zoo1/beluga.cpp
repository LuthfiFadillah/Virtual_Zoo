#include "cetacea.h"
#include "animals.h"
#include "beluga.h"
#include "indices.h"
#include <iostream>
using namespace std;
  /** @brief Constructor dari Beluga
    * Menghidupkan hewan Beluga
    *
    * @param x integer adalah letak absis Beluga yang dihidupkan
    * @param y integer adalah letak ordinat Beluga yang dihidupkan
    * @param bb integer adalah berat badan Beluga yang dihidupkan
    */
  Beluga::Beluga(int bb, int x, int y) : Cetacea(true,x,y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Beluga
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Beluga ke layar
    */
  void Beluga::Interact() {
    cout << "Ooooooooooooo..." << endl;
   }
   /** @brief Mengembalikan nilai character kode dari objek Beluga
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Beluga::Render() {
    return 'B';
  }