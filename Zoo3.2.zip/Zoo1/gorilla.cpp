#include "gorilla.h"
#include <iostream>
using namespace std;
  /** @brief Constructor dari Gorilla
    * Menghidupkan hewan Gorilla
    *
    * @param x integer adalah letak absis Gorilla yang dihidupkan
    * @param y integer adalah letak ordinat Gorilla yang dihidupkan
    * @param bb integer adalah berat badan Gorilla yang dihidupkan
    */
  Gorilla::Gorilla(int bb, int x, int y) : Primates(true, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Gorilla
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Gorilla ke layar
    */
  void Gorilla::Interact(){
    cout << "*thump thump*" << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Gorilla
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Gorilla::Render() {
    return 'J';
  }