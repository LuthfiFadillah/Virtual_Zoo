#include "deer.h"
#include <iostream>
using namespace std;

  /** @brief Constructor dari Deer
    * Menghidupkan hewan Deer
    *
    * @param x integer adalah letak absis Deer yang dihidupkan
    * @param y integer adalah letak ordinat Deer yang dihidupkan
    * @param bb integer adalah berat badan Deer yang dihidupkan
    */
  Deer::Deer(int bb, int x, int y): Artiodactyls(true, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Deer
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Deer ke layar
    */
  void Deer::Interact(){
    cout << "Do you know where is santa house??" << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Deer
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Deer::Render() {
    return 'D';
  }