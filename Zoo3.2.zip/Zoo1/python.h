#ifndef PYTHON_H
#define PYTHON_H
#include "squamata.h"
class Python : public Squamata {
public:
  /** @brief Constructor dari Python
    * Menghidupkan hewan Python
    *
    * @param x integer adalah letak absis Python yang dihidupkan
    * @param y integer adalah letak ordinat Python yang dihidupkan
    * @param bb integer adalah berat badan Python yang dihidupkan
    */
  Python(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Python
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Python ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Python
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif