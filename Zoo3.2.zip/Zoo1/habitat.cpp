#include "habitat.h"
  
  /** @brief Constructor dari Habitat
    * Menghidupkan habitat
    *
    * @param I Indices adalah alamat dimana habitat dihidupkan
    * @param type integer adalah kode dari habitat dimana 0=Land, 1=Water, 2=Air
    * @param code character adalah suatu huruf untuk merepresentasikan habitat di layar.
    */
  Habitat::Habitat(Indices ind, int type, char code) :
                   Cell(ind, 0, code), hType(type) {

  }
  /** @brief Mengembalikan nilai boolean apakah habitat adalah land
    */
  bool Habitat::IsLand() {
  	return hType == 0;
  }
  /** @brief Mengembalikan nilai boolean apakah habitat adalah water
    */
  bool Habitat::IsWater() {
  	return hType == 1;
  }
  /** @brief Mengembalikan nilai boolean apakah habitat adalah air
    */
  bool Habitat::IsAir() {
  	return hType == 2;
  }