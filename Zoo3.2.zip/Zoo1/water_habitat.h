#ifndef WATERHABITAT_H
#define WATERHABITAT_H
#include "habitat.h"
class WaterHabitat : public Habitat {
public:
  /** @brief Constructor dari Water Habitat
    * Menghidupkan habitat air
    *
    * @param I Indices adalah alamat dimana habitat dihidupkan
    */
  WaterHabitat(Indices ind);
  /** @brief Mengembalikan nilai character kode dari objek Water Habitat
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif