#ifndef LEMUR_H
#define LEMUR_H
#include "primates.h"
class Lemur : public Primates {
public:
  /** @brief Constructor dari Lemur
    * Menghidupkan hewan Lemur
    *
    * @param x integer adalah letak absis Lemur yang dihidupkan
    * @param y integer adalah letak ordinat Lemur yang dihidupkan
    * @param bb integer adalah berat badan Lemur yang dihidupkan
    */
  Lemur(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Lemur
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Lemur ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Lemur
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif