#ifndef STRIGIFORMES_H
#define STRIGIFORMES_H
#include "animals.h"
class Strigiformes : public Animals {
public:
  /** @brief Constructor dari Strigiformes
    * Menghidupkan hewan Ordo Strigiformes
    *
    * @param x integer adalah letak absis Strigiformes yang dihidupkan
    * @param y integer adalah letak ordinat Strigiformes yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Strigiformes(bool kejinakan, int x, int y);
};
#endif