#ifndef MONKEY_H
#define MONKEY_H
#include "primates.h"
class Monkey : public Primates {
public:
  /** @brief Constructor dari Monkey
    * Menghidupkan hewan Monkey
    *
    * @param x integer adalah letak absis Monkey yang dihidupkan
    * @param y integer adalah letak ordinat Monkey yang dihidupkan
    * @param bb integer adalah berat badan Monkey yang dihidupkan
    */
  Monkey(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Monkey
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Monkey ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Monkey
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif