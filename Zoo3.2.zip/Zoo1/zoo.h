#ifndef ZOO_H
#define ZOO_H
#include "animals.h"
#include "cell.h"
#include "cage.h"
class Zoo {
public:
  /** @brief Constructor dari Zoo
    * Menghidupkan kebun binatang
    */
  Zoo();
  /** @brief Destructor dari Zoo
    * Menghilangkan alokasi memori Zoo
    */
  ~Zoo();
  /** @brief Prosedur Move
    * I.S Semua elemen dalam kebun binatang telah dihidupkan
    * F.S Semua Animals dalam berpindah tempat
    * Menggerakkan hewan yang ada didalam kebun binatang
    */
  void Move();
  /** @brief Prosedur Print
    * I.S Zoo telah hidup
    * F.S Semua elemen zoo tercetak pada layar
    * Mencetak kebun binatang beserta seluruh elemennya ke layar
    */
  void Print();
  /** @brief Prosedur Hitung Makanan
    * I.S Zoo telah hidup
    * F.S Jumlah makanan yang dibutuhkan kebun binatang setiap harinya tercetak di layar
    * Mengkalkulasikan jumlah makanan yang diperlukan hewan-hewan yang hidup di kebun binatang
    * Mencetak hasil kalkulasi jumlah makanan ke layar
    */
  void HitungMakanan();
  /** @brief Mengembalikan bool apakah indeks tertentu bersinggungan dengan sebuah kandang
    *
    * @param ind adalah indeks yang akan diperiksa
    * @param c adalah kandang yang akan diperiksa
    */
  bool IsInteractable(Indices ind, Cage c);
  /** @brief Getter daftar kandang pada zoo
    */
  Cage* GetKandang();
private:
  /** @brief Atribut map adalah Matriks of Pointer to Cell
    */
  Cell* **map;
  /** @brief Atribut daftar_kandang adalah Array of Cage yang dimiliki kebun binatang
  */
  Cage *daftar_kandang;
  /** @brief Atribut lebar adalah lebar dari kebun binatang
    */
  int lebar;
  /** @brief Atribut panjang adalah panjang dari kebun binatang
    */
  int panjang;
  /** @brief Atribut banyak_kandang adalah jumlah kandang yang ada di kebun binatang
    */
  int banyak_kandang;
  /** @brief Atribut ready_to_print adalah Matriks of character kebun binatang yang siap dicetak ke layar (sudah ada hewan)
    */
  char **ready_to_print;
  /** @brief Atribut base_map adalah Matriks of character kebun binatang hasil render habitat (belum ada hewan)
    */
  char **base_map;
  /** @brief ukuran default panjang dan lebar zoo
    */
  int DEFSIZE=20;
};
#endif