#ifndef CASSOWARY_H
#define CASSOWARY_H
#include "casuariformes.h"
class Cassowary : public Casuariformes {
public:
  /** @brief Constructor dari Cassowary
    * Menghidupkan hewan Cassowary
    *
    * @param x integer adalah letak absis Cassowary yang dihidupkan
    * @param y integer adalah letak ordinat Cassowary yang dihidupkan
    * @param bb integer adalah berat badan Cassowary yang dihidupkan
    */
  Cassowary(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Cassowary
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Cassowary ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Cassowary
    * Character ini nantinya yang siap di Print ke layar
    */
  char Render();
};
#endif