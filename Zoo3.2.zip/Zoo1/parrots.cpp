#include "parrots.h"
#include <iostream>
using namespace std;
  /** @brief Constructor dari Parrots
    * Menghidupkan hewan Parrots
    *
    * @param x integer adalah letak absis Parrots yang dihidupkan
    * @param y integer adalah letak ordinat Parrots yang dihidupkan
    * @param bb integer adalah berat badan Parrots yang dihidupkan
    */
  Parrots::Parrots(int bb, int x, int y) : Psittaciformes(true, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Parrots
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Parrots ke layar
    */
  void Parrots::Interact() {
    cout << "Anyeong.." << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Parrots
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Parrots::Render() {
    return 'X';
  }