#include "restaurant.h"
  /** @brief Constructor dari Restaurant
    * Menghidupkan fasilitas restauran
    *
    * @param I Indices adalah alamat dimana fasilitas dihidupkan
    */
  Restaurant::Restaurant(Indices ind) : Facility(ind, 2, 'r') {

  }
  /** @brief Mengembalikan nilai character kode dari objek Restaurant
    * Character ini nantinya yang siap di Print ke layar
    */
  char Restaurant::Render() {
    return 'R';
  }