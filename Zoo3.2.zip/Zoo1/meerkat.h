#ifndef MEERKAT_H
#define MEERKAT_H
#include "carnivora.h"
class Meerkat : public Carnivora {
public:
  /** @brief Constructor dari Meerkat
    * Menghidupkan hewan Meerkat
    *
    * @param x integer adalah letak absis Meerkat yang dihidupkan
    * @param y integer adalah letak ordinat Meerkat yang dihidupkan
    * @param bb integer adalah berat badan Meerkat yang dihidupkan
    */
  Meerkat(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Meerkat
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Meerkat ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Meerkat
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif