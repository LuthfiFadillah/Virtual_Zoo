#ifndef PARK_H
#define PARK_H
#include "facility.h"
class Park : public Facility {
public:
  /** @brief Constructor dari Park
    * Menghidupkan fasilitas taman
    *
    * @param I Indices adalah alamat dimana fasilitas dihidupkan
    */	
  Park(Indices ind);
  /** @brief Mengembalikan nilai character kode dari objek Park
  * Character ini nantinya yang siap dicetak ke layar
  */
  char Render();
};
#endif