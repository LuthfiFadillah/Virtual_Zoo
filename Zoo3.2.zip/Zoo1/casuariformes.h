#ifndef CASUARIFORMES_H
#define CASUARIFORMES_H
#include "animals.h"
class Casuariformes : public Animals {
public:
  /** @brief Constructor dari Casuariformes
    * Menghidupkan hewan Ordo Casuariformes
    *
    * @param x integer adalah letak absis Casuariformes yang dihidupkan
    * @param y integer adalah letak ordinat Casuariformes yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Casuariformes(bool kejinakan, int x, int y);
};
#endif