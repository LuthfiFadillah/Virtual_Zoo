#ifndef PRIMATES_H
#define PRIMATES_H
#include "animals.h"
class Primates: public Animals {
public:
  /** @brief Constructor dari Primates
    * Menghidupkan hewan Ordo Primates
    *
    * @param x integer adalah letak absis Primates yang dihidupkan
    * @param y integer adalah letak ordinat Primates yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Primates(bool kejinakan, int x, int y);
};
#endif