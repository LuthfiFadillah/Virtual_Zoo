#include "Cage.h"
#include "Indices.h"
int main() {
  Indices wil[10];
  k=0;
  Indices ind;
  for (i = 0; i < 2; i++) {
    for (j = 0; j < 5; j++) {	
	  ind.set_absis(i + 1); ind.set_ordinat(j + 1);
      wil[k] = ind;
    }
  }
  Cage c1(Wil, 10);
  return 0;
}