//
//  mzoo.cpp
//  vz02
//
//  Created by Alivia Dewi Parahita on 3/14/17.
//  Copyright © 2017 Alivia Dewi Parahita. All rights reserved.
//

#include "Zoo.h"
#include <iostream>
using namespace std;

int main() {
    Zoo Z;
    
    Z.Print();
    Z.Move();
    cout<<endl;
    Z.Print();
    
    Z.Move();
    cout<<endl;
    Z.Print();
    
    Z.Move();
    cout<<endl;
    Z.Print();
    
    Z.Move();
    cout<<endl;
    Z.Print();
    
    Z.HitungMakanan();
    
    Indices I(4,0);
    if (Z.IsInteractable(I, Z.GetKandang()[0])) {
        cout << "Yeay.." << endl;
    }
    if (!Z.IsInteractable(I, Z.GetKandang()[8])) {
        cout << "Yeay..again" << endl;
    }
    
    return 0;
}
