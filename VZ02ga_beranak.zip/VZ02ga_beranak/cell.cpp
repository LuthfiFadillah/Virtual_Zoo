//
//  Cell.cpp
//  vz02
//
//  Created by Alivia Dewi Parahita on 3/14/17.
//  Copyright © 2017 Alivia Dewi Parahita. All rights reserved.
//

#include "cell.h"

Cell::Cell() {}

Cell::Cell(Indices I, char c){
    code = c;
    koordinat = I;
}
Cell::~Cell(){}

Cell& Cell::operator= (Cell& C) {
    koordinat = C.koordinat;
    code = C.code;
    
    return *this;
}

Indices Cell::GetKoordinat(){
    return koordinat;
}

bool Cell::IsHabitat(){
    return ((code == 'l')|| (code == 'w') || (code == 'a'));
}

bool Cell::IsFacility(){
    return ((code == 'P')|| (code == 'R') || (code == 'S'));
}


char Cell::GetCode(){
    return code;
}

bool Cell::IsRoad(){
    return ((code == '-')|| (code == '+') || (code == '='));
}

bool Cell::IsPark(){
    return (code == 'P');
}

bool Cell::IsRestaurant(){
    return (code == 'R');
}

bool Cell::IsLand(){
    return (code == 'l');
}

bool Cell::IsWater(){
    return (code == 'w');
}

bool Cell::IsAir(){
    return (code == 'a');
}

char Cell::Render(){
    return code;
}
