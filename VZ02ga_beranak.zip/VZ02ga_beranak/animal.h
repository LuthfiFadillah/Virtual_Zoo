#ifndef ANIMAL_H
#define ANIMAL_H
#include "indices.h"
#include <string>
using namespace std;

class Animal {
public:
  /** @brief Constructor tanpa parameter dari Animal
    * Menghidupkan sebuah objek Animal
    */
  Animal();
  /** @brief Constructor dari Animal
    * Menghidupkan sebuah objek Animal
    * @param x integer adalah letak absis Animal yang dihidupkan
    * @param y integer adalah letak ordinat Animal yang dihidupkan
    * @param bb integer adalah berat badan Animal yang dihidupkan
    */
  Animal(char code, int bb, int x, int y, int makan, bool land, bool water, bool air, bool kejinakan);
  /** @brief Destructor dari Animal
    * Menghilangkan alokasi memori objek Animal
    */
  ~Animal();
  /** @brief Getter berat badan sebuah objek Animal
    * Mengembalikan nilai integer berat badan sebuah objek Animal
    */
     int GetBerat();
    /** @brief Operator overloading = dari Animal
     * Memastikan bukan bitewise copy
     *
     * @param A menyatakan Animal yang ingin disalin
     */
    Animal& operator= (Animal& A);
    /** @brief Getter makanan sebuah objek Animal
     * Mengembalikan nilai makanan objek Animal
     */
    int GetMakanan();
  /** @brief Getter koordinat sebuah objek Animal
    * Mengembalikan nilai Indices koordinat objek Animal
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Animal
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Animal
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Animal
    * I.S Animal telah dihidupkan
    * F.S interaksi Animal tercetak ke layar
    * Mencetak interaksi Animal ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Animal dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Animal dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Animal dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Animal jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Animal
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Animal dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Animal dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut code  adalah char yang menyatakan nama Animal
    */
  char code;
  /** @brief Atribut berat_badan  menyatakan berapa berat Animal yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Animal berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Animal
    */
  int makanan; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Animal tinggal di darat
    */
  bool land_animal;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Animal tinggal di air
    */
  bool water_animal;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Animal tinggal di udara
    */
  bool air_animal;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Animal
    */
  bool jinak;
 
  
};

#endif
