//file: Zoo.h
#ifndef ZOO_H
#define ZOO_H
#include "cell.h"
#include "cage.h"

class Zoo {
public:
    void SetReady(char c,int i,int j);
    /** @brief Constructor tanpa parameter dari Zoo
     * Menghidupkan sebuah objek Zoo
     */
	Zoo();
    /** @brief Destructor dari Zoo
     * Menghilangkan alokasi memori objek Zoo
     */
	~Zoo();
    /** @brief Prosedur Move
     * I.S Semua elemen dalam kebun binatang telah dihidupkan
     * F.S Semua Animals dalam berpindah tempat
     * Menggerakkan hewan yang ada didalam kebun binatang
     */
    void Move();
    /** @brief Prosedur Print
     * I.S Zoo telah hidup
     * F.S Semua elemen zoo tercetak pada layar
     * Mencetak kebun binatang beserta seluruh elemennya ke layar
     */
    void Print();
    /** @brief Prosedur Hitung Makanan
     * I.S Zoo telah hidup
     * F.S Jumlah makanan yang dibutuhkan kebun binatang setiap harinya tercetak di layar
     * Mengkalkulasikan jumlah makanan yang diperlukan hewan-hewan yang hidup di kebun binatang
     * Mencetak hasil kalkulasi jumlah makanan ke layar
     */
    void HitungMakanan();
    /** @brief Mengembalikan nilai boolean apakah kandang C berapa dapat berinteraksi dengan indices i
      *
      * @param C cage yang ingin di check
      * @param I indices yang ingin di check
      */
    bool IsInteractable(Indices I, Cage C);
    /** @brief Getter kandang pada zoo
     * Mengembalikan atribut daftar_kandang dari kebun binatang
     */
    Cage* GetKandang();
    /** @brief Getter Print dari Kebun Binatang
     * Mengembalikan matriks yang siap di print yaitu atribut ready_to_print
     */
	char** GetPrint();
    /** @brief Prosedur Tour
     * I.S Zoo telah hidup
     * F.S Melakukan kunjungan mengelilingi zoo dan berinteraksi dengan setiap hewan di kandang
     * Vitur mengelilingi zoo dan berinteraksi dengan setiap hewan yang hidup
     */
	void Tour();

private:
    /** @brief Attribut Map adalah Matriks of Cell
      */
	Cell **map;
    /** @brief Attribut DaftarKandang adalah Array of Cage yang dimiliki kebun binatang
     */
	Cage *daftar_kandang;
    /** @brief Attribut Lebar adalah lebar dari kebun binatang
     */
	int lebar;
    /** @brief Attribut Panjang adalah panjang dari kebun binatang
     */
	int panjang;
    /** @brief Attribut BykKandang adalah banyaknya kandang yang ada di kebun binatang
     */
	int banyak_kandang;
    /** @brief Attribut ready_to_print adalah Matriks of character kebun binatang yang siap di print ke layar (sudah ada hewan)
     */
    char **ready_to_print;
    /** @brief Attribut dasar adalah Matriks of character kebun binatang hasil render habitat (belum ada hewan). Dasar adalah duplikasi base_map.
     */
    char **dasar;
    /** @brief Attribut base_map adalah Matriks of character kebun binatang hasil render habitat (belum ada hewan)
     */
	//char **base_map;
	//int DEFSIZE=20;
};

#endif
