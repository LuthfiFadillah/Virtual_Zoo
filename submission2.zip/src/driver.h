#ifndef DRIVER_H
#define DRIVER_h
#include "zoo.h"

class Driver{
  public:
    /** @brief Prosedur Main Menu
      * I.S Program siap dijalan kan
      * F.S Menampilkan main menu kelayar serta menerima pilihan masukan main menu
      * vitur main menu. Memberikan beberapa pilihan dan menerima input pilihan sampai menerima input pilihan quit
      */
    void MainMenu();
    /** @brief Prosedur Display Vitrual Zoo
     * I.S Zoo telah hidup
     * F.S Menampilkan Zoo sesuai dengan koordinat yang menjadi masukan
     * Menampilkan kebun binatang ke layar sesuai dengan koordinat yang user inginkan.
     *
     * @param x1 integer absis yang dijadikan titip awal zoo yang ditampilkan
     * @param y1 integer ordinat yang dijadikan titip awal zoo yang ditampilkan
     * @param x2 integer absis yang dijadikan titip akhir zoo yang ditampilkan
     * @param y2 integer absis yang dijadikan titip akhir zoo yang ditampilkan
     */
    void DisplayVirtualZoo(int x1, int y1, int x2, int y2);
    /** @brief Prosedur Tour
     * I.S Zoo telah hidup
     * F.S Melakukan tour pada zoo serta menampilkan interaksi setiap hewan pada kandang yang dikunjungi
     * Vitur mengelilingi zoo. Mengunjungi beberapa kandang dan berinteraksi dengan hewannya
     */
    void TourVirtualZoo();
    /** @brief Prosedur Display Makanan
     * I.S Zoo telah hidup
     * F.S Jumlah makanan yang dibutuhkan muncul dilayar
     * Vitur display makanan, menampilkan banyaknya makanan yang dibutuhkan kebun binatang ke layar.
     */
    void DisplayMakanan();
  private:
    /** @brief Attribut Z adalah Zoo yang hidup
     */
    Zoo Z;
};

#endif
