//
//  Zoo.cpp
//  vz02
//
//  Created by Alivia Dewi Parahita on 3/14/17.
//  Copyright © 2017 Alivia Dewi Parahita. All rights reserved.
//

#include "zoo.h"
#include <time.h>
#include <cstdio>
#include <string>
#include <fstream>
#include <iostream>
#include "stdlib.h"
using namespace std;

void Zoo::SetReady(char c,int i,int j) {
        ready_to_print[i][j] = c;
    }
Zoo::Zoo() {
    ifstream filezoo;
    filezoo.open("map.txt", ios::in);
    //FILE *fp;
    string brs;
    int bwh=0;
    int samping=0;
    int BK=0;
    int i,j;
    Indices **Temp;
    
    if (filezoo.is_open()) {
        
        filezoo >> brs;
        bwh=0;
        for(i=0; i<brs.length(); i++) {
            bwh = (bwh*10)+ ((int) brs[i] -48);
        }
        
        filezoo >> brs;
        samping=0;
        for (i=0; i<brs.length(); i++) {
            samping = (samping*10) + ((int) brs[i] -48);
        }
 
        filezoo >> brs;
        for (i=0; i<brs.length(); i++) {
            BK = (BK*10) + ((int) brs[i] -48);
        }
        
        Temp = new Indices *[BK];
        for (i=0; i<BK; i++){
            Temp[i]= new Indices [25]; //constraint: maksimal habitat dalam satu cage adalah 25
        }
        
        lebar = bwh; cout << lebar;
        panjang = samping; cout << " 20";
        map = new Cell* [lebar];
        for (i=0; i<lebar; i++) {
            map[i] = new Cell [panjang];
        }
        
        banyak_kandang = BK;
        int *NeffKandang;
        NeffKandang = new int [BK];
        for (i=0; i<banyak_kandang; i++) {
            NeffKandang[i] = 0;
        }
        char habitat;
        int code;
        
        Indices I(0,0);
        for (i=0; i<bwh; i++) {
            filezoo >> brs;
            int j=0;
            int k=0;
            while (j<samping*2) {
                I.SetAbsis(k);
                I.SetOrdinat(i);
                habitat = brs[j];
                if (habitat == 'W') {
                    Cell C(I,'w');
                    map[i][k] = C;
                } else
                    if (habitat == 'L') {
                        Cell C(I,'l');
                        map[i][k] = C;
                    } else
                        if (habitat == 'A') {
                            Cell C(I,'a');
                            map[i][k] = C;
                        } else {
                            Cell C(I,habitat);
                            map[i][k] = C;
                        }
                j++;
                k++;
                
                code = ((int) brs[j] -48);
                if (code != 0) {
                    Temp[code-1][NeffKandang[code-1]] = I;
                    NeffKandang[code-1]++;
                }
                
                j++;
            }
        }
        filezoo.close();
        daftar_kandang = new Cage[banyak_kandang];
        Indices *TempI;
        //TempI =  new Indices [25];
        for (i=0; i<banyak_kandang; i++) {
            TempI =  new Indices [25];
            for (int j=0; j<NeffKandang[i]; j++) {
                TempI[j] = Temp[i][j];
            }
            Cage C(TempI,NeffKandang[i]);
            daftar_kandang[i] = C;
            C.~Cage();
            delete [] TempI;
        }
        
        //base_map = new char* [lebar];
        ready_to_print = new char *[lebar];
        dasar = new char *[lebar];
        for (i=0; i<lebar; i++) {
            //base_map[i] = new char [panjang];
            ready_to_print[i] = new char [panjang];
            dasar[i] = new char [panjang];
        }
        /*
        for (i=0; i<lebar; i++) {
            for (int j=0; j<panjang; j++) {
                base_map[i][j] = map[i][j].Render();
            }
        }
        */

        for (i=0; i<lebar; i++) {
            for (int j=0; j<panjang; j++) {
                dasar[i][j] = map[i][j].Render();
            }
        }

        for (i=0; i<lebar; i++) {
            for (int j=0; j<panjang; j++) {
                ready_to_print[i][j] = dasar[i][j];
            }
        }
        
        Animal* PA;
        PA = new Animal [37];
        i = 0;
        //Cage 1
        Animal A1('B',45,2,2,2,false,true,false,true);
        PA[i] = A1;
        daftar_kandang[0].AddAnimal(PA[i]);
        i++;
        Animal A2('N',45,1,1,0,false,true,false,true);
        PA[i] = A2;
        daftar_kandang[0].AddAnimal(PA[i]);
        i++;
        Animal A3('Q',45,0,0,1,true,true,false,true);
        PA[i] = A3;
        daftar_kandang[0].AddAnimal(PA[i]);
        i++;
        //Cage 2
        Animal A4('O',10,19,0,1,true,false,false,true);
        PA[i] = A4;
        daftar_kandang[1].AddAnimal(PA[i]);
        i++;
        Animal A5('O',10,8,2,1,true,false,false,true);
        PA[i] = A5;
        daftar_kandang[1].AddAnimal(PA[i]);
        i++;
        Animal A6('X',10,17,0,1,true,false,false,true);
        PA[i] = A6;
        daftar_kandang[1].AddAnimal(PA[i]);
        i++;
        //Cage 3
        Animal A7('I',100,1,4,2,true,false,false,false);
        PA[i] = A7;
        daftar_kandang[2].AddAnimal(PA[i]);
        i++;
        Animal A8('I',100,1,5,2,true,false,false,false);
        PA[i] = A8;
        daftar_kandang[2].AddAnimal(PA[i]);
        i++;
        //Cage 4
        Animal A9('C',70,6,4,1,true,false,false,true);
        PA[i] = A9;
        daftar_kandang[3].AddAnimal(PA[i]);
        i++;
        Animal A10('Y',30,6,6,0,true,false,false,true);
        PA[i] = A10;
        daftar_kandang[3].AddAnimal(PA[i]);
        i++;
        Animal A11('D',60,7,5,0,true,false,false,true);
        PA[i] = A11;
        daftar_kandang[3].AddAnimal(PA[i]);
        i++;
        Animal A12('E',30,5,7,0,true,false,false,true);
        PA[i] = A12;
        daftar_kandang[3]. AddAnimal(PA[i]);
        i++;
        //Cage 5
        Animal A13('G',100,14,4,0,true,false,false,true);
        PA[i] = A13;
        daftar_kandang[4].AddAnimal(PA[i]);
        i++;
        Animal A14('M',30,14,6,0,true,false,false,true);
        PA[i] = A14;
        daftar_kandang[4].AddAnimal(PA[i]);
        i++;
        Animal A15('Z',10,16,4,1,false,false,true,true);
        PA[i] = A15;
        daftar_kandang[4].AddAnimal(PA[i]);
        i++;
        Animal A16('H',15,12,6,2,true,false,false,true);
        PA[i] = A16;
        daftar_kandang[4].AddAnimal(PA[i]);
        i++;
        //Cage 6
        Animal A17('@',70,18,8,2,true,false,false,false);
        PA[i] = A17;
        daftar_kandang[5].AddAnimal(PA[i]);
        i++;
        Animal A18('@',70,19,6,2,true,false,false,false);
        PA[i] = A18;
        daftar_kandang[5].AddAnimal(PA[i]);
        i++;			
        //Cage 7
        Animal A19('J',100,10,12,0,true,false,false,true);
        PA[i] = A19;
        daftar_kandang[6].AddAnimal(PA[i]);
        i++;
        Animal A20('U',10,14,11,1,true,true,false,true);
        PA[i] = A20;
        daftar_kandang[6].AddAnimal(PA[i]);
        i++;
        Animal A21('Q',10,12,12,1,true,true,false,true);
        PA[i] = A21;
        daftar_kandang[6].AddAnimal(PA[i]);
        i++;
        //Cage 8
        Animal A22('$',150,5,19,2,true,false,false,false);
        PA[i] = A22;
        daftar_kandang[7].AddAnimal(PA[i]);
        i++;
        Animal A23('$',150,7,16,2,true,false,false,false);
        PA[i] = A23;
        daftar_kandang[7].AddAnimal(PA[i]);
        i++;
        //Cage 9
        Animal A24('V',100,11,18,2,true,false,false,false);
        PA[i] = A24;
        daftar_kandang[8].AddAnimal(PA[i]);
        i++;
        Animal A25('V',100,12,16,2,true,false,false,false);
        PA[i] = A25;
        daftar_kandang[8].AddAnimal(PA[i]);
        i++;
        Animal A26('V',100,12,19,2,true,false,false,false);
        PA[i] = A26;
        daftar_kandang[8].AddAnimal(PA[i]);
        i++;
     


        int a;
        int b;
        for ( i = 0; i < banyak_kandang; i++) {
            for ( j = 0; j < daftar_kandang[i].GetBanyakHewan(); j++) {
                a = daftar_kandang[i].GetAnimals()[j].GetKoordinat().GetAbsis();
                b = daftar_kandang[i].GetAnimals()[j].GetKoordinat().GetOrdinat();
                SetReady(daftar_kandang[i].GetAnimals()[j].Render(),a,b);
                //ready_to_print[a][b] = daftar_kandang[i].GetAnimals()[j].Render();
            }
        }
    }
}

Zoo::~Zoo() {
    int i;
    for ( i=0; i<lebar; i++) {
        delete [] map[i];
        delete [] dasar[i];
        delete [] ready_to_print[i];
    }
    delete [] dasar;
    delete [] ready_to_print;
    delete [] map;
    delete [] daftar_kandang;
    //delete [] base_map;
}

void Zoo::Move(){
    cout << "s";
    srand(time(NULL));
    cout << "t";
    bool move;
    cout << "i";
    Indices I;
    int count,a,b,to,tox,toy;
    for (int i=0; i<banyak_kandang; i++) {
        cout << "j";
        for (int j=0; j<daftar_kandang[i].GetBanyakHewan(); j++) {
            move= false;
            count = 0;
            cout << "1";
            a = (daftar_kandang[i].GetAnimals()[j]).GetKoordinat().GetAbsis();
            b = (daftar_kandang[i].GetAnimals()[j]).GetKoordinat().GetOrdinat();
            cout << "2";
            to = (rand() % 3) +1;
            while ((!(move)) && (count<4)){
                tox = a; toy = b;
                count++;
                switch (to)
                {
                    case 1 : {tox++;}; break;
                    case 2 : {toy++;}; break;
                    case 3 : {tox--;}; break;
                    case 4 : {toy--;}; break;
                        
                }
                if ((toy>=0) && (toy<lebar) && (tox >=0) && (tox <panjang)) {
                        cout << "3";
                    I.SetOrdinat(toy); I.SetAbsis(tox);
                        cout << "4";
                    if (((daftar_kandang[i].GetAnimals()[j]).IsLivable(map[toy][tox].Render())) &&
                        (daftar_kandang[i].IsHostOf(I)) &&
                        ((ready_to_print[toy][tox] == 'w') || (ready_to_print[toy][tox] == 'l') || (ready_to_print[toy][tox] == 'a'))) {
                        move = true;
                        (daftar_kandang[i].GetAnimals()[j]).SetKoordinat(tox, toy);
                        ready_to_print[b][a] = dasar[b][a];
                        ready_to_print[toy][tox] = (daftar_kandang[i].GetAnimals()[j]).Render();
                    } else {
                        to = (to%4) + 1;
                    }
                } else {
                    to = (to%4) + 1;
                }
            }
        }
    }
}
void Zoo::Print() {
    for(int i=0; i<lebar; i++) {
        for(int j=0; j<panjang; j++) {
            cout<<ready_to_print[i][j] << " ";
        }
        cout<< endl;
        cout << "d";
    }
    cout << "e";
}

void Zoo::HitungMakanan(){
    int sayur_buah_dan_biji2an=0;
    int daging=0;
    int i,j;
    for (i = 0; i<banyak_kandang; i++) {
        for (j = 0; j<daftar_kandang[i].GetBanyakHewan(); j++) {
            if (daftar_kandang[i].GetAnimals()[j].GetMakanan() == 0) {
                sayur_buah_dan_biji2an = sayur_buah_dan_biji2an + (daftar_kandang[i].GetAnimals()[j].GetBerat() * 3 / 100);
            } else
                if (daftar_kandang[i].GetAnimals()[j].GetMakanan() == 1) {
                    sayur_buah_dan_biji2an = sayur_buah_dan_biji2an + (daftar_kandang[i].GetAnimals()[j].GetBerat() * 3 / 200);
                    daging = daging + (daftar_kandang[i].GetAnimals()[j].GetBerat() * 3 / 200);
                } else
                    if (daftar_kandang[i].GetAnimals()[j].GetMakanan() == 2) {
                        daging = daging + (daftar_kandang[i].GetAnimals()[j].GetBerat() * 3 / 100);
                    }
        }
    }
    
    cout << "Butuh daging sebanyak " << daging << "kg." << endl;
    cout << "Butuh sayur, buah, dan biji-bijian sebanyak " << sayur_buah_dan_biji2an << "kg." << endl;
}

Cage* Zoo::GetKandang() {
    return daftar_kandang;
}

bool Zoo::IsInteractable(Indices I, Cage C) {
    bool iya = false;
   // int i = 0;
    Indices It;
    It.SetAbsis(I.GetAbsis()+1); It.SetOrdinat(I.GetOrdinat());
    iya = (C.IsHostOf(It));
    if (!iya) {
        It.SetAbsis(I.GetAbsis()-1); It.SetOrdinat(I.GetOrdinat());
        iya = (C.IsHostOf(It));
    }
    if (!iya) {
        It.SetAbsis(I.GetAbsis()); It.SetOrdinat(I.GetOrdinat()+1);
        iya = (C.IsHostOf(It));
    }
    if (!iya) {
        It.SetAbsis(I.GetAbsis()); It.SetOrdinat(I.GetOrdinat()-1);
        iya = (C.IsHostOf(It));
    }
    return iya;
}

char** Zoo::GetPrint() {
    return ready_to_print;
}

void Zoo::Tour(){
    //i=y , j=x
    bool jalan;
   // int countcage;
    Indices* ent;
    Indices* ex;
    int countentrance,countexit;
    int i,j;
    int idxentrance=0;
  //  int idxexit;
    int tempint = 0;
    char** map;
    countentrance = 0;
    countexit = 0;
    map = new char*[20];
    for(i=0;i<20;i++){
        map[i] = new char[20];
    }
    //mindahin map di zoo ke temp map
    for(i=0; i<lebar; i++) {
        for(j=0; j<panjang; j++) {
            map[i][j] = ready_to_print[i][j];
        }
    }
    //mencari entrance
    for(i=0; i<lebar; i++) {
        for(j=0; j<panjang; j++) {
            if (map[i][j] == '+') {
                countentrance++;
            }
        }
    }
    //memasukkan koordinat entrance ke array of Indices
    ent = new Indices [countentrance];
    for(i=0; i<lebar; i++) {
        for(j=0; j<panjang; j++) {
            if(map[i][j] == '+'){
                ent[tempint].SetAbsis(j);
                ent[tempint].SetOrdinat(i);
                tempint++;
            }
        }
    }
    //mencari exit
    for(i=0; i<lebar; i++) {
        for(j=0; j<panjang; j++) {
            if (map[i][j] == '=') {
                countexit++;
            }
        }
    }
    tempint = 0;
    //memasukkan koordinat exit ke array of Indices
    ex = new Indices [countexit];
    for(i=0; i<lebar; i++) {
        for(j=0; j<panjang; j++) {
            if(map[i][j] == '='){
                ex[tempint].SetAbsis(j);
                ex[tempint].SetOrdinat(i);
                tempint++;
            }
        }
    }
    //menentukan entrance secara acak
    srand((unsigned)time(NULL));
    idxentrance = rand()%countentrance;
    // membuat array of visitable
    bool** IsVisitable;
    IsVisitable = new bool* [lebar];
    for(i=0;i<lebar;i++){
        IsVisitable[i] = new bool [panjang];
    }
    for(i=0; i<lebar; i++) {
        for(j=0; j<panjang; j++) {
            if (map[i][j] == '=' || map[i][j] == '-' || map[i][j] == '+') {
                IsVisitable[i][j] = true;
            }
            else{
                IsVisitable[i][j] = false;
            }
        }
    }
    //	cout << "h" << endl;
    //touring
    int x = ent[idxentrance].GetAbsis();
    int y = ent[idxentrance].GetOrdinat();
    cout << "Anda baru saja masuk, anda berada di " << x << "," << y << endl;
    bool IsJalanAble[4];// 0 : atas, 1 : kiri, 2 : bawah, 3 : kanan
    for (i = 0; i < 4; i++) {
        IsJalanAble[i] = false;
    }
    int countjalan;
    int n;
    jalan = true;
    Indices I;
    while(jalan){
        //for(int i=0; i<lebar; i++) {
        //			for(int j=0; j<panjang; j++) {
        //				if(IsVisitable[i][j]){
        //				cout << '1';
        //		}
        //	else{
        //	cout << '0';
        //	}
        //	cout << ' ';
        //}
        //cout<< endl;
        //	}
        cout << "Anda berada di " << x << "," << y << endl;
        I.SetAbsis(x);
        I.SetOrdinat(y);
        for(n = 0; n<banyak_kandang ; n++){
            if(IsInteractable(I,daftar_kandang[n])){
                daftar_kandang[n].Inter();
            }
        }
        countjalan = 0;
        if ((y>0) && (IsVisitable[y-1][x])) {// di atas bisa jalan?
            IsJalanAble[0] = true;
            countjalan++;
        }else{ IsJalanAble[0] = false;}
        if((x>0) && IsVisitable[y][x-1]) {// di kiri bisa jalan?
            IsJalanAble[1] = true;
            countjalan++;
        }else{ IsJalanAble[1] = false;}
        if ((y<lebar-1) && IsVisitable[y+1][x]) {// di bawah bisa jalan?
            IsJalanAble[2] = true;
            countjalan++;
        }else{ IsJalanAble[2] = false;}
        if ((x < lebar-1) && IsVisitable[y][x+1]) {// di kanan bisa jalan?
            IsJalanAble[3] = true;
            countjalan++;
        }else{ IsJalanAble[3] = false;}
        if(countjalan==0){
            jalan = false;
        }
        else{
            do{
                n = rand()%4;
            }while(!IsJalanAble[n]);
            IsVisitable[y][x] = false;
            switch (n) {
                case 0: y--;break;
                case 1: x--;break;
                case 2: y++;break;
                case 3: x++;break;
                default : jalan=false;
            }
        }
    }
    //end touring
    //cek apakah berhenti di exit
    bool IsExit = false;
 //   int z;
    for (i = 0; i < countexit; i++) {
        if(ex[i].GetAbsis() == x && ex[i].GetOrdinat() == y){
            IsExit = true;
        }
    }
    if(IsExit){
        cout << "yeeeyeyeyyey keluar!!!" << endl;
        cout << "Anda berakhir di " << x << "," << y << endl;
    }
    else{
        cout << "noonononono kejebak!!!" << endl;
        cout << "Anda berakhir di " << x << "," << y << endl;
    }
}
