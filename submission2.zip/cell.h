//file Cell.h
#ifndef CELL_H
#define CELL_H
#include "indices.h"

class Cell {
public:
  /** @brief Constructor tanpa parameter dari Cell
    * Menghidupkan Cell
    */
  Cell();
  /** @brief Constructor dari Cell
    * Menghidupkan Cell
    *
    * @param I Indices adalah alamat dimana Cell dihidupkan
    */
  Cell(Indices I, char c);
  /** @brief Destructor dari Cell
    * Menghilangkan alokasi memori Cell
    */
  ~Cell();
    /** @brief Operator overloading = dari Cell
     * Memastikan bukan bitewise copy
     *
     * @param C menyatakan Cell yang ingin disalin
     */
    Cell& operator= (Cell& C);
    /** @brief Mengembalikan nilai Indices dimana Cell berada
    */
  Indices GetKoordinat();
  /** @brief Mengembalikan nilai boolean apakah Cell adalah habitat
    */
  bool IsHabitat();
  /** @brief Mengembalikan nilai boolean apakah Cell adalah fasilitas
    */
  bool IsFacility();
  /** @brief Mengembalikan nilai char Code yang adalah atribut Cell
    */
  char GetCode();
  /** @brief Mengembalikan nilai boolean apakah Cell adalah road
    */
  bool IsRoad();
  /** @brief Mengembalikan nilai boolean apakah Cell adalah Park
    */
  bool IsPark();
  /** @brief Mengembalikan nilai boolean apakah Cell adalah restaurant
    */
  bool IsRestaurant();
  /** @brief Mengembalikan nilai boolean apakah Cell adalah land
    */
  bool IsLand();
  /** @brief Mengembalikan nilai boolean apakah Cell adalah water
    */
  bool IsWater();
  /** @brief Mengembalikan nilai boolean apakah Cell adalah air
    */
  bool IsAir();
  /** @brief Mengembalikan nilai kode char dari objek Cell
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
private:
  /** @brief Atribut koordinat yang adalah Indices letak Cell
    */
  Indices koordinat;
  /** @brief Atribut code yang adalah code dari Cell
    */
  char code;
};

#endif
