//
//  mdriver.cpp
//  vz02
//
//  Created by Alivia Dewi Parahita on 3/15/17.
//  Copyright © 2017 Alivia Dewi Parahita. All rights reserved.
//

#include "driver.h"
#include <iostream>

using namespace std;

int main() {
    Driver main;
    main.MainMenu();
    return 0;
}
