//file: Cage.h
#ifndef CAGE_H
#define CAGE_H
#include "animal.h"
#include "indices.h"

class Cage {
public:
    /** @brief Constructor tanpa parameter dari Cage
     * Menghidupkan kandang
     */
    Cage();
    /** @brief Constructor dengan parameter dari Cage
     * Menghidupkan kandang sesuai dengan input parameter
     *
     * @param I array of Indices menyatakan Cell dengan indices mana saja yang tergabung dalam cage
     * @param Neff integer menyatakan banyaknya Indices yang ada pada array
     */
	Cage(Indices *I, int Neff);
    /** @brief Operator overloading = dari Cage
     * Memastikan bukan bitewise copy
     *
     * @param C menyatakan Cage yang ingin disalin   */
    Cage& operator= (const Cage& C);
    /** @brief Destructor dari Cage
     * Menghilangkan alokasi memori Cage
     */
	~Cage();
    /** @brief  Mengembalikan nilai boolean apakah indices termasuk pada cangkupan cage
     *
     * @param I adalah indices yang diperiksa sebagai bagian dari cage
     */
	bool IsHostOf(Indices I);
    /** @brief Mengembalikan nilai boolean apakah masih ada ruang untuk animal di cage tersebut
     */
	bool Spacious();
    /** @brief Prosedur AddAnimal dari Cage
     * I.S Cage telah hidup dan Masukkan terdefinisi sebagai hewan yang hidup
     * F.S Animal A tercatat pada Data Animals Cage
     * Menambahkan Animals A pada Data Animals Cage
     *
     * @param A adalah Pointer to Animals yang ingin dimasukkan di Data Animals
     */
    void AddAnimal(Animal A);
    /** @brief Prosedur Inter dari Cage
     * I.S Cage terdefinisi
     * F.S Memanggil semua prosedur interact dari animals yang ada di Cage
     * Mencetak semua suara binatang yang ada dalam kandang
     */
	void Inter();
    /** @brief Mengembalikan nilai atribut DataAnimals
     *
     */
    Animal* GetAnimals();
    /** @brief GetLuas dari cage
     * Mengembalikan nilai luas suatu kandang
     *
     */
    int GetLuas();
    /** @brief GetBanyakHewan dari Cage
     * Mengembalikan nilai banyaknya hewan yang ada di suatu kandang
     */
    int GetBanyakHewan();
	
private:
    /** @brief Attribut wilayah adalah Array of Indices kandang yang termasuk pada kandang
     */
	Indices* wilayah;
    /** @brief Attribut data_animal adalah Array of Animal yang tinggal dikandang tersebut
      */
	Animal* data_animal;
    /** @brief Attribut luas menyatakan luasnya kandang
     */
	int luas;
    /** @brief Attribut banyak_hewan menyatakan jumlah hewan yang hidup di kandang
     */
	int banyak_hewan;
	
};
#endif
