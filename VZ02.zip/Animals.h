#ifndef ANIMALS_H
#define ANIMALS_H
#include "Indices.h"

class XX {
public:
  /** @brief Constructor dari XX
    * Menghidupkan sebuah objek XX
    * @param x integer adalah letak absis Dolphin yang dihidupkan
    * @param y integer adalah letak ordinat Dolphin yang dihidupkan
    * @param bb integer adalah berat badan Dolphin yang dihidupkan
    */
  XX(int bb, int x, int y);
  /** @brief Destructor dari XX
    * Menghilangkan alokasi memori objek XX
    */
  ~XX();
  /** @brief Getter berat badan sebuah objek XX
    * Mengembalikan nilai integer berat badan sebuah objek XX
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek XX
    * Mengembalikan nilai Indices koordinat objek XX
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari XX
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari XX
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek XX
    * I.S XX telah dihidupkan
    * F.S interaksi XX tercetak ke layar
    * Mencetak interaksi XX ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah XX dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah XX dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah XX dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah XX jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek XX
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah XX dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk XX dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat XX yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana XX berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek XX
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah XX tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah XX tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah XX tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya XX
    */
  const bool jinak = true;
};

class BigHornSheep {
public:
  BigHornSheep(int bb, int x, int y);
  ~BigHornSheep();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Cassowary {
public:
  Cassowary(int bb, int x, int y);
  ~Cassowary();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};


class Cassowary {
public:
  Cassowary(int bb, int x, int y);
  ~Cassowary();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Cassowary {
public:
  Cassowary(int bb, int x, int y);
  ~Cassowary();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Cassowary {
public:
  Cassowary(int bb, int x, int y);
  ~Cassowary();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Cassowary {
public:
  Cassowary(int bb, int x, int y);
  ~Cassowary();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Cassowary {
public:
  Cassowary(int bb, int x, int y);
  ~Cassowary();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Chameleon {
public:
  Chameleon(int bb, int x, int y);
  ~Chameleon();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Cheetah {
public:
  Cheetah(int bb, int x, int y);
  ~Cheetah();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};


class Cockatoo {
public:
  Cockatoo(int bb, int x, int y);
  ~Cockatoo();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Deer {
public:
  Deer(int bb, int x, int y);
  ~Deer();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Dolphin {
public:
  Dolphin(int bb, int x, int y);
  ~Dolphin();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Duck {
public:
  Duck(int bb, int x, int y);
  ~Duck();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Giraffe {
public:
  Giraffe(int bb, int x, int y);
  ~Giraffe();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Gorilla {
public:
  Gorilla(int bb, int x, int y);
  ~Gorilla();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class GreatWhiteShark {
public:
  GreatWhiteShark(int bb, int x, int y);
  ~GreatWhiteShark();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Lemur {
public:
  Lemur(int bb, int x, int y);
  ~Lemur();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Lion {
public:
  Lion(int bb, int x, int y);
  ~Lion();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Meerkat {
public:
  Meerkat(int bb, int x, int y);
  ~Meerkat();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Monkey {
public:
  Monkey(int bb, int x, int y);
  ~Monkey();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Orca {
public:
  Orca(int bb, int x, int y);
  ~Orca();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Owl {
public:
  Owl(int bb, int x, int y);
  ~Owl();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Parrots {
public:
  Parrots(int bb, int x, int y);
  ~Parrots();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Python {
public:
  Python(int bb, int x, int y);
  ~Python();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Swan {
public:
  Swan(int bb, int x, int y);
  ~Swan();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Tarsier {
public:
  Tarsier(int bb, int x, int y);
  ~Tarsier();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};

class Wolf {
public:
  Wolf(int bb, int x, int y);
  ~Wolf();
  int GetBerat();
  Indices GetKoordinat();
  void SetBerat(int bb);
  void SetKoordinat(int x, int y);
  void Interact();
  bool IsLandAnimal();
  bool IsWaterAnimal();
  bool IsAirAnimal();
  bool IsJinak();
  char Render();
  bool IsLivable(char c);
private:
  int berat_badan;
  Indices koordinat;
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  const bool land_animal = true;
  const bool water_animal = true;
  const bool air_animal = true;
  const bool jinak = true;
};



#endif
