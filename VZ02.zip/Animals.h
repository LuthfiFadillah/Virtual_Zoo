#ifndef ANIMALS_H
#define ANIMALS_H
#include "Indices.h"

class Beluga {
public:
  /** @brief Constructor dari Beluga
    * Menghidupkan sebuah objek Beluga
    * @param x integer adalah letak absis Beluga yang dihidupkan
    * @param y integer adalah letak ordinat Beluga yang dihidupkan
    * @param bb integer adalah berat badan Beluga yang dihidupkan
    */
  Beluga(int bb, int x, int y);
  /** @brief Destructor dari Beluga
    * Menghilangkan alokasi memori objek Beluga
    */
  ~Beluga();
  /** @brief Getter berat badan sebuah objek Beluga
    * Mengembalikan nilai integer berat badan sebuah objek Beluga
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Beluga
    * Mengembalikan nilai Indices koordinat objek Beluga
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Beluga
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Beluga
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Beluga
    * I.S Beluga telah dihidupkan
    * F.S interaksi Beluga tercetak ke layar
    * Mencetak interaksi Beluga ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Beluga dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Beluga dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Beluga dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Beluga jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Beluga
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Beluga dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Beluga dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Beluga yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Beluga berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Beluga
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Beluga tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Beluga tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Beluga tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Beluga
    */
  const bool jinak = true;
};

class BigHornSheep {
public:
  /** @brief Constructor dari BigHornSheep
    * Menghidupkan sebuah objek BigHornSheep
    * @param x integer adalah letak absis BigHornSheep yang dihidupkan
    * @param y integer adalah letak ordinat BigHornSheep yang dihidupkan
    * @param bb integer adalah berat badan BigHornSheep yang dihidupkan
    */
  BigHornSheep(int bb, int x, int y);
  /** @brief Destructor dari BigHornSheep
    * Menghilangkan alokasi memori objek BigHornSheep
    */
  ~BigHornSheep();
  /** @brief Getter berat badan sebuah objek BigHornSheep
    * Mengembalikan nilai integer berat badan sebuah objek BigHornSheep
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek BigHornSheep
    * Mengembalikan nilai Indices koordinat objek BigHornSheep
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari BigHornSheep
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari BigHornSheep
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek BigHornSheep
    * I.S BigHornSheep telah dihidupkan
    * F.S interaksi BigHornSheep tercetak ke layar
    * Mencetak interaksi BigHornSheep ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah BigHornSheep dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah BigHornSheep dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah BigHornSheep dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah BigHornSheep jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek BigHornSheep
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah BigHornSheep dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk BigHornSheep dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat BigHornSheep yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana BigHornSheep berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek BigHornSheep
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah BigHornSheep tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah BigHornSheep tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah BigHornSheep tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya BigHornSheep
    */
  const bool jinak = true;
};

class Cassowary {
public:
  /** @brief Constructor dari Cassowary
    * Menghidupkan sebuah objek Cassowary
    * @param x integer adalah letak absis Cassowary yang dihidupkan
    * @param y integer adalah letak ordinat Cassowary yang dihidupkan
    * @param bb integer adalah berat badan Cassowary yang dihidupkan
    */
  Cassowary(int bb, int x, int y);
  /** @brief Destructor dari Cassowary
    * Menghilangkan alokasi memori objek Cassowary
    */
  ~Cassowary();
  /** @brief Getter berat badan sebuah objek Cassowary
    * Mengembalikan nilai integer berat badan sebuah objek Cassowary
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Cassowary
    * Mengembalikan nilai Indices koordinat objek Cassowary
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Cassowary
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Cassowary
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Cassowary
    * I.S Cassowary telah dihidupkan
    * F.S interaksi Cassowary tercetak ke layar
    * Mencetak interaksi Cassowary ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Cassowary dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Cassowary dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Cassowary dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Cassowary jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Cassowary
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Cassowary dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Cassowary dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Cassowary yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Cassowary berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Cassowary
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Cassowary tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Cassowary tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Cassowary tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Cassowary
    */
  const bool jinak = true;
};

class Chameleon {
public:
  /** @brief Constructor dari Chameleon
    * Menghidupkan sebuah objek Chameleon
    * @param x integer adalah letak absis Chameleon yang dihidupkan
    * @param y integer adalah letak ordinat Chameleon yang dihidupkan
    * @param bb integer adalah berat badan Chameleon yang dihidupkan
    */
  Chameleon(int bb, int x, int y);
  /** @brief Destructor dari Chameleon
    * Menghilangkan alokasi memori objek Chameleon
    */
  ~Chameleon();
  /** @brief Getter berat badan sebuah objek Chameleon
    * Mengembalikan nilai integer berat badan sebuah objek Chameleon
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Chameleon
    * Mengembalikan nilai Indices koordinat objek Chameleon
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Chameleon
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Chameleon
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Chameleon
    * I.S Chameleon telah dihidupkan
    * F.S interaksi Chameleon tercetak ke layar
    * Mencetak interaksi Chameleon ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Chameleon dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Chameleon dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Chameleon dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Chameleon jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Chameleon
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Chameleon dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Chameleon dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Chameleon yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Chameleon berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Chameleon
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Chameleon tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Chameleon tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Chameleon tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Chameleon
    */
  const bool jinak = true;
};

class Cheetah {
public:
  /** @brief Constructor dari Cheetah
    * Menghidupkan sebuah objek Cheetah
    * @param x integer adalah letak absis Cheetah yang dihidupkan
    * @param y integer adalah letak ordinat Cheetah yang dihidupkan
    * @param bb integer adalah berat badan Cheetah yang dihidupkan
    */
  Cheetah(int bb, int x, int y);
  /** @brief Destructor dari Cheetah
    * Menghilangkan alokasi memori objek Cheetah
    */
  ~Cheetah();
  /** @brief Getter berat badan sebuah objek Cheetah
    * Mengembalikan nilai integer berat badan sebuah objek Cheetah
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Cheetah
    * Mengembalikan nilai Indices koordinat objek Cheetah
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Cheetah
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Cheetah
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Cheetah
    * I.S Cheetah telah dihidupkan
    * F.S interaksi Cheetah tercetak ke layar
    * Mencetak interaksi Cheetah ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Cheetah dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Cheetah dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Cheetah dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Cheetah jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Cheetah
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Cheetah dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Cheetah dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Cheetah yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Cheetah berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Cheetah
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Cheetah tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Cheetah tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Cheetah tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Cheetah
    */
  const bool jinak = true;
};

class Cockatoo {
public:
  /** @brief Constructor dari Cockatoo
    * Menghidupkan sebuah objek Cockatoo
    * @param x integer adalah letak absis Cockatoo yang dihidupkan
    * @param y integer adalah letak ordinat Cockatoo yang dihidupkan
    * @param bb integer adalah berat badan Cockatoo yang dihidupkan
    */
  Cockatoo(int bb, int x, int y);
  /** @brief Destructor dari Cockatoo
    * Menghilangkan alokasi memori objek Cockatoo
    */
  ~Cockatoo();
  /** @brief Getter berat badan sebuah objek Cockatoo
    * Mengembalikan nilai integer berat badan sebuah objek Cockatoo
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Cockatoo
    * Mengembalikan nilai Indices koordinat objek Cockatoo
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Cockatoo
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Cockatoo
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Cockatoo
    * I.S Cockatoo telah dihidupkan
    * F.S interaksi Cockatoo tercetak ke layar
    * Mencetak interaksi Cockatoo ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Cockatoo dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Cockatoo dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Cockatoo dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Cockatoo jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Cockatoo
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Cockatoo dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Cockatoo dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Cockatoo yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Cockatoo berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Cockatoo
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Cockatoo tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Cockatoo tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Cockatoo tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Cockatoo
    */
  const bool jinak = true;
};

class Deer {
public:
  /** @brief Constructor dari Deer
    * Menghidupkan sebuah objek Deer
    * @param x integer adalah letak absis Deer yang dihidupkan
    * @param y integer adalah letak ordinat Deer yang dihidupkan
    * @param bb integer adalah berat badan Deer yang dihidupkan
    */
  Deer(int bb, int x, int y);
  /** @brief Destructor dari Deer
    * Menghilangkan alokasi memori objek Deer
    */
  ~Deer();
  /** @brief Getter berat badan sebuah objek Deer
    * Mengembalikan nilai integer berat badan sebuah objek Deer
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Deer
    * Mengembalikan nilai Indices koordinat objek Deer
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Deer
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Deer
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Deer
    * I.S Deer telah dihidupkan
    * F.S interaksi Deer tercetak ke layar
    * Mencetak interaksi Deer ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Deer dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Deer dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Deer dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Deer jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Deer
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Deer dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Deer dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Deer yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Deer berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Deer
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Deer tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Deer tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Deer tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Deer
    */
  const bool jinak = true;
};

class Dolphin {
public:
  /** @brief Constructor dari Dolphin
    * Menghidupkan sebuah objek Dolphin
    * @param x integer adalah letak absis Dolphin yang dihidupkan
    * @param y integer adalah letak ordinat Dolphin yang dihidupkan
    * @param bb integer adalah berat badan Dolphin yang dihidupkan
    */
  Dolphin(int bb, int x, int y);
  /** @brief Destructor dari Dolphin
    * Menghilangkan alokasi memori objek Dolphin
    */
  ~Dolphin();
  /** @brief Getter berat badan sebuah objek Dolphin
    * Mengembalikan nilai integer berat badan sebuah objek Dolphin
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Dolphin
    * Mengembalikan nilai Indices koordinat objek Dolphin
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Dolphin
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Dolphin
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Dolphin
    * I.S Dolphin telah dihidupkan
    * F.S interaksi Dolphin tercetak ke layar
    * Mencetak interaksi Dolphin ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Dolphin dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Dolphin dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Dolphin dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Dolphin jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Dolphin
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Dolphin dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Dolphin dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Dolphin yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Dolphin berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Dolphin
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Dolphin tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Dolphin tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Dolphin tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Dolphin
    */
  const bool jinak = true;
};

class Duck {
public:
  /** @brief Constructor dari Duck
    * Menghidupkan sebuah objek Duck
    * @param x integer adalah letak absis Duck yang dihidupkan
    * @param y integer adalah letak ordinat Duck yang dihidupkan
    * @param bb integer adalah berat badan Duck yang dihidupkan
    */
  Duck(int bb, int x, int y);
  /** @brief Destructor dari Duck
    * Menghilangkan alokasi memori objek Duck
    */
  ~Duck();
  /** @brief Getter berat badan sebuah objek Duck
    * Mengembalikan nilai integer berat badan sebuah objek Duck
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Duck
    * Mengembalikan nilai Indices koordinat objek Duck
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Duck
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Duck
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Duck
    * I.S Duck telah dihidupkan
    * F.S interaksi Duck tercetak ke layar
    * Mencetak interaksi Duck ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Duck dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Duck dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Duck dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Duck jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Duck
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Duck dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Duck dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Duck yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Duck berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Duck
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Duck tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Duck tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Duck tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Duck
    */
  const bool jinak = true;
};

class Giraffe {
public:
  /** @brief Constructor dari Giraffe
    * Menghidupkan sebuah objek Giraffe
    * @param x integer adalah letak absis Giraffe yang dihidupkan
    * @param y integer adalah letak ordinat Giraffe yang dihidupkan
    * @param bb integer adalah berat badan Giraffe yang dihidupkan
    */
  Giraffe(int bb, int x, int y);
  /** @brief Destructor dari Giraffe
    * Menghilangkan alokasi memori objek Giraffe
    */
  ~Giraffe();
  /** @brief Getter berat badan sebuah objek Giraffe
    * Mengembalikan nilai integer berat badan sebuah objek Giraffe
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Giraffe
    * Mengembalikan nilai Indices koordinat objek Giraffe
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Giraffe
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Giraffe
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Giraffe
    * I.S Giraffe telah dihidupkan
    * F.S interaksi Giraffe tercetak ke layar
    * Mencetak interaksi Giraffe ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Giraffe dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Giraffe dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Giraffe dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Giraffe jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Giraffe
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Giraffe dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Giraffe dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Giraffe yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Giraffe berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Giraffe
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Giraffe tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Giraffe tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Giraffe tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Giraffe
    */
  const bool jinak = true;
};

class Gorilla {
public:
  /** @brief Constructor dari Gorilla
    * Menghidupkan sebuah objek Gorilla
    * @param x integer adalah letak absis Gorilla yang dihidupkan
    * @param y integer adalah letak ordinat Gorilla yang dihidupkan
    * @param bb integer adalah berat badan Gorilla yang dihidupkan
    */
  Gorilla(int bb, int x, int y);
  /** @brief Destructor dari Gorilla
    * Menghilangkan alokasi memori objek Gorilla
    */
  ~Gorilla();
  /** @brief Getter berat badan sebuah objek Gorilla
    * Mengembalikan nilai integer berat badan sebuah objek Gorilla
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Gorilla
    * Mengembalikan nilai Indices koordinat objek Gorilla
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Gorilla
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Gorilla
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Gorilla
    * I.S Gorilla telah dihidupkan
    * F.S interaksi Gorilla tercetak ke layar
    * Mencetak interaksi Gorilla ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Gorilla dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Gorilla dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Gorilla dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Gorilla jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Gorilla
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Gorilla dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Gorilla dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Gorilla yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Gorilla berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Gorilla
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Gorilla tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Gorilla tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Gorilla tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Gorilla
    */
  const bool jinak = true;
};

class GreatWhiteShark {
public:
  /** @brief Constructor dari GreatWhiteShark
    * Menghidupkan sebuah objek GreatWhiteShark
    * @param x integer adalah letak absis GreatWhiteShark yang dihidupkan
    * @param y integer adalah letak ordinat GreatWhiteShark yang dihidupkan
    * @param bb integer adalah berat badan GreatWhiteShark yang dihidupkan
    */
  GreatWhiteShark(int bb, int x, int y);
  /** @brief Destructor dari GreatWhiteShark
    * Menghilangkan alokasi memori objek GreatWhiteShark
    */
  ~GreatWhiteShark();
  /** @brief Getter berat badan sebuah objek GreatWhiteShark
    * Mengembalikan nilai integer berat badan sebuah objek GreatWhiteShark
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek GreatWhiteShark
    * Mengembalikan nilai Indices koordinat objek GreatWhiteShark
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari GreatWhiteShark
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari GreatWhiteShark
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek GreatWhiteShark
    * I.S GreatWhiteShark telah dihidupkan
    * F.S interaksi GreatWhiteShark tercetak ke layar
    * Mencetak interaksi GreatWhiteShark ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah GreatWhiteShark dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah GreatWhiteShark dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah GreatWhiteShark dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah GreatWhiteShark jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek GreatWhiteShark
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah GreatWhiteShark dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk GreatWhiteShark dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat GreatWhiteShark yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana GreatWhiteShark berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek GreatWhiteShark
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah GreatWhiteShark tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah GreatWhiteShark tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah GreatWhiteShark tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya GreatWhiteShark
    */
  const bool jinak = true;
};

class Lemur {
public:
  /** @brief Constructor dari Lemur
    * Menghidupkan sebuah objek Lemur
    * @param x integer adalah letak absis Lemur yang dihidupkan
    * @param y integer adalah letak ordinat Lemur yang dihidupkan
    * @param bb integer adalah berat badan Lemur yang dihidupkan
    */
  Lemur(int bb, int x, int y);
  /** @brief Destructor dari Lemur
    * Menghilangkan alokasi memori objek Lemur
    */
  ~Lemur();
  /** @brief Getter berat badan sebuah objek Lemur
    * Mengembalikan nilai integer berat badan sebuah objek Lemur
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Lemur
    * Mengembalikan nilai Indices koordinat objek Lemur
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Lemur
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Lemur
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Lemur
    * I.S Lemur telah dihidupkan
    * F.S interaksi Lemur tercetak ke layar
    * Mencetak interaksi Lemur ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Lemur dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Lemur dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Lemur dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Lemur jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Lemur
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Lemur dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Lemur dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Lemur yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Lemur berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Lemur
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Lemur tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Lemur tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Lemur tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Lemur
    */
  const bool jinak = true;
};

class Lion {
public:
  /** @brief Constructor dari Lion
    * Menghidupkan sebuah objek Lion
    * @param x integer adalah letak absis Lion yang dihidupkan
    * @param y integer adalah letak ordinat Lion yang dihidupkan
    * @param bb integer adalah berat badan Lion yang dihidupkan
    */
  Lion(int bb, int x, int y);
  /** @brief Destructor dari Lion
    * Menghilangkan alokasi memori objek Lion
    */
  ~Lion();
  /** @brief Getter berat badan sebuah objek Lion
    * Mengembalikan nilai integer berat badan sebuah objek Lion
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Lion
    * Mengembalikan nilai Indices koordinat objek Lion
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Lion
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Lion
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Lion
    * I.S Lion telah dihidupkan
    * F.S interaksi Lion tercetak ke layar
    * Mencetak interaksi Lion ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Lion dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Lion dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Lion dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Lion jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Lion
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Lion dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Lion dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Lion yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Lion berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Lion
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Lion tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Lion tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Lion tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Lion
    */
  const bool jinak = true;
};

class Meerkat {
public:
  /** @brief Constructor dari Meerkat
    * Menghidupkan sebuah objek Meerkat
    * @param x integer adalah letak absis Meerkat yang dihidupkan
    * @param y integer adalah letak ordinat Meerkat yang dihidupkan
    * @param bb integer adalah berat badan Meerkat yang dihidupkan
    */
  Meerkat(int bb, int x, int y);
  /** @brief Destructor dari Meerkat
    * Menghilangkan alokasi memori objek Meerkat
    */
  ~Meerkat();
  /** @brief Getter berat badan sebuah objek Meerkat
    * Mengembalikan nilai integer berat badan sebuah objek Meerkat
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Meerkat
    * Mengembalikan nilai Indices koordinat objek Meerkat
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Meerkat
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Meerkat
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Meerkat
    * I.S Meerkat telah dihidupkan
    * F.S interaksi Meerkat tercetak ke layar
    * Mencetak interaksi Meerkat ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Meerkat dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Meerkat dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Meerkat dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Meerkat jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Meerkat
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Meerkat dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Meerkat dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Meerkat yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Meerkat berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Meerkat
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Meerkat tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Meerkat tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Meerkat tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Meerkat
    */
  const bool jinak = true;
};

class Monkey {
public:
  /** @brief Constructor dari Meerkat
    * Menghidupkan sebuah objek Meerkat
    * @param x integer adalah letak absis Monkey yang dihidupkan
    * @param y integer adalah letak ordinat Monkey yang dihidupkan
    * @param bb integer adalah berat badan Monkey yang dihidupkan
    */
  Monkey(int bb, int x, int y);
  /** @brief Destructor dari Monkey
    * Menghilangkan alokasi memori objek Monkey
    */
  ~Monkey();
  /** @brief Getter berat badan sebuah objek Monkey
    * Mengembalikan nilai integer berat badan sebuah objek Monkey
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Monkey
    * Mengembalikan nilai Indices koordinat objek Monkey
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Monkey
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Monkey
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Monkey
    * I.S Monkey telah dihidupkan
    * F.S interaksi Monkey tercetak ke layar
    * Mencetak interaksi Monkey ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Monkey dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Monkey dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Monkey dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Monkey jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Monkey
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Monkey dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Monkey dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat XX yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana XX berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Monkey
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Monkey tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Monkey tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Monkey tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Monkey
    */
  const bool jinak = true;
};

class Orca {
public:
  /** @brief Constructor dari Orca
    * Menghidupkan sebuah objek Orca
    * @param x integer adalah letak absis Orca yang dihidupkan
    * @param y integer adalah letak ordinat Orca yang dihidupkan
    * @param bb integer adalah berat badan Orca yang dihidupkan
    */
  Orca(int bb, int x, int y);
  /** @brief Destructor dari Orca
    * Menghilangkan alokasi memori objek Orca
    */
  ~Orca();
  /** @brief Getter berat badan sebuah objek Orca
    * Mengembalikan nilai integer berat badan sebuah objek Orca
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Orca
    * Mengembalikan nilai Indices koordinat objek Orca
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Orca
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Orca
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Orca
    * I.S Orca telah dihidupkan
    * F.S interaksi Orca tercetak ke layar
    * Mencetak interaksi Orca ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Orca dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Orca dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Orca dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Orca jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Orca
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Orca dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Orca dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Orca yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Orca berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Orca
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Orca tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Orca tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Orca tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Orca
    */
  const bool jinak = true;
};

class Owl {
public:
  /** @brief Constructor dari Owl
    * Menghidupkan sebuah objek Owl
    * @param x integer adalah letak absis Owl yang dihidupkan
    * @param y integer adalah letak ordinat Owl yang dihidupkan
    * @param bb integer adalah berat badan Owl yang dihidupkan
    */
  Owl(int bb, int x, int y);
  /** @brief Destructor dari Owl
    * Menghilangkan alokasi memori objek Owl
    */
  ~Owl();
  /** @brief Getter berat badan sebuah objek Owl
    * Mengembalikan nilai integer berat badan sebuah objek Owl
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Owl
    * Mengembalikan nilai Indices koordinat objek Owl
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Owl
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Owl
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Owl
    * I.S Owl telah dihidupkan
    * F.S interaksi Owl tercetak ke layar
    * Mencetak interaksi Owl ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Owl dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Owl dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Owl dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Owl jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Owl
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Owl dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Owl dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Owl yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Owl berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Owl
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Owl tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Owl tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Owl tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Owl
    */
  const bool jinak = true;
};

class Parrots {
public:
  /** @brief Constructor dari Parrots
    * Menghidupkan sebuah objek Parrots
    * @param x integer adalah letak absis Parrots yang dihidupkan
    * @param y integer adalah letak ordinat Parrots yang dihidupkan
    * @param bb integer adalah berat badan Parrots yang dihidupkan
    */
  Parrots(int bb, int x, int y);
  /** @brief Destructor dari Parrots
    * Menghilangkan alokasi memori objek Parrots
    */
  ~Parrots();
  /** @brief Getter berat badan sebuah objek Parrots
    * Mengembalikan nilai integer berat badan sebuah objek Parrots
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Parrots
    * Mengembalikan nilai Indices koordinat objek Parrots
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Parrots
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Parrots
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Parrots
    * I.S Parrots telah dihidupkan
    * F.S interaksi Parrots tercetak ke layar
    * Mencetak interaksi Parrots ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Parrots dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Parrots dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Parrots dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Parrots jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Parrots
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Parrots dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Parrots dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Parrots yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Parrots berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Parrots
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Parrots tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Parrots tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Parrots tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Parrots
    */
  const bool jinak = true;
};

class Python {
public:
  /** @brief Constructor dari Python
    * Menghidupkan sebuah objek Python
    * @param x integer adalah letak absis Python yang dihidupkan
    * @param y integer adalah letak ordinat Python yang dihidupkan
    * @param bb integer adalah berat badan Python yang dihidupkan
    */
  Python(int bb, int x, int y);
  /** @brief Destructor dari Python
    * Menghilangkan alokasi memori objek Python
    */
  ~Python();
  /** @brief Getter berat badan sebuah objek Python
    * Mengembalikan nilai integer berat badan sebuah objek Python
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Python
    * Mengembalikan nilai Indices koordinat objek Python
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Python
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Python
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Python
    * I.S Python telah dihidupkan
    * F.S interaksi Python tercetak ke layar
    * Mencetak interaksi Python ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Python dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Python dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Python dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Python jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Python
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Python dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Python dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Python yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Python berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Python
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Python tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Python tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Python tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Python
    */
  const bool jinak = true;
};

class Swan {
public:
  /** @brief Constructor dari Swan
    * Menghidupkan sebuah objek Swan
    * @param x integer adalah letak absis Swan yang dihidupkan
    * @param y integer adalah letak ordinat Swan yang dihidupkan
    * @param bb integer adalah berat badan Swan yang dihidupkan
    */
  Swan(int bb, int x, int y);
  /** @brief Destructor dari Swan
    * Menghilangkan alokasi memori objek Swan
    */
  ~Swan();
  /** @brief Getter berat badan sebuah objek Swan
    * Mengembalikan nilai integer berat badan sebuah objek Swan
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Swan
    * Mengembalikan nilai Indices koordinat objek Swan
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Swan
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Swan
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Swan
    * I.S Swan telah dihidupkan
    * F.S interaksi Swan tercetak ke layar
    * Mencetak interaksi Swan ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Swan dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Swan dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Swan dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Swan jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Swan
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Swan dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Swan dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Swan yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Swan berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Swan
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Swan tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Swan tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Swan tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Swan
    */
  const bool jinak = true;
};

class Tarsier {
public:
  /** @brief Constructor dari Tarsier
    * Menghidupkan sebuah objek Tarsier
    * @param x integer adalah letak absis Tarsier yang dihidupkan
    * @param y integer adalah letak ordinat Tarsier yang dihidupkan
    * @param bb integer adalah berat badan Tarsier yang dihidupkan
    */
  Tarsier(int bb, int x, int y);
  /** @brief Destructor dari Tarsier
    * Menghilangkan alokasi memori objek Tarsier
    */
  ~Tarsier();
  /** @brief Getter berat badan sebuah objek Tarsier
    * Mengembalikan nilai integer berat badan sebuah objek Tarsier
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Tarsier
    * Mengembalikan nilai Indices koordinat objek Tarsier
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Tarsier
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Tarsier
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Tarsier
    * I.S Tarsier telah dihidupkan
    * F.S interaksi Tarsier tercetak ke layar
    * Mencetak interaksi Tarsier ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Tarsier dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Tarsier dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Tarsier dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Tarsier jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Tarsier
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Tarsier dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Tarsier dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Tarsier yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Tarsier berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Tarsier
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Tarsier tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Tarsier tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Tarsier tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Tarsier
    */
  const bool jinak = true;
};

class Wolf {
public:
  /** @brief Constructor dari Wolf
    * Menghidupkan sebuah objek Wolf
    * @param x integer adalah letak absis Wolf yang dihidupkan
    * @param y integer adalah letak ordinat Wolf yang dihidupkan
    * @param bb integer adalah berat badan Wolf yang dihidupkan
    */
  Wolf(int bb, int x, int y);
  /** @brief Destructor dari Wolf
    * Menghilangkan alokasi memori objek Wolf
    */
  ~Wolf();
  /** @brief Getter berat badan sebuah objek Wolf
    * Mengembalikan nilai integer berat badan sebuah objek Wolf
    */
  int GetBerat();
  /** @brief Getter koordinat sebuah objek Wolf
    * Mengembalikan nilai Indices koordinat objek Wolf
    */
  Indices GetKoordinat();
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void SetBerat(int bb);
  /** @brief Prosedur SetKoordinat  dari Wolf
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai koordinat dari Wolf
    *
    * @param x integer menyatakan absis yang ingin diset
    * @param y integer menyatakan ordinat yang ingin diset
    */
  void SetKoordinat(int x, int y);
  /** @brief prosedur Interact dari objek Wolf
    * I.S Wolf telah dihidupkan
    * F.S interaksi Wolf tercetak ke layar
    * Mencetak interaksi Wolf ke layar
    */
  void Interact();	
  /** @brief Mengembalikan nilai boolean apakah Wolf dapat hidup di Land
    */
  bool IsLandAnimal();
  /** @brief Mengembalikan nilai boolean apakah Wolf dapat hidup di Water
    */
  bool IsWaterAnimal();
  /** @brief Mengembalikan nilai boolean apakah Wolf dapat hidup di Air
    */
  bool IsAirAnimal();
  /** @brief Mengembalikan nilai boolean apakah Wolf jinak
    */
  bool IsJinak();
  /** @brief Mengembalikan nilai kode char dari objek Wolf
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
  /** @brief Mengembalikan nilai boolean apakah Wolf dapat tinggal pada Cell berkode c atau tidak
    *
    * @param c char yang dicek untuk Wolf dapat tinggal atau tidak
    */
  bool IsLivable(char c);
private:
  /** @brief Atribut berat_badan  menyatakan berapa berat Wolf yang bersangkutan
    */
  int berat_badan;
  /** @brief Atribut koordinat  adalah letak dimana Wolf berada
    */
  Indices koordinat;
  /** @brief Atribut makanan objek Wolf
    */
  const int makanan = 0; //Herbivore = 0; Omnivore = 1; Carnivore = 2;
  /** @brief Atribut land_animal  adalah boolean yang menyatakan dapatkah Wolf tinggal di darat
    */
  const bool land_animal = true;
  /** @brief Atribut water_animal  adalah boolean yang menyatakan dapatkah Wolf tinggal di air
    */
  const bool water_animal = true;
  /** @brief Atribut air_animal  adalah boolean yang menyatakan dapatkah Wolf tinggal di udara
    */
  const bool air_animal = true;
  /** @brief Atribut jinak  adalah boolean yang menyatakan jinak atau tidaknya Wolf
    */
  const bool jinak = true;
};

