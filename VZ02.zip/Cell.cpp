//file Cell.cpp
#include "Cell.h"
#include "Indices.h"

	Park::Park(Indices I): code('P') {
		koordinat = I;
	}
	//Cell(Cell& C);
	Park::~Park() {}
	//Cell& operator= (Cell& C);
	Indices Park::GetKoordinat() {
		return koordinat;
	}
	bool Park::IsHabitat() {
		return false;
	}
	bool Park::IsFacility() {
		return true;
	}
	char Park::GetCode() {
		return code;
	}
	bool Park::IsRoad() {
		return false;
	}
	bool Park::IsPark() {
		return true;
	}
	bool Park::IsRestaurant() {
		return false;
	}
	bool Park::IsLand() {
		return false;
	}
	bool Park::IsWater() {
		return false;	
	}
	bool Park::IsAir() {
		return false;
	}
	char Render() {
		return 'P';
	}

	
	Restaurant::Restaurant(Indices I): code('R') {
		koordinat = I;
	}
	//Cell(Cell& C);
	Restaurant::~Restaurant() {}
	//Cell& operator= (Cell& C);
	Indices Restaurant::GetKoordinat() {
		return koordinat;
	}
	bool Restaurant::IsHabitat() {
		return false;
	}
	bool Restaurant::IsFacility() {
		return true;
	}
	char Restaurant::GetCode() {
		return code;
	}
	bool Restaurant::IsRoad() {
		return false;
	}
	bool Restaurant::IsPark() {
		return true;
	}
	bool Restaurant::IsRestaurant() {
		return false;
	}
	bool Restaurant::IsLand() {
		return false;
	}
	bool Restaurant::IsWater() {
		return false;	
	}
	bool Restaurant::IsAir() {
		return false;
	}
	char Restaurant::Render() {
		return 'R';
	}
	
	
	Road::Road(Indices I, int t): code('P'), type(t) {
		koordinat = I;
	}
	//Cell(Cell& C);
	Road::~Road() {}
	//Cell& operator= (Cell& C);
	Indices Road::GetKoordinat() {
		return koordinat;
	}
	bool Road::IsHabitat() {
		return false;
	}
	bool Road::IsFacility() {
		return true;
	}
	char Road::GetCode() {
		return code;
	}
	bool Road::IsRoad() {
		return false;
	}
	bool Road::IsPark() {
		return true;
	}
	bool Road::IsRestaurant() {
		return false;
	}
	bool Road::IsLand() {
		return false;
	}
	bool Road::IsWater() {
		return false;	
	}
	bool Road::IsAir() {
		return false;
	}
	bool Road::IsEntrance() {
		return (type == 1);
	}
	bool Road::IsExit() {
		return (type == 2);
	}
	bool Road::IsNRoad() {
		return (type == 0);
	}
	char Road::Render() {
		if (IsEntrance()) {
			return '+';
		} else
		if (IsExit()) {
			return '=';
		} else {
			return '-';
		}
	}
	
	
	LandHabitat::LandHabitat(Indices I): code('l') {
		koordinat = I;
	}
	//Cell(Cell& C);
	LandHabitat::~LandHabitat() {}
	//Cell& operator= (Cell& C);
	Indices LandHabitat::GetKoordinat() {
		return koordinat;
	}
	bool LandHabitat::IsHabitat() {
		return false;
	}
	bool LandHabitat::IsFacility() {
		return true;
	}
	char LandHabitat::GetCode() {
		return code;
	}
	bool LandHabitat::IsRoad() {
		return false;
	}
	bool LandHabitat::IsPark() {
		return true;
	}
	bool LandHabitat::IsRestaurant() {
		return false;
	}
	bool LandHabitat::IsLand() {
		return false;
	}
	bool LandHabitat::IsWater() {
		return false;	
	}
	bool LandHabitat::IsAir() {
		return false;
	}
	char LandHabitat::Render() {
		return 'l';
	}
	
	
	WaterHabitat::WaterHabitat(Indices I): code('w') {
		koordinat = I;
	}
	//Cell(Cell& C);
	WaterHabitat::~WaterHabitat() {}
	//Cell& operator= (Cell& C);
	Indices WaterHabitat::GetKoordinat() {
		return koordinat;
	}
	bool WaterHabitat::IsHabitat() {
		return false;
	}
	bool WaterHabitat::IsFacility() {
		return true;
	}
	char WaterHabitat::GetCode() {
		return code;
	}
	bool WaterHabitat::IsRoad() {
		return false;
	}
	bool WaterHabitat::IsPark() {
		return true;
	}
	bool WaterHabitat::IsRestaurant() {
		return false;
	}
	bool WaterHabitat::IsLand() {
		return false;
	}
	bool WaterHabitat::IsWater() {
		return false;	
	}
	bool WaterHabitat::IsAir() {
		return false;
	}
	char WaterHabitat::Render() {
		return code;
	}
	
	
	AirHabitat::AirHabitat(Indices I): code('a') {
		koordinat = I;
	}
	//Cell(Cell& C);
	AirHabitat::~AirHabitat() {}
	//Cell& operator= (Cell& C);
	Indices AirHabitat::GetKoordinat() {
		return koordinat;
	}
	bool AirHabitat::IsHabitat() {
		return false;
	}
	bool AirHabitat::IsFacility() {
		return true;
	}
	char AirHabitat::GetCode() {
		return code;
	}
	bool AirHabitat::IsRoad() {
		return false;
	}
	bool AirHabitat::IsPark() {
		return true;
	}
	bool AirHabitat::IsRestaurant() {
		return false;
	}
	bool AirHabitat::IsLand() {
		return false;
	}
	bool AirHabitat::IsWater() {
		return false;	
	}
	bool AirHabitat::IsAir() {
		return false;
	}
	char AirHabitat::Render() {
		return code;
	}
