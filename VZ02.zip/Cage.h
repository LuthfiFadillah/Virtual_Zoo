//file Cage.h
#ifndef CAGE_H
#define CAGE_H

#include "Animals.h"
//#include "Habitat.h"
#include "Indices.h"

class Cage {
public:
	Cage();
	Cage(Indices *I, int Neff);
    Cage& operator= (const Cage& C);
	~Cage();
	bool IsHostOf(Indices I);
	bool Spacious();
	void AddAnimal(char c, int bb, int x, int y, bool jinak);
	void Inter();
	//bool IsCageOf(Beluga* A);
    void ** GetAnimals();
    int GetLuas();
    int GetBanyakHewan();
    bool IsAddable(bool jinak);
	
private:
	Indices* wilayah;
	void** data_animals;
	int luas;
	int banyak_hewan;
	
};

#endif
