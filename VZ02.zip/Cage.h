//file Cage.h
#ifndef CAGE_H
#define CAGE_H

#include "Animals.h"
//#include "Habitat.h"
#include "Indices.h"

class Cage {
public:
  /** @brief Constructor tanpa parameter dari Cage
    * Menghidupkan kandang
    */
  Cage();
  /** @brief Constructor dengan parameter dari Cage
    * Menghidupkan kandang sesuai dengan input parameter
    *
    * @param I array of Indices menyatakan Cell dengan indices mana saja yang tergabung dalam cage
    * @param Neff integer menyatakan banyaknya Indices yang ada pada array
    */
  Cage(Indices *I, int Neff);
  /** @brief Operator overloading = dari Cage
    * Memastikan bukan bitewise copy
    *
    * @param C menyatakan Cage yang ingin disalin
    */
  Cage& operator= (const Cage& C);
  /** @brief Destructor dari Cage
    * Menghilangkan alokasi memori Cage
    */
  ~Cage();
  /** @brief  Mengembalikan nilai boolean apakah indices termasuk pada cangkupan cage
    *
    * @param I adalah indices yang diperiksa sebagai bagian dari cage
    */
  bool IsHostOf(Indices I);
  /** @brief Mengembalikan nilai boolean apakah masih ada ruang untuk animal di cage tersebut
    */
  bool Spacious();
  /** @brief Prosedur AddAnimal dari Cage
    * I.S Cage telah hidup dan Masukkan terdefinisi sebagai hewan yang hidup
    * F.S Animal A tercatat pada Data Animals Cage
    * Menambahkan Animals A pada Data Animals Cage
    *
    * @param A adalah Pointer to Animals yang ingin dimasukkan di Data Animals
    */
  void AddAnimal(char c, int bb, int x, int y, bool jinak);
  /** @brief Prosedur Inter dari Cage
    * I.S Cage terdefinisi
    * F.S Memanggil semua prosedur interact dari animals yang ada di Cage
    * Mencetak semua suara binatang yang ada dalam kandang
    */
  void Inter();
  /** @brief Mengembalikan nilai boolean apakah animals tinggal di kandang tersebut
    * 
    * @param A adalah Pointer to Animals yang diperiksa
    */
  //bool IsCageOf(Beluga* A);
  /** @brief Mengembalikan nilai atribut DataAnimals 
    */
  void ** GetAnimals();
  /** @brief GetLuas dari cage
    * Mengembalikan nilai luas suatu kandang
    */
  int GetLuas();
  /** @brief GetBanyakHewan dari Cage
    * Mengembalikan nilai banyaknya hewan yang ada di suatu kandang
    */
  int GetBanyakHewan();
  //bool IsAddable(bool jinak);
private:
  /** @brief Atribut wilayah adalah setiap Indices yang dicakup oleh cage
    */
  Indices* wilayah;
  /** @brief Atribut data_animals adalah daftar hewan yang tinggal dalam cage
    */
  void** data_animals;
  /** @brief Atriubt luas adalah jumlah Indices pada wilayah
    */
  int luas;
  /** @brief Atribut banyak_hewan adalah jumlah hewan yang tinggal dalam cage
    */
  int banyak_hewan;
};

#endif
