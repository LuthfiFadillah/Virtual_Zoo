/** @brief Constructor dari XX
* Menghidupkan sebuah objek XX
* @param berat badan objek XX yang akan dihidupkan
* @param absis objek XX yang akan dihidupkan
* @param ordinat objek XX yang akan dihiupkan
*/

/** @brief Destructor dari XX
* Menghilangkan alokasi memori objek XX
*/
