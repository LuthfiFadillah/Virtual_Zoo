//file Cell.h
#ifndef CELL_H
#define CELL_H
#include "Indices.h"

class Park {
public:
	Park(Indices I);
	//Cell(Cell& C);
	~Park();
	//Cell& operator= (Cell& C);
	Indices GetKoordinat();
	bool IsHabitat();
	bool IsFacility();
	char GetCode();
	bool IsRoad();
	bool IsPark();
	bool IsRestaurant();
	bool IsLand();
	bool IsWater();
	bool IsAir();
	char Render();
	
private:
	Indices koordinat;
	const char code;
};


class Restaurant {
public:
	Restaurant(Indices I);
	//Cell(Cell& C);
	~Restaurant();
	//Cell& operator= (Cell& C);
	Indices GetKoordinat();
	bool IsHabitat();
	bool IsFacility();
	char GetCode();
	bool IsRoad();
	bool IsPark();
	bool IsRestaurant();
	bool IsLand();
	bool IsWater();
	bool IsAir();
	char Render();
	
private:
	Indices koordinat;
	const char code;
};


class Road {
public:
	Road(Indices I, int t);
	//Cell(Cell& C);
	~Road();
	//Cell& operator= (Cell& C);
	Indices GetKoordinat();
	bool IsHabitat();
	bool IsFacility();
	char GetCode();
	bool IsRoad();
	bool IsPark();
	bool IsRestaurant();
	bool IsLand();
	bool IsWater();
	bool IsAir();
	bool IsEntrance();
	bool IsExit();
	bool IsNRoad();
	char Render();
	
private:
	Indices koordinat;
	const char code;
	const int type;
};


class LandHabitat {
public:
	LandHabitat(Indices I);
	//Cell(Cell& C);
	~LandHabitat();
	//Cell& operator= (Cell& C);
	Indices GetKoordinat();
	bool IsHabitat();
	bool IsFacility();
	char GetCode();
	bool IsRoad();
	bool IsPark();
	bool IsRestaurant();
	bool IsLand();
	bool IsWater();
	bool IsAir();
	char Render();
	
private:
	Indices koordinat;
	const char code;
};


class WaterHabitat {
public:
	WaterHabitat(Indices I);
	//Cell(Cell& C);
	~WaterHabitat();
	//Cell& operator= (Cell& C);
	Indices GetKoordinat();
	bool IsHabitat();
	bool IsFacility();
	char GetCode();
	bool IsRoad();
	bool IsPark();
	bool IsRestaurant();
	bool IsLand();
	bool IsWater();
	bool IsAir();
	char Render();
	
private:
	Indices koordinat;
	const char code;
};


class AirHabitat {
public:
	AirHabitat(Indices I);
	//Cell(Cell& C);
	~AirHabitat();
	//Cell& operator= (Cell& C);
	Indices GetKoordinat();
	bool IsHabitat();
	bool IsFacility();
	char GetCode();
	bool IsRoad();
	bool IsPark();
	bool IsRestaurant();
	bool IsLand();
	bool IsWater();
	bool IsAir();
	char Render();
	
private:
	Indices koordinat;
	const char code;
};

#endif
