//file Cell.h
#ifndef CELL_H
#define CELL_H
#include "Indices.h"

class Park {
public:
  /** @brief Constructor dari Park
    * Menghidupkan Park
    *
    * @param I Indices adalah alamat dimana Park dihidupkan
    */
  Park(Indices I);
  /** @brief Destructor dari Park
    * Menghilangkan alokasi memori Park
    */
  ~Park();
  /** @brief Mengembalikan nilai Indices dimana Park berada
    */
  Indices GetKoordinat();
  /** @brief Mengembalikan nilai boolean apakah Park adalah habitat
    */
  bool IsHabitat();
  /** @brief Mengembalikan nilai boolean apakah Park adalah fasilitas
    */
  bool IsFacility();
  /** @brief Mengembalikan nilai char Code yang adalah atribut Park
    */
  char GetCode();
  /** @brief Mengembalikan nilai boolean apakah Park adalah road
    */
  bool IsRoad();
  /** @brief Mengembalikan nilai boolean apakah Park adalah park
    */
  bool IsPark();
  /** @brief Mengembalikan nilai boolean apakah Park adalah restaurant
    */
  bool IsRestaurant();
  /** @brief Mengembalikan nilai boolean apakah Park adalah land
    */
  bool IsLand();
  /** @brief Mengembalikan nilai boolean apakah Park adalah water
    */
  bool IsWater();
  /** @brief Mengembalikan nilai boolean apakah Park adalah air
    */
  bool IsAir();
  /** @brief Mengembalikan nilai kode char dari objek Park
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
private:
  /** @brief Atribut koordinat yang adalah Indices letak Park
    */
  Indices koordinat;
  /** @brief Atribut code yang adalah code dari Park
    */
  const char code;
};


class Restaurant {
public:
  /** @brief Constructor dari Restaurant
    * Menghidupkan Restaurant
    *
    * @param I Indices adalah alamat dimana Restaurant dihidupkan
    */
  Restaurant(Indices I);
  /** @brief Destructor dari Restaurant
    * Menghilangkan alokasi memori Restaurant
    */
  ~Restaurant();
  /** @brief Mengembalikan nilai Indices dimana Restaurant berada
    */
  Indices GetKoordinat();
  /** @brief Mengembalikan nilai boolean apakah Restaurant adalah habitat
    */
  bool IsHabitat();
  /** @brief Mengembalikan nilai boolean apakah Restaurant adalah fasilitas
    */
  bool IsFacility();
  /** @brief Mengembalikan nilai char Code yang adalah atribut Restaurant
    */
  char GetCode();
  /** @brief Mengembalikan nilai boolean apakah Restaurant adalah road
    */
  bool IsRoad();
  /** @brief Mengembalikan nilai boolean apakah Restaurant adalah park
    */
  bool IsPark();
  /** @brief Mengembalikan nilai boolean apakah Restaurant adalah restaurant
    */
  bool IsRestaurant();
  /** @brief Mengembalikan nilai boolean apakah Restaurant adalah land
    */
  bool IsLand();
  /** @brief Mengembalikan nilai boolean apakah Restaurant adalah water
    */
  bool IsWater();
  /** @brief Mengembalikan nilai boolean apakah Restaurant adalah air
    */
  bool IsAir();
  /** @brief Mengembalikan nilai kode char dari objek Restaurant
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
private:
  /** @brief Atribut koordinat yang adalah Indices letak Restaurant
    */
  Indices koordinat;
  /** @brief Atribut code yang adalah code dari Restaurant
    */
  const char code;
};


class LandHabitat {
public:
  /** @brief Constructor dari LandHabitat
    * Menghidupkan LandHabitat
    *
    * @param I Indices adalah alamat dimana LandHabitat dihidupkan
    */
  LandHabitat(Indices I);
  /** @brief Destructor dari LandHabitat
    * Menghilangkan alokasi memori LandHabitat
    */
  ~LandHabitat();
  /** @brief Mengembalikan nilai Indices dimana LandHabitat berada
    */
  Indices GetKoordinat();
  /** @brief Mengembalikan nilai boolean apakah LandHabitat adalah habitat
    */
  bool IsHabitat();
  /** @brief Mengembalikan nilai boolean apakah LandHabitat adalah fasilitas
    */
  bool IsFacility();
  /** @brief Mengembalikan nilai char Code yang adalah atribut LandHabitat
    */
  char GetCode();
  /** @brief Mengembalikan nilai boolean apakah LandHabitat adalah road
    */
  bool IsRoad();
  /** @brief Mengembalikan nilai boolean apakah LandHabitat adalah park
    */
  bool IsPark();
  /** @brief Mengembalikan nilai boolean apakah LandHabitat adalah restaurant
    */
  bool IsRestaurant();
  /** @brief Mengembalikan nilai boolean apakah LandHabitat adalah land
    */
  bool IsLand();
  /** @brief Mengembalikan nilai boolean apakah LandHabitat adalah water
    */
  bool IsWater();
  /** @brief Mengembalikan nilai boolean apakah LandHabitat adalah air
    */
  bool IsAir();
  /** @brief Mengembalikan nilai kode char dari objek LandHabitat
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
private:
  /** @brief Atribut koordinat yang adalah Indices letak LandHabitat
    */
  Indices koordinat;
  /** @brief Atribut code yang adalah code dari LandHabitat
    */
  const char code;
};


class WaterHabitat {
public:
  /** @brief Constructor dari WaterHabitat
    * Menghidupkan WaterHabitat
    *
    * @param I Indices adalah alamat dimana WaterHabitat dihidupkan
    */
  WaterHabitat(Indices I);
  /** @brief Destructor dari WaterHabitat
    * Menghilangkan alokasi memori WaterHabitat
    */
  ~WaterHabitat();
  /** @brief Mengembalikan nilai Indices dimana WaterHabitat berada
    */
  Indices GetKoordinat();
  /** @brief Mengembalikan nilai boolean apakah WaterHabitat adalah habitat
    */
  bool IsHabitat();
  /** @brief Mengembalikan nilai boolean apakah WaterHabitat adalah fasilitas
    */
  bool IsFacility();
  /** @brief Mengembalikan nilai char Code yang adalah atribut WaterHabitat
    */
  char GetCode();
  /** @brief Mengembalikan nilai boolean apakah WaterHabitat adalah road
    */
  bool IsRoad();
  /** @brief Mengembalikan nilai boolean apakah WaterHabitat adalah park
    */
  bool IsPark();
  /** @brief Mengembalikan nilai boolean apakah WaterHabitat adalah restaurant
    */
  bool IsRestaurant();
  /** @brief Mengembalikan nilai boolean apakah WaterHabitat adalah land
    */
  bool IsLand();
  /** @brief Mengembalikan nilai boolean apakah WaterHabitat adalah water
    */
  bool IsWater();
  /** @brief Mengembalikan nilai boolean apakah WaterHabitat adalah air
    */
  bool IsAir();
  /** @brief Mengembalikan nilai kode char dari objek WaterHabitat
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
private:
  /** @brief Atribut koordinat yang adalah Indices letak XX
    */
  Indices koordinat;
  /** @brief Atribut code yang adalah code dari XX
    */
  const char code;
};

class AirHabitat {
public:
  /** @brief Constructor dari AirHabitat
    * Menghidupkan AirHabitat
    *
    * @param I Indices adalah alamat dimana AirHabitat dihidupkan
    */
  AirHabitat(Indices I);
  /** @brief Destructor dari AirHabitat
    * Menghilangkan alokasi memori AirHabitat
    */
  ~AirHabitat();
  /** @brief Mengembalikan nilai Indices dimana AirHabitat berada
    */
  Indices GetKoordinat();
  /** @brief Mengembalikan nilai boolean apakah AirHabitat adalah habitat
    */
  bool IsHabitat();
  /** @brief Mengembalikan nilai boolean apakah AirHabitat adalah fasilitas
    */
  bool IsFacility();
  /** @brief Mengembalikan nilai char Code yang adalah atribut AirHabitat
    */
  char GetCode();
  /** @brief Mengembalikan nilai boolean apakah AirHabitat adalah road
    */
  bool IsRoad();
  /** @brief Mengembalikan nilai boolean apakah AirHabitat adalah park
    */
  bool IsPark();
  /** @brief Mengembalikan nilai boolean apakah AirHabitat adalah restaurant
    */
  bool IsRestaurant();
  /** @brief Mengembalikan nilai boolean apakah AirHabitat adalah land
    */
  bool IsLand();
  /** @brief Mengembalikan nilai boolean apakah AirHabitat adalah water
    */
  bool IsWater();
  /** @brief Mengembalikan nilai boolean apakah AirHabitat adalah air
    */
  bool IsAir();
  /** @brief Mengembalikan nilai kode char dari objek AirHabitat
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
private:
  /** @brief Atribut koordinat yang adalah Indices letak AirHabitat
    */
  Indices koordinat;
  /** @brief Atribut code yang adalah code dari AirHabitat
    */
  const char code;
};


class Road {
public:
  /** @brief Constructor dari Road
    * Menghidupkan Road
    *
    * @param I Indices adalah alamat dimana Road dihidupkan
    */
  Road(Indices I);
  /** @brief Destructor dari Road
    * Menghilangkan alokasi memori Road
    */
  ~Road();
  /** @brief Mengembalikan nilai Indices dimana Road berada
    */
  Indices GetKoordinat();
  /** @brief Mengembalikan nilai boolean apakah Road adalah habitat
    */
  bool IsHabitat();
  /** @brief Mengembalikan nilai boolean apakah Road adalah fasilitas
    */
  bool IsFacility();
  /** @brief Mengembalikan nilai char Code yang adalah atribut Road
    */
  char GetCode();
  /** @brief Mengembalikan nilai boolean apakah Road adalah road
    */
  bool IsRoad();
  /** @brief Mengembalikan nilai boolean apakah Road adalah park
    */
  bool IsPark();
  /** @brief Mengembalikan nilai boolean apakah Road adalah restaurant
    */
  bool IsRestaurant();
  /** @brief Mengembalikan nilai boolean apakah Road adalah land
    */
  bool IsLand();
  /** @brief Mengembalikan nilai boolean apakah Road adalah water
    */
  bool IsWater();
  /** @brief Mengembalikan nilai boolean apakah Road adalah air
    */
  bool IsAir();
  /** @brief Mengembalikan nilai boolean apakah Road adalah pintu masuk
    */
  bool IsEntrance();
  /** @brief Mengembalikan nilai boolean apakah Road adalah pintu keluar
    */
  bool IsExit();
  /** @brief Mengembalikan nilai boolean apakah Road adalah jalan biasa
    */
  bool IsNRoad();
  /** @brief Mengembalikan nilai char dari objek Objek
    * char ini nantinya yang siap dicetak ke layar
    */
  char Render();
private:
  /** @brief Atribut koordinat yang adalah Indices letak Road
    */
  Indices koordinat;
  /** @brief Atribut code yang adalah code dari Road
    */
  const char code;
};
