//file: Zoo.h
#ifndef ZOO_H
#define ZOO_H
#include "Cell.h"
#include "Cage.h"

class Zoo {
public:
  /** @brief Constructor dari Zoo
    * Menghidupkan kebun binatang
    */
  Zoo();
  /** @brief Destructor dari Zoo
    * Menghilangkan alokasi memori Zoo
    */
  ~Zoo();
  /** @brief Prosedur Move
    * I.S Semua elemen dalam kebun binatang telah dihidupkan
    * F.S Semua Animals dalam berpindah tempat
    * Menggerakkan hewan yang ada didalam kebun binatang
    */ 
  void Move();
  /** @brief Prosedur Print
    * I.S Zoo telah hidup
    * F.S Semua elemen zoo tercetak pada layar
    * Mencetak kebun binatang beserta seluruh elemennya ke layar
    */ 
  void Print();
  /** @brief Prosedur Hitung Makanan
    * I.S Zoo telah hidup
    * F.S Jumlah makanan yang dibutuhkan kebun binatang setiap harinya tercetak di layar
    * Mengkalkulasikan jumlah makanan yang diperlukan hewan-hewan yang hidup di kebun binatang
    * Mencetak hasil kalkulasi jumlah makanan ke layar
    */
  void HitungMakanan();
  /** @brief Mengembalikan nilai booleaan apakah indeks I bersebelahan dengan kandang C
    * 
    * @param I adalah indeks yang akan diperiksa
    * @param C adalah kandang yang akan diperiksa
    */
  bool IsInteractable(Indices I, Cage C);
  /** @brief Getter daftar kandang pada zoo
    */
  Cage* GetKandang();
private:
  /** @brief Atribut map adalah map pada zoo
    */
  Road **map;
  /** @brief Atribut daftar_kandang adalah daftar kandang pada zoo
    */
  Cage *daftar_kandang;
  /** @brief Atribut lebar adalah lebar map pada zoo
    */
  int lebar;
  /** @brief Atribut panjang adalah panjang map pada zoo
    */
  int panjang;
  /** @brief Atribut banyak_kandang adalah jumlah kandang yang ada pada zoo
    */
  int banyak_kandang;
  /** @brief Atribut ready_to_print adalah map yang siap diprint pada zoo
    * yaitu yang menyimpan status posisi hewan juga
    */
  char **ready_to_print;
  /** @brief Atribut base_map adalah map yang dasar pada zoo
    * yaitu yang hanya menyimpan jenis sel pada zoo
    */ 
  char **base_map;
  /** @brief Atribut DEFSIZE adalah nilai default panjang dan lebar zoo
    */
  int DEFSIZE=20;
};

#endif
