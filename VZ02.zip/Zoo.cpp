//File: Zoo.cpp
#include "Zoo.h"
#include "Cell.h"
#include "Animals.h"
#include "Cage.h"
#include "Indices.h"
#include <time.h>
#include <cstdio>
#include <string>
#include <fstream>
#include <iostream>
using namespace std;

	Zoo::Zoo() {
		ifstream filezoo;
		filezoo.open("map.txt", ios::in);
		//FILE *fp;
		string brs;
		int bwh=0;
		int samping=0;
		int BK=0;
		int i;
		Indices **Temp;
		
		if (filezoo.is_open()) {
			/*
			fp = fopen("zoo.txt", "r");
			fgets(brs,sizeof(brs),fp);
			*/
			
			filezoo >> brs;
			for(i=0; i<brs.length(); i++) {
				bwh = (bwh*10)+ ((int) brs[i] -48); 
			}
			
			//fgets(brs, sizeof(brs); i++);
			filezoo >> brs;
			for (i=0; i<brs.length(); i++) {
				samping = (samping*10) + ((int) brs[i] -48);
			}
			
			//fgets(brs,sizeof(brs); i++);
			filezoo >> brs;
			for (i=0; i<brs.length(); i++) {
				BK = (BK*10) + ((int) brs[i] -48);
			}
			
			Temp = new Indices *[BK];
			for (i=0; i<BK; i++){
				Temp[i]= new Indices [25]; //constraint: maksimal habitat dalam satu cage adalah 25
			}
			
			lebar = bwh;
			panjang = samping;
			base_map = new char* [lebar];
			for (i=0; i<lebar; i++) {
				base_map[i] = new char [panjang];
			}
		
			banyak_kandang = BK;
			int *NeffKandang;
			NeffKandang = new int [BK];
			for (i=0; i<banyak_kandang; i++) {
				NeffKandang[i] = 0;
			}
			char habitat;
			int code;
		
			Indices ind(0,0);
			WaterHabitat* wh;
			AirHabitat* ah;
			LandHabitat* lh;
			Road* s;
			Park* p;
			Restaurant* r;
			for (int i=0; i<bwh; i++) {
				//fgets(brs, sizeof(brs),fp);
				filezoo >> brs;
				int j=0;
				int k=0;
				while (j<samping*2) {
					ind.SetAbsis(k);
					ind.SetOrdinat(i);
					habitat = brs[j];
					if (habitat == 'W') {
						wh = new WaterHabitat(ind);
						base_map[i][k] = wh->Render();
						wh++;
					} else
					if (habitat == 'L') {
						lh = new LandHabitat(ind);
						base_map[i][k] = lh->Render();
						lh++;
					} else
					if (habitat == 'A') {
						ah = new AirHabitat(ind);
						base_map[i][k] = ah->Render();
						ah++;
					} else
					if (habitat == '-') {
						s = new Road(ind, 0);
						base_map[i][k] = s->Render();
						s++;
					} else
					if (habitat == '+') {
						s = new Road(ind, 1);
						base_map[i][k] = s->Render();
						s++;
					} else
					if (habitat == '=') {
						s = new Road(ind, 2);
						base_map[i][k] = s->Render();
						s++;
					} else
					if (habitat == 'P') {
						p = new Park(ind);
						base_map[i][k] = p->Render();
						p++;
					} else
					if (habitat == 'R') {
						r = new Restaurant(ind);
						base_map[i][k] = r->Render();
						r++;
					} else{
						
					}
					j++;
					k++;
				
					code = ((int) brs[j] -48);
					if (code != 0) {
						Temp[code-1][NeffKandang[code-1]] = ind;
						NeffKandang[code-1]++;
					}
				
					j++;
				}
			}
			filezoo.close();
			daftar_kandang = new Cage[banyak_kandang];
			Indices *TempI;
            //TempI =  new Indices [25];
			for (i=0; i<banyak_kandang; i++) {
                TempI =  new Indices [25];
				for (int j=0; j<NeffKandang[i]; j++) {
					TempI[j] = Temp[i][j];
				}
				Cage C(TempI,NeffKandang[i]);
				daftar_kandang[i] = C;
				C.~Cage();
                delete [] TempI;
			}
	
			for (i=0; i<lebar; i++) {
				for (int j=0; j<panjang; j++) {
                    ready_to_print[i][j] = base_map[i][j];
				}
			}
			
			i=0;
			//Cage 1
			daftar_kandang[i].AddAnimal('B',45,2,2,true);
			daftar_kandang[i].AddAnimal('N',45,1,1,true);
			daftar_kandang[i].AddAnimal('Q',45,0,0,true);
			i++;
			//Cage 2
			daftar_kandang[i].AddAnimal('O',10,19,0,true);
			daftar_kandang[i].AddAnimal('O',10,8,2,true);
			daftar_kandang[i].AddAnimal('X',10,17,0,true);
			i++;
			//Cage 3
			daftar_kandang[i].AddAnimal('I',100, 1, 4,false);
			daftar_kandang[i].AddAnimal('I',100, 1, 5,false);
			i++;
			//Cage 4
			daftar_kandang[i].AddAnimal('C',70, 6, 4,true);
			daftar_kandang[i].AddAnimal('Y',30, 6, 6,true);
			daftar_kandang[i].AddAnimal('D',60, 7, 5,true);
			daftar_kandang[i].AddAnimal('E',30,5,7,true);
			i++;
			//Cage 5
			daftar_kandang[i].AddAnimal('G',100,14,4),true;
			daftar_kandang[i].AddAnimal('M',30, 14, 6,true);
			daftar_kandang[i].AddAnimal('Z',10, 16, 4,true);
			daftar_kandang[i].AddAnimal('H',15, 12, 6,true);
			i++;
			//Cage 6
			daftar_kandang[i].AddAnimal('@',70, 18, 8,false);
			daftar_kandang[i].AddAnimal('@',70, 19, 6,false);
			i++;			
			//Cage 7
			daftar_kandang[i].AddAnimal('J',100, 10, 12,true);
			daftar_kandang[i].AddAnimal('U',10, 14, 11,true);
			daftar_kandang[i].AddAnimal('Q',10, 12, 12,true);
			i++;
			//Cage 8
			daftar_kandang[i].AddAnimal('$',150, 5, 19,false);
			daftar_kandang[i].AddAnimal('$',150, 7, 16,false);
			i++;
			//Cage 9
			daftar_kandang[i].AddAnimal('V',100, 11, 18,false);
			daftar_kandang[i].AddAnimal('V',100, 12, 16,false);
			daftar_kandang[i].AddAnimal('V',100, 12, 19,false);
			i++;
			
			int x;
			int y;
			for (int i = 0; i < banyak_kandang; i++) {
				for (int j = 0; j < daftar_kandang[i].GetBanyakHewan(); j++) {
					x = daftar_kandang[i].GetAnimals()[j]->GetKoordinat().GetAbsis();
					y = daftar_kandang[i].GetAnimals()[j]->GetKoordinat().GetOrdinat();
					ready_to_print[x][y] = daftar_kandang[i].GetAnimals()[j]->Render();
				}
			}
		}
	}
	
	Zoo::~Zoo() {
		for (int i=0; i<lebar; i++) {
			delete [] map[i];
		}
		delete [] map;
		delete [] daftar_kandang;
		for (int i=0; i<lebar; i++) {
			delete [] base_map[i];
		}
		delete [] base_map;
	}

void Zoo::Move(){
	srand(time(NULL));
    bool move;
    Indices I;
    int count,x,y,to,tox,toy;
    for (int i=0; i<banyak_kandang; i++) {
        for (int j=0; j<daftar_kandang[i].GetBanyakHewan(); j++) {
            move= false;
            count = 0;
            x = (daftar_kandang[i].GetAnimals()[j])->GetKoordinat().GetAbsis();
            y = (daftar_kandang[i].GetAnimals()[j])->GetKoordinat().GetOrdinat();
            to = (rand() % 3) +1;
            while ((!(move)) && (count<4)){
                tox = x; toy = y;
                count++;
                switch (to)
                {
                    case 1 : {tox++;}; break;
                    case 2 : {toy++;}; break;
                    case 3 : {tox--;}; break;
                    case 4 : {toy--;}; break;
                    
                }
                if ((toy>=0) && (toy<lebar) && (tox >=0) && (tox <panjang)) {
					I.SetOrdinat(toy); I.SetAbsis(tox);
					if (((daftar_kandang[i].GetAnimals()[j])->IsLivable(base_map[toy][tox])) && 
					   (daftar_kandang[i].IsHostOf(I)) &&
					   ((ready_to_print[toy][tox] == 'w') || (ready_to_print[toy][tox] == 'l') || (ready_to_print[toy][tox] == 'a'))) {
						move = true;
						(daftar_kandang[i].GetAnimals()[j])->SetKoordinat(tox, toy);
						ready_to_print[y][x] = base_map[y][x];
						ready_to_print[toy][tox] = (daftar_kandang[i].GetAnimals()[j])->Render();
					} else {
						to = (to%4) + 1;
					}
				} else {
					to = (to%4) + 1;
				}
            }        
        }
    }
}
void Zoo::Print(){
    for(int i=0; i<lebar; i++) {
        for(int j=0; j<panjang; j++) {
            cout<<ready_to_print[i][j] << " ";
        }
        cout<< endl;
    }
}

void Zoo::HitungMakanan(){
    int sayur_buah_dan_biji2an=0;
    int daging=0;
    int i,j;
    for (i = 0; i<banyak_kandang; i++) {
        for (j = 0; j<daftar_kandang[i].GetBanyakHewan(); j++) {
            if (daftar_kandang[i].GetAnimals()[j]->GetMakanan() == 0) {
                sayur_buah_dan_biji2an = sayur_buah_dan_biji2an + (daftar_kandang[i].GetAnimals()[j]->GetBerat() * 3 / 100);
            } else
            if (daftar_kandang[i].GetAnimals()[j]->GetMakanan() == 1) {
                sayur_buah_dan_biji2an = sayur_buah_dan_biji2an + (daftar_kandang[i].GetAnimals()[j]->GetBerat() * 3 / 200);
                daging = daging + (daftar_kandang[i].GetAnimals()[j]->GetBerat() * 3 / 200);
            } else
            if (daftar_kandang[i].GetAnimals()[j].GetMakanan() == 2) {
                daging = daging + (daftar_kandang[i].GetAnimals()[j]->GetBerat() * 3 / 100);
            }
        }
    }
    
    cout << "Butuh daging sebanyak " << daging << "kg." << endl;
    cout << "Butuh sayur, buah, dan biji-bijian sebanyak " << sayur_buah_dan_biji2an << "kg." << endl;
}

Cage* Zoo::GetKandang() {
	return daftar_kandang;
}

bool Zoo::IsInteractable(Indices I, Cage C) {
	bool iya = false;
	int i = 0;
	Indices It;
	It.SetAbsis(I.GetAbsis()+1); It.SetOrdinat(I.GetOrdinat());
	iya = (C.IsHostOf(It));
	if (!iya) {
		It.SetAbsis(I.GetAbsis()-1); It.SetOrdinat(I.GetOrdinat());
		iya = (C.IsHostOf(It));
	}
	if (!iya) {
		It.SetAbsis(I.GetAbsis()); It.SetOrdinat(I.GetOrdinat()+1);
		iya = (C.IsHostOf(It));
	}
	if (!iya) {
		It.SetAbsis(I.GetAbsis()); It.SetOrdinat(I.GetOrdinat()-1);
		iya = (C.IsHostOf(It));
	}
	return iya;
}

