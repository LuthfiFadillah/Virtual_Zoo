#include "Cage.h"
#include "Animals.h"
//#include "Habitat.h"
#include "Indices.h"
#include <iostream>
using namespace std;

	Cage::Cage() {
		
	}
	
	Cage::Cage(Indices *I,int Neff){
		wilayah = new Indices[Neff];
		for (int i=0; i< Neff; i++) {
			wilayah[i] = I[i];
		}
		luas = Neff;
		banyak_hewan = 0;
		data_animals = new void* [(Neff*3)/10];
	}
	
	Cage::~Cage(){
		//delete [] wilayah;
		//delete [] data_animals;
		luas =0;
	}

    Cage& Cage::operator= (const Cage& C){
        int i;
        luas = C.luas;
        banyak_hewan = C.banyak_hewan;
        if (this != &C) {
            //delete [] wilayah;
            wilayah = new Indices[luas];
            for (i=0; i<luas; i++) {
                wilayah[i] = C.wilayah[i];
            }
            //delete [] data_animals;
            data_animals = new Animals* [banyak_hewan];
            for (i=0; i<banyak_hewan; i++) {
                data_animals[i] = C.data_animals[i];
            }
        }
        return *this;
    }

	bool Cage::IsHostOf(Indices I){
		bool ketemu = false;
		int i=0;
		while ((i<luas) && (!(ketemu))) {
			ketemu = (I.IsEqual(wilayah[i]));
			i++; 
		}
		
		return ketemu;
	}
	
	bool Cage::Spacious() {
		return (banyak_hewan <= (luas*3)/10) ;
	}
	
	void Cage::AddAnimal(char c, int bb, int x, int y, bool jinak) {
		Indices I(x,y);
		if (IsHostOf(ind)) {
			if (Spacious()) {
				if (c == 'B') {
					Beluga a*;
					a = new Beluga(bb,x,y);
				} else
				if (c == 'S') {
					BigHornSheep a*;
					a = BigHornSheep(bb,x,y);
				} else
				if (c == 'C') {
					Cassowary* a;
					a = new Cassowary(bb,x,y);
				} else
				if (c == 'H') {
					Chameleon* a;
					a = new Chameleon(bb,x,y);
				} else
				if (c == 'T') {
					Cheetah* a;
					a = Cheetah(bb,x,y);
				} else
				if (c == 'O') {
					Cockatoo* a;
					a = new Cockatoo(bb,x,y);
				} else
				if (c == 'D') {
					Deer* a;
					a = new Deer(bb,x,y);
				} else
				if (c == 'N') {
					Dolphin* a;
					a = new Dolphin(bb,x,y);
				} else
				if (c == 'U') {
					Duck* a;
					a = new Duck(bb,x,y);
				} else
				if (c == 'G') {
					Giraffe* a;
					a = new Giraffe(bb,x,y);
				} else
				if (c == 'J') {
					Gorilla *a;
					a = new Gorilla(bb,x,y);
				} else
				if (c == 'K') {
					GreatWhiteShark *a
					a =  new GreatWhiteShark(bb,x,y);
				} else
				if (c == 'E') {
					Lemur* a;
					a = new Lemur(bb,x,y);
				} else
				if (c == 'I') {
					Lion* a;
					a = new Lion(bb,x,y);
				} else
				if (c == 'M') {
					Meerkat* a;
					a = new Meerkat(bb,x,y);
				} else
				if (c == 'Y') {
					Monkey* a;
					a = new Monkey(bb,x,y);
				} else
				if (c == '$') {
					Orca* a;
					a = new Orca(bb,x,y);
				} else
				if (c == 'Z') {
					Owl* a;
					a = new Owl(bb,x,y);
				} else
				if (c == 'X') {
					Parrots* a;
					a = new Parrots(bb,x,y);
				} else
				if (c == 'V') {
					Python* a;
					a = Python(bb,x,y);
				} else
				if (c == 'Q') {
					Swan* a;
					a = new Swan(bb,x,y);
				} else
				if (c == 'F') {
					Tarsier* a;
					a = new Tarsier(bb,x,y);
				} else
				if (c == '@') {
					Wolf a(bb,x,y);
				} else {
					cout << "typo" << endl;
				}
			} else {
				cout<< "Penuh couyyy" << endl;
			}
		}
	}
	
/* 	void Cage::Inter()  {
		for (int i=0; i<banyak_hewan; i++) {
			data_animals[i]->Interact();
		}
	}
*/
	/*
	bool Cage::IsCageOf(char c) {
		int i = 0;
		bool ketemu = (data_animals[i] == c);
		while (!ketemu && (i<banyak_hewan)) {
			ketemu = (data_animals[i] == c);
			i++;
		}
        return ketemu;
	}
	*/

void* Cage::GetAnimals(){
    return data_animals;
}
int Cage::GetLuas(){
    return luas;
}
int Cage::GetBanyakHewan(){
    return banyak_hewan;
}

bool IsAddable(bool jinak) {
	if (!jinak) {
		if (banyak_hewan == 0) {
			return true;
		} else {
			if (a->Render() == data_animals[0]->Render()) {
				return false;
			} else {
				return false;
			}
		}
	} else {
		return true;
	}
}
