#include <iostream>
using namespace std;

int main () {
	void* t[2];
	t[0] = new int();
	int i = 1;
	t[0] = &i;
	t[1] = new float();
	float f = 2.5;
	t[1] = &f;
	for (int i=0; i<2; i++) {
		cout << &t[i] << " ";
	}
	return 0;
}
