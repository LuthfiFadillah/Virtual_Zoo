#include "Indices.h"
#include "Animals.h"
#include <iostream>
using namespace std;

	Beluga::Beluga(int bb, int x, int y) {
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Beluga::~Beluga(){
		berat_badan = 0;
	}
	int Beluga::GetBerat(){
		return berat_badan;
	}
	Indices Beluga::GetKoordinat(){
		return koordinat;
	}
	void Beluga::SetBerat(int bb){
		berat_badan = bb;
	}
	void Beluga::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Beluga::Interact(){
		cout << "Ooooooooooooo..." << endl;
	}
	bool Beluga::IsLandAnimal(){
		return land_animal;
	}
	bool Beluga::IsWaterAnimal(){
		return water_animal;
	}
	bool Beluga::IsAirAnimal(){
		return air_animal;
	}
	bool Beluga::IsJinak(){
		return jinak;
	}
	char Beluga::Render(){
		return 'B';
	}
	bool Beluga::IsLivable(char c) {
		return (c == 'w');
	}


	BigHornSheep::BigHornSheep(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	BigHornSheep::~BigHornSheep(){
		berat_badan = 0;
	}
	
	int BigHornSheep::GetBerat(){
		return berat_badan;
	}
	Indices BigHornSheep::GetKoordinat(){
		return koordinat;
	}
	void BigHornSheep::SetBerat(int bb){
		berat_badan = bb;
	}
	void BigHornSheep::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void BigHornSheep::Interact(){
		cout<< "Mbeeekkkk" << endl;
	}
	bool BigHornSheep::IsLandAnimal(){
		return land_animal;
	}
	bool BigHornSheep::IsWaterAnimal(){
		return water_animal;
	}
	bool BigHornSheep::IsAirAnimal(){
		return air_animal;
	}
	bool BigHornSheep::IsJinak(){
		return jinak;
	}
	char BigHornSheep::Render(){
		return 'S';
	}
	bool BigHornSheep::IsLivable(char c) {
		return (c == 'l');
	}	
	
	Cassowary::Cassowary(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Cassowary::~Cassowary(){
		berat_badan = 0;
	}
	int Cassowary::GetBerat(){
		return berat_badan;
	}
	Indices Cassowary::GetKoordinat(){
		return koordinat;
	}
	void Cassowary::SetBerat(int bb){
		berat_badan = bb;
	}
	void Cassowary::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Cassowary::Interact(){
		cout << "I can't fly :(" << endl;
	}
	bool Cassowary::IsLandAnimal(){
		return land_animal;
	}
	bool Cassowary::IsWaterAnimal(){
		return water_animal;
	}
	bool Cassowary::IsAirAnimal(){
		return air_animal;
	}
	bool Cassowary::IsJinak(){
		return jinak;
	}
	char Cassowary::Render(){
		return 'C';
	}
	bool Cassowary::IsLivable(char c) {
		return (c == 'l');
	}	
	
	Chameleon::Chameleon(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Chameleon::~Chameleon(){
		berat_badan = 0;
	}
	int Chameleon::GetBerat(){
		return berat_badan;
	}
	Indices Chameleon::GetKoordinat(){
		return koordinat;
	}
	void Chameleon::SetBerat(int bb){
		berat_badan = bb;
	}
	void Chameleon::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Chameleon::Interact(){
		cout << "Smisshy slimi skinny\n";
	}
	bool Chameleon::IsLandAnimal(){
		return land_animal;
	}
	bool Chameleon::IsWaterAnimal(){
		return water_animal;
	}
	bool Chameleon::IsAirAnimal(){
		return air_animal;
	}
	bool Chameleon::IsJinak(){
		return jinak;
	}
	char Chameleon::Render(){
		return 'H';
	}
	bool Chameleon::IsLivable(char c) {
		return (c == 'l');
	}	

	Cheetah::Cheetah(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Cheetah::~Cheetah(){
		berat_badan = 0;
	}
	int Cheetah::GetBerat(){
		return berat_badan;
	}
	Indices Cheetah::GetKoordinat(){
		return koordinat;
	}
	void Cheetah::SetBerat(int bb){
		berat_badan = bb;
	}
	void Cheetah::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Cheetah::Interact(){
		cout << "*runs fast*" << endl;
	}
	bool Cheetah::IsLandAnimal(){
		return land_animal;
	}
	bool Cheetah::IsWaterAnimal(){
		return water_animal;
	}
	bool Cheetah::IsAirAnimal(){
		return air_animal;
	}
	bool Cheetah::IsJinak(){
		return jinak;
	}
	char Cheetah::Render(){
		return 'T';
	}
	bool Cheetah::IsLivable(char c) {
		return (c == 'l');
	}
	
	Cockatoo::Cockatoo(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Cockatoo::~Cockatoo(){
		berat_badan = 0;
	}
	int Cockatoo::GetBerat(){
		return berat_badan;
	}
	Indices Cockatoo::GetKoordinat(){
		return koordinat;
	}
	void Cockatoo::SetBerat(int bb){
		berat_badan = bb;
	}
	void Cockatoo::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Cockatoo::Interact(){
		cout << "Cockatooo... Cockatooo..." << endl;
	}
	bool Cockatoo::IsLandAnimal(){
		return land_animal;
	}
	bool Cockatoo::IsWaterAnimal(){
		return water_animal;
	}
	bool Cockatoo::IsAirAnimal(){
		return air_animal;
	}
	bool Cockatoo::IsJinak(){
		return jinak;
	}
	char Cockatoo::Render(){
		return 'o';
	}
	bool Cockatoo::IsLivable(char c) {
		return (c == 'a');
	}

	Deer::Deer(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Deer::~Deer(){
		berat_badan = 0;
	}
	int Deer::GetBerat(){
		return berat_badan;
	}
	Indices Deer::GetKoordinat(){
		return koordinat;
	}
	void Deer::SetBerat(int bb){
		berat_badan = bb;
	}
	void Deer::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Deer::Interact(){
		cout << "Do you know where is santa house??" << endl;
	}
	bool Deer::IsLandAnimal(){
		return land_animal;
	}
	bool Deer::IsWaterAnimal(){
		return water_animal;
	}
	bool Deer::IsAirAnimal(){
		return air_animal;
	}
	bool Deer::IsJinak(){
		return jinak;
	}
	char Deer::Render(){
		return 'D';
	}
	bool Deer::IsLivable(char c) {
		return (c == 'l');
	}

	Dolphin::Dolphin(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Dolphin::~Dolphin(){
		berat_badan = 0;
	}
	int Dolphin::GetBerat(){
		return berat_badan;
	}
	Indices Dolphin::GetKoordinat(){
		return koordinat;
	}
	void Dolphin::SetBerat(int bb){
		berat_badan = bb;
	}
	void Dolphin::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Dolphin::Interact(){
		cout << "Bermain bola? Makan dulu" << endl;
	}
	bool Dolphin::IsLandAnimal(){
		return land_animal;
	}
	bool Dolphin::IsWaterAnimal(){
		return water_animal;
	}
	bool Dolphin::IsAirAnimal(){
		return air_animal;
	}
	bool Dolphin::IsJinak(){
		return jinak;
	}
	char Dolphin::Render(){
		return 'N';
	}
	bool Dolphin::IsLivable(char c) {
		return (c == 'w');
	}

	Duck::Duck(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Duck::~Duck(){
		berat_badan = 0;
	}
	int Duck::GetBerat(){
		return berat_badan;
	}
	Indices Duck::GetKoordinat(){
		return koordinat;
	}
	void Duck::SetBerat(int bb){
		berat_badan = bb;
	}
	void Duck::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Duck::Interact(){
		cout << "Qwekk Qwekk\n";
	}
	bool Duck::IsLandAnimal(){
		return land_animal;
	}
	bool Duck::IsWaterAnimal(){
		return water_animal;
	}
	bool Duck::IsAirAnimal(){
		return air_animal;
	}
	bool Duck::IsJinak(){
		return jinak;
	}
	char Duck::Render(){
		return 'U';
	}
	bool Duck::IsLivable(char c) {
		return ((c == 'w') || (c == 'l'));
	}

	Giraffe::Giraffe(int bb, int x, int y) {
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Giraffe::~Giraffe() {
		berat_badan = 0;
	}
	int Giraffe::GetBerat() {
		return berat_badan;
	}
	Indices Giraffe::GetKoordinat() {
		return koordinat;
	}
	void Giraffe::SetBerat(int bb) {
		berat_badan = bb;
	}
	void Giraffe::SetKoordinat(int x, int y) {
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Giraffe::Interact() {
		cout<< "where are u? i cant see you! are you down there?? please come up!" << endl;
	}
	bool Giraffe::IsLandAnimal() {
		return land_animal;
	}
	bool Giraffe::IsWaterAnimal() {
		return water_animal;
	}
	bool Giraffe::IsAirAnimal() {
		return air_animal;
	}
	bool Giraffe::IsJinak() {
		return jinak;
	}
	char Giraffe::Render() {
		return 'G';
	}
	bool Giraffe::IsLivable(char c) {
		return (c == 'l');
	}

	Gorilla::Gorilla(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Gorilla::~Gorilla(){
		berat_badan = 0;
	}
	int Gorilla::GetBerat(){
		return berat_badan;
	}
	Indices Gorilla::GetKoordinat(){
		return koordinat;
	}
	void Gorilla::SetBerat(int bb){
		berat_badan = bb;
	}
	void Gorilla::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Gorilla::Interact(){
		cout<<"*thump thump*"<<endl;
	}
	bool Gorilla::IsLandAnimal(){
		return land_animal;
	}
	bool Gorilla::IsWaterAnimal(){
		return water_animal;
	}
	bool Gorilla::IsAirAnimal(){
		return air_animal;
	}
	bool Gorilla::IsJinak(){
		return jinak;
	}
	char Gorilla::Render(){
		return 'J';
	}
	bool Gorilla::IsLivable(char c) {
		return (c == 'l');
	}

	GreatWhiteShark::GreatWhiteShark(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	GreatWhiteShark::~GreatWhiteShark(){
		berat_badan = 0;
	}
	int GreatWhiteShark::GetBerat(){
		return berat_badan;
	}
	Indices GreatWhiteShark::GetKoordinat(){
		return koordinat;
	}
	void GreatWhiteShark::SetBerat(int bb){
		berat_badan = bb;
	}
	void GreatWhiteShark::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void GreatWhiteShark::Interact(){
		cout << "*Big grins* heyyo" << endl;
	}
	bool GreatWhiteShark::IsLandAnimal(){
		return land_animal;
	}
	bool GreatWhiteShark::IsWaterAnimal(){
		return water_animal;
	}
	bool GreatWhiteShark::IsAirAnimal(){
		return air_animal;
	}
	bool GreatWhiteShark::IsJinak(){
		return jinak;
	}
	char GreatWhiteShark::Render(){
		return 'K';
	}
	bool GreatWhiteShark::IsLivable(char c) {
		return (c == 'w');
	}

	Lemur::Lemur(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Lemur::~Lemur(){
		berat_badan = 0;
	}
	int Lemur::GetBerat(){
		return berat_badan;
	}
	Indices Lemur::GetKoordinat(){
		return koordinat;
	}
	void Lemur::SetBerat(int bb){
		berat_badan = bb;
	}
	void Lemur::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Lemur::Interact(){
		cout<<"*chirps*"<<endl;
	}
	bool Lemur::IsLandAnimal(){
		return land_animal;
	}
	bool Lemur::IsWaterAnimal(){
		return water_animal;
	}
	bool Lemur::IsAirAnimal(){
		return air_animal;
	}
	bool Lemur::IsJinak(){
		return jinak;
	}
	char Lemur::Render(){
		return 'E';
	}
	bool Lemur::IsLivable(char c) {
		return (c == 'l');
	}

	Lion::Lion(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Lion::~Lion(){
		berat_badan = 0;
	}
	int Lion::GetBerat(){
		return berat_badan;
	}
	Indices Lion::GetKoordinat(){
		return koordinat;
	}
	void Lion::SetBerat(int bb){
		berat_badan = bb;
	}
	void Lion::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Lion::Interact(){
		cout << "ROAR" << endl;
	}
	bool Lion::IsLandAnimal(){
		return land_animal;
	}
	bool Lion::IsWaterAnimal(){
		return water_animal;
	}
	bool Lion::IsAirAnimal(){
		return air_animal;
	}
	bool Lion::IsJinak(){
		return jinak;
	}
	char Lion::Render(){
		return 'L';
	}
	bool Lion::IsLivable(char c) {
		return (c == 'l');
	}

	Meerkat::Meerkat(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Meerkat::~Meerkat(){
		berat_badan = 0;
	}
	int Meerkat::GetBerat(){
		return berat_badan;
	}
	Indices Meerkat::GetKoordinat(){
		return koordinat;
	}
	void Meerkat::SetBerat(int bb){
		berat_badan = bb;
	}
	void Meerkat::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Meerkat::Interact(){
		cout << "*suddenly standing*" << endl;
	}
	bool Meerkat::IsLandAnimal(){
		return land_animal;
	}
	bool Meerkat::IsWaterAnimal(){
		return water_animal;
	}
	bool Meerkat::IsAirAnimal(){
		return air_animal;
	}
	bool Meerkat::IsJinak(){
		return jinak;
	}
	char Meerkat::Render(){
		return 'M';
	}
	bool Meerkat::IsLivable(char c) {
		return (c == 'l');
	}

	Monkey::Monkey(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Monkey::~Monkey(){
		berat_badan = 0;
	}
	int Monkey::GetBerat(){
		return berat_badan;
	}
	Indices Monkey::GetKoordinat(){
		return koordinat;
	}
	void Monkey::SetBerat(int bb){
		berat_badan = bb;
	}
	void Monkey::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Monkey::Interact(){
		cout<<"uuuk aaak aaak"<<endl;
	}
	bool Monkey::IsLandAnimal(){
		return land_animal;
	}
	bool Monkey::IsWaterAnimal(){
		return water_animal;
	}
	bool Monkey::IsAirAnimal(){
		return air_animal;
	}
	bool Monkey::IsJinak(){
		return jinak;
	}
	char Monkey::Render(){
		return 'Y';
	}
	bool Monkey::IsLivable(char c) {
		return (c == 'l');
	}

	Orca::Orca(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Orca::~Orca(){
		berat_badan = 0;
	}
	int Orca::GetBerat(){
		return berat_badan;
	}
	Indices Orca::GetKoordinat(){
		return koordinat;
	}
	void Orca::SetBerat(int bb){
		berat_badan = bb;
	}
	void Orca::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Orca::Interact(){
		cout << "*WWUSHHHO" << endl;
	}
	bool Orca::IsLandAnimal(){
		return land_animal;
	}
	bool Orca::IsWaterAnimal(){
		return water_animal;
	}
	bool Orca::IsAirAnimal(){
		return air_animal;
	}
	bool Orca::IsJinak(){
		return jinak;
	}
	char Orca::Render(){
		return '$';
	}
	bool Orca::IsLivable(char c) {
		return (c == 'w');
	}

	Owl::Owl(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Owl::~Owl(){
		berat_badan = 0;
	}
	int Owl::GetBerat(){
		return berat_badan;
	}
	Indices Owl::GetKoordinat(){
		return koordinat;
	}
	void Owl::SetBerat(int bb){
		berat_badan = bb;
	}
	void Owl::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Owl::Interact(){
		cout << "Coccooo Coccooo" << endl;
	}
	bool Owl::IsLandAnimal(){
		return land_animal;
	}
	bool Owl::IsWaterAnimal(){
		return water_animal;
	}
	bool Owl::IsAirAnimal(){
		return air_animal;
	}
	bool Owl::IsJinak(){
		return jinak;
	}
	char Owl::Render(){
		return 'Z';
	}
	bool Owl::IsLivable(char c) {
		return (c == 'a');
	}

	Parrots::Parrots(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Parrots::~Parrots(){
		berat_badan = 0;
	}
	int Parrots::GetBerat(){
		return berat_badan;
	}
	Indices Parrots::GetKoordinat(){
		return koordinat;
	}
	void Parrots::SetBerat(int bb){
		berat_badan = bb;
	}
	void Parrots::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Parrots::Interact(){
		cout << "Annyeong.." << endl;
	}
	bool Parrots::IsLandAnimal(){
		return land_animal;
	}
	bool Parrots::IsWaterAnimal(){
		return water_animal;
	}
	bool Parrots::IsAirAnimal(){
		return air_animal;
	}
	bool Parrots::IsJinak(){
		return jinak;
	}
	char Parrots::Render(){
		return 'X';
	}
	bool Parrots::IsLivable(char c) {
		return (c == 'a');
	}

	Python::Python(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Python::~Python(){
		berat_badan = 0;
	}
	int Python::GetBerat(){
		return berat_badan;
	}
	Indices Python::GetKoordinat(){
		return koordinat;
	}
	void Python::SetBerat(int bb){
		berat_badan = bb;
	}
	void Python::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Python::Interact(){
		cout << "Ssshhh\n";
	}
	bool Python::IsLandAnimal(){
		return land_animal;
	}
	bool Python::IsWaterAnimal(){
		return water_animal;
	}
	bool Python::IsAirAnimal(){
		return air_animal;
	}
	bool Python::IsJinak(){
		return jinak;
	}
	char Python::Render(){
		return 'V';
	}
	bool Python::IsLivable(char c) {
		return (c == 'l');
	}

	Swan::Swan(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Swan::~Swan(){
		berat_badan = 0;
	}
	int Swan::GetBerat(){
		return berat_badan;
	}
	Indices Swan::GetKoordinat(){
		return koordinat;
	}
	void Swan::SetBerat(int bb){
		berat_badan = bb;
	}
	void Swan::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Swan::Interact(){
		cout << "Qwokk Qwokk\n";
	}
	bool Swan::IsLandAnimal(){
		return land_animal;
	}
	bool Swan::IsWaterAnimal(){
		return water_animal;
	}
	bool Swan::IsAirAnimal(){
		return air_animal;
	}
	bool Swan::IsJinak(){
		return jinak;
	}
	char Swan::Render(){
		return 'Q';
	}
	bool Swan::IsLivable(char c) {
		return (c == 'l');
	}

	Tarsier::Tarsier(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Tarsier::~Tarsier(){
		berat_badan = 0;
	}
	int Tarsier::GetBerat(){
		return berat_badan;
	}
	Indices Tarsier::GetKoordinat(){
		return koordinat;
	}
	void Tarsier::SetBerat(int bb){
		berat_badan = bb;
	}
	void Tarsier::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Tarsier::Interact(){
		cout<<"*googly eyes*"<<endl;
	}
	bool Tarsier::IsLandAnimal(){
		return land_animal;
	}
	bool Tarsier::IsWaterAnimal(){
		return water_animal;
	}
	bool Tarsier::IsAirAnimal(){
		return air_animal;
	}
	bool Tarsier::IsJinak(){
		return jinak;
	}
	char Tarsier::Render(){
		return 'F';
	}
	bool Tarsier::IsLivable(char c) {
		return (c == 'l');
	}

	Wolf::Wolf(int bb, int x, int y){
		berat_badan = bb;
		Indices I(x,y);
		koordinat = I;
	}
	Wolf::~Wolf(){
		berat_badan = 0;
	}
	int Wolf::GetBerat(){
		return berat_badan;
	}
	Indices Wolf::GetKoordinat(){
		return koordinat;
	}
	void Wolf::SetBerat(int bb){
		berat_badan = bb;
	}
	void Wolf::SetKoordinat(int x, int y){
		koordinat.SetAbsis(x);
		koordinat.SetOrdinat(y);
	}
	void Wolf::Interact(){
		cout << "AUUUUUUU" << endl;
	}
	bool Wolf::IsLandAnimal(){
		return land_animal;
	}
	bool Wolf::IsWaterAnimal(){
		return water_animal;
	}
	bool Wolf::IsAirAnimal(){
		return air_animal;
	}
	bool Wolf::IsJinak(){
		return jinak;
	}
	char Wolf::Render(){
		return '@';
	}
	bool Wolf::IsLivable(char c) {
		return (c == 'l');
	}
