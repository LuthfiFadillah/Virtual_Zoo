#include "Animal.h"
#include "Indices.h"
#include <string>
#include <iostream>
using namespace std;

Animal::Animal() {}
Animal::Animal(char c, int bb, int x, int y, int makan, bool land, bool water, bool air, bool kejinakan) {
    code = c;
    makanan = makan;
    land_animal = land;
    water_animal = water;
    air_animal = air;
    jinak = kejinakan;
    berat_badan = bb;
    Indices I(x,y);
    koordinat = I;
}
Animal::~Animal() {
    berat_badan = 0;
}
Animal& Animal::operator= (Animal& A){
    code = A.code;
    berat_badan = A.berat_badan;
    koordinat = A.koordinat;
    makanan = A.makanan;
    land_animal = A.land_animal;
    water_animal = A.water_animal;
    air_animal = A.air_animal;
    jinak = A.jinak;
    
    return *this;
}
int Animal::GetBerat(){
    return berat_badan;
}
Indices Animal::GetKoordinat(){
    return koordinat;
}
int Animal::GetMakanan(){
    return makanan;
}
void Animal::SetBerat(int bb){
    berat_badan = bb;
}
void Animal::SetKoordinat(int x, int y){
    koordinat.SetAbsis(x);
    koordinat.SetOrdinat(y);
}
void Animal::Interact(){
    if (code == 'B') {
        cout << "OOoooooooooooo" << endl;
    } else if (code == 'S') {
        cout<< "Mbeeekkkk" << endl;
    } else if (code == 'C') {
        cout<< "I can't fly :("  << endl;
    } else if (code == 'H') {
        cout<< "Smisshy slimi skinny" << endl;
    } else if (code == 'T') {
        cout<< "*runs fast*" << endl;
    } else if (code == 'O') {
        cout<< "Cockatooo... Cockatooo..." << endl;
    } else if (code == 'D') {
        cout<< "Do you know where is santa house??"  << endl;
    } else if (code == 'N') {
        cout<< "Bermain bola? Makan dulu" << endl;
    } else if (code == 'U') {
        cout<< "Qwekk Qwekk" << endl;
    } else if (code == 'G') {
        cout<< "where are u? i cant see you! are you down there?? please come up!" << endl;
    } else if (code == 'J') {
        cout<< "*thump thump*" << endl;
    } else if (code == 'K') {
        cout<< "*Big grins* heyyo"<< endl;
    } else if (code == 'E') {
        cout<< "*chirps*" << endl;
    } else if (code == 'I') {
        cout<< "ROAR" << endl;
    } else if (code == 'M') {
        cout<< "*suddenly standing*" << endl;
    } else if (code == 'Y') {
        cout<< "uuuk aaak aaak" << endl;
    } else if (code == '$') {
        cout<< "*WWUSHHHO" << endl;
    } else if (code == 'Z') {
        cout<< "Coccooo Coccooo" << endl;
    } else if (code == 'X') {
        cout<< "Annyeong.." << endl;
    } else if (code == 'V') {
        cout<< "Sssshhh" << endl;
    } else if (code == 'Q') {
        cout<< "Qwokk Qwokk" << endl;
    } else if (code == 'F') {
        cout<< "*googly eyes*" << endl;
    } else if (code == '@') {
        cout<< "AUUUUUUU" << endl;
    }

}
    
bool Animal::IsLandAnimal(){
    return land_animal;
}
bool Animal::IsWaterAnimal(){
    return water_animal;
}
bool Animal::IsAirAnimal(){
    return air_animal;
}
bool Animal::IsJinak(){
    return jinak;
}
char Animal::Render(){
    return code;
 /*   if (strcmp(name,"beluga")) {
        render = 'B';
    } else if (strcmp(name,"big horn sheep")) {
        render = 'S';
    } else if (strcmp(name,"cassowary")) {
        render = 'C';
    } else if (strcmp(name,"chameleon")) {
        render = 'H';
    } else if (strcmp(name,"cheetah")) {
        render = 'T';
    } else if (strcmp(name,"cockatoo")) {
        render = 'O';
    } else if (strcmp(name,"deer")) {
        render = 'D';
    } else if (strcmp(name,"dolphin")) {
        render = 'N';
    } else if (strcmp(name,"duck")) {
        render = 'U';
    } else if (strcmp(name,"giraffe")) {
        render = 'G';
    } else if (strcmp(name,"gorilla")) {
        render = 'J';
    } else if (strcmp(name,"great white shark")) {
        render = 'K';
    } else if (strcmp(name,"lemur")) {
        render = 'E';
    } else if (strcmp(name,"lion")) {
        render = 'I';
    } else if (strcmp(name,"meerkat")) {
        render = 'M';
    } else if (strcmp(name,"monkey")) {
        render = 'Y';
    } else if (strcmp(name,"orca")) {
        render = '$';
    } else if (strcmp(name,"owl")) {
        render = 'Z';
    } else if (strcmp(name,"parrots")) {
        render = 'X';
    } else if (strcmp(name,"python")) {
        render = 'V';
    } else if (strcmp(name,"swan")) {
        render = 'Q';
    } else if (strcmp(name,"tarsier")) {
        render = 'F';
    } else if (strcmp(name,"wolf")) {
        render = '@';
    }*/
}

bool Animal::IsLivable(char c){
    bool bisa;
    if (code == 'B') {
        bisa = (c == 'w');
    } else if (code == 'S') {
        bisa = (c == 'l');
    } else if (code == 'C') {
        bisa = (c == 'l');
    } else if (code == 'H') {
        bisa = (c == 'l');
    } else if (code == 'T') {
        bisa = (c == 'l');
    } else if (code == 'O') {
        bisa = (c == 'a');
    } else if (code == 'D') {
        bisa = (c == 'l');
    } else if (code == 'N') {
        bisa = (c == 'w');
    } else if (code == 'U') {
        bisa = ((c == 'l') || (c == 'a'));
    } else if (code == 'G') {
        bisa = (c == 'l');
    } else if (code == 'J') {
        bisa = (c == 'l');
    } else if (code == 'K') {
        bisa = (c == 'w');
    } else if (code == 'E') {
        bisa = (c == 'l');
    } else if (code == 'I') {
        bisa = (c == 'l');
    } else if (code == 'M') {
        bisa = (c == 'l');
    } else if (code == 'Y') {
        bisa = (c == 'l');
    } else if (code == '$') {
        bisa = (c == 'w');
    } else if (code == 'Z') {
        bisa = (c == 'a');
    } else if (code == 'X') {
        bisa = (c == 'a');
    } else if (code == 'V') {
        bisa = (c == 'l');
    } else if (code == 'Q') {
        bisa = ((c == 'l') || (c == 'a'));
    } else if (code == 'F') {
        bisa = (c == 'l');
    } else if (code == '@') {
        bisa = (c == 'l');
    }
    
    return bisa;
}

