//
//  Cage.cpp
//  vz02
//
//  Created by Alivia Dewi Parahita on 3/14/17.
//  Copyright © 2017 Alivia Dewi Parahita. All rights reserved.
//

#include "Cage.h"
#include <iostream>
using namespace std;

Cage::Cage(){}
Cage::Cage(Indices *I, int Neff){
    wilayah = new Indices[Neff];
    for (int i=0; i< Neff; i++) {
        wilayah[i] = I[i];
    }
    luas = Neff;
    banyak_hewan = 0;
    data_animal = new Animal [(Neff*3)/10];
}
Cage& Cage::operator= (const Cage& C){
    int i;
    luas = C.luas;
    banyak_hewan = C.banyak_hewan;
    if (this != &C) {
        //delete [] wilayah;
        wilayah = new Indices[luas];
        for (i=0; i<luas; i++) {
            wilayah[i] = C.wilayah[i];
        }
        //delete [] data_animals;
        data_animal = new Animal [banyak_hewan];
        for (i=0; i<banyak_hewan; i++) {
            data_animal[i] = C.data_animal[i];
        }
    }
    return *this;
}

Cage::~Cage(){
    luas = 0;
}
bool Cage::IsHostOf(Indices I){
    bool ketemu = false;
    int i=0;
    
    while ((i<luas) && (!(ketemu))) {
        ketemu = (I.IsEqual(wilayah[i]));
        i++;
    }
    
    return ketemu;
}
bool Cage::Spacious(){
    return (banyak_hewan <= (luas*3)/10) ;
}
void Cage::AddAnimal(Animal A){
    Indices I(A.GetKoordinat().GetAbsis(), A.GetKoordinat().GetOrdinat());
    if (IsHostOf(I)) {
        if (Spacious()) {
            if (!(A.IsJinak())) {
                if (banyak_hewan == 0) {
                    data_animal[banyak_hewan] = A;
                    banyak_hewan++;
                } else {
                    if (A.GetBerat() == data_animal[0].GetBerat()) {
                        data_animal[banyak_hewan] = A;
                        banyak_hewan++;
                    }
                }
            } else {
                data_animal[banyak_hewan] = A;
                banyak_hewan++;
            }
        } else {
            cout<< "Penuh couyyy" << endl;
        }
    }
}
void Cage::Inter(){
    for (int i=0; i<banyak_hewan; i++) {
        data_animal[i].Interact();
    }
}
Animal* Cage::GetAnimals(){
    return data_animal;
}
int Cage::GetLuas(){
    return luas;
}
int Cage::GetBanyakHewan(){
    return banyak_hewan;
}
