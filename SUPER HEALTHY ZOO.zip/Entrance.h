#ifndef ENTRANCE_H
#define ENTRANCE_H
#include "Cell.h"
#include "Facility.h"
#include "Road.h"

class Entrance:public Road{
public:

protected:

};
#endif
