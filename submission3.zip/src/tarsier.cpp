#include "tarsier.h"
#include <iostream>
using namespace std;
  /** @brief Constructor dari Tarsier
    * Menghidupkan hewan Tarsier
    *
    * @param x integer adalah letak absis Tarsier yang dihidupkan
    * @param y integer adalah letak ordinat Tarsier yang dihidupkan
    * @param bb integer adalah berat badan Tarsier yang dihidupkan
    */
  Tarsier::Tarsier(int bb, int x, int y) : Primates(true, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Tarsier
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Tarsier ke layar
    */
  void Tarsier::Interact() {
    cout << "*googly eyes*" << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Tarsier
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Tarsier::Render() {
    return 'F';
  }