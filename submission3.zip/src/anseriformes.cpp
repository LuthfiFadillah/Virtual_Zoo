#include "anseriformes.h"

  /** @brief Constructor dari Anseriformes
    * Menghidupkan hewan Ordo Anseriformes
    *
    * @param x integer adalah letak absis Anseriformes yang dihidupkan
    * @param y integer adalah letak ordinat Anseriformes yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Anseriformes::Anseriformes(bool kejinakan, int x, int y) :
                             Animals(1, true, true, false,kejinakan, x,y) {}