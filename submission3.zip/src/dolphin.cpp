#include "dolphin.h"
#include <iostream>
using namespace std;
  
  /** @brief Constructor dari Dolphin
    * Menghidupkan hewan Dolphin
    *
    * @param x integer adalah letak absis Dolphin yang dihidupkan
    * @param y integer adalah letak ordinat Dolphin yang dihidupkan
    * @param bb integer adalah berat badan Dolphin yang dihidupkan
    */
  Dolphin::Dolphin(int bb, int x, int y): Cetacea(true, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Dolphin
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Dolphin ke layar
    */
  void Dolphin::Interact() {
    cout << "Bermain bola? Makan dulu" << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Dolphin
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Dolphin::Render() {
    return 'N';
  }