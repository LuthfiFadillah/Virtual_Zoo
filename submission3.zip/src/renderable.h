#ifndef RENDERABLE_H
#define RENDERABLE_H
class Renderable {
public:
  /** @brief Constructor Renderable dengan jenisnya
    */
  Renderable(int t);
  /** @brief virtual method Render untuk mengembalikan kode renderable
    */
  virtual char Render() = 0;
  /** @brief Mengembalikan bool apakah suatu objek Renderable merupakan Cell
    */
  bool IsCell();
  /** @brief Mengembalikan bool apakah suatu objek Renderable merupakan Animal
    */
  bool IsAnimal();
 private:
   /** @brief Atribut ty adalah tipe dari sebuah objek Renderable
     */
  const int ty;
};
#endif