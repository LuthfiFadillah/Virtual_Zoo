#include "land_habitat.h"
  
  /** @brief Mengembalikan nilai character kode dari objek Land Habitat
    * Character ini nantinya yang siap di Print ke layar
    */
  LandHabitat::LandHabitat(Indices ind) : Habitat(ind, 0, 'l') {}
  char LandHabitat::Render(){
    return 'l';
  }