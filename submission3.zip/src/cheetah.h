#ifndef CHEETAH_H
#define CHEETAH_H
#include "carnivora.h"
class Cheetah : public Carnivora {
public:
  /** @brief Constructor dari Cheetah
    * Menghidupkan hewan Cheetah
    *
    * @param x integer adalah letak absis Cheetah yang dihidupkan
    * @param y integer adalah letak ordinat Cheetah yang dihidupkan
    * @param bb integer adalah berat badan Cheetah yang dihidupkan
    */
  Cheetah(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Cheetah
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Cheetah ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Cheetah
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif