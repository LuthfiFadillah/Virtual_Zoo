#ifndef SWAN_H
#define SWAN_H
#include "anseriformes.h"
class Swan : public Anseriformes {
public:
  /** @brief Constructor dari Swan
    * Menghidupkan hewan Swan
    *
    * @param x integer adalah letak absis Swan yang dihidupkan
    * @param y integer adalah letak ordinat Swan yang dihidupkan
    * @param bb integer adalah berat badan Swan yang dihidupkan
    */
  Swan(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Swan
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Swan ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Swan
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif