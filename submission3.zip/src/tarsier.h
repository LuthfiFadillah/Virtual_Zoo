#ifndef TARSIER_H
#define TARSIER_H
#include "primates.h"
class Tarsier : public Primates {
public:
  /** @brief Constructor dari Tarsier
    * Menghidupkan hewan Tarsier
    *
    * @param x integer adalah letak absis Tarsier yang dihidupkan
    * @param y integer adalah letak ordinat Tarsier yang dihidupkan
    * @param bb integer adalah berat badan Tarsier yang dihidupkan
    */	
  Tarsier(int bb, int x, int y);
  /** @brief prosedur Interact dari objek Tarsier
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Tarsier ke layar
    */
  void Interact();
  /** @brief Mengembalikan nilai character kode dari objek Tarsier
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Render();
};
#endif