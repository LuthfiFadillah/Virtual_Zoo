#include "cassowary.h"
#include <iostream>
using namespace std;

  /** @brief Constructor dari Cassowary
    * Menghidupkan hewan Cassowary
    *
    * @param x integer adalah letak absis Cassowary yang dihidupkan
    * @param y integer adalah letak ordinat Cassowary yang dihidupkan
    * @param bb integer adalah berat badan Cassowary yang dihidupkan
    */
  Cassowary::Cassowary(int bb, int x, int y): Casuariformes(true, x, y) {
    Cassowary::SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Cassowary
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Cassowary ke layar
    */
  void Cassowary::Interact() {
    cout << "I can't fly :(" << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Cassowary
    * Character ini nantinya yang siap di Print ke layar
    */
  char Cassowary::Render() {
    return 'C';
  }