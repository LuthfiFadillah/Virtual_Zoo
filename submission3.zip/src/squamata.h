#ifndef SQUAMATA_H
#define SQUAMATA_H
#include "animals.h"
class Squamata : public Animals {
public:
  /** @brief Constructor dari Squamata
    * Menghidupkan hewan Ordo Squamata
    *
    * @param x integer adalah letak absis Squamata yang dihidupkan
    * @param y integer adalah letak ordinat Squamata yang dihidupkan
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    */
  Squamata(bool kejinakan, int x, int y);
};
#endif