#include "swan.h"
#include <iostream>
using namespace std;
  /** @brief Constructor dari Swan
    * Menghidupkan hewan Swan
    *
    * @param x integer adalah letak absis Swan yang dihidupkan
    * @param y integer adalah letak ordinat Swan yang dihidupkan
    * @param bb integer adalah berat badan Swan yang dihidupkan
    */
  Swan::Swan(int bb, int x, int y) : Anseriformes(true, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Swan
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Swan ke layar
    */
  void Swan::Interact() {
    cout << "Qwokk Qwokk\n" << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Swan
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Swan::Render() {
    return 'Q';
  }