#ifndef INDICES_H
#define INDICES_H
class Indices {
public:
  /** @brief Constructor tanpa parameter dari Indices
    * Menghidupkan indeks
    */
  Indices();
  /** @brief Constructor dengan parameter dari Indices
    * Menghidupkan indeks sesuai parameter
    *
    * @param x integer adalah absis yang akan di set
    * @param y integer adalah ordinat yang akan di set
    */
  Indices(int absis, int ordinat);
  /** @brief Copy Constructor dari Indices
    * Menghidupkan indeks dengan atribut yang sama seperti indeks yang lain
    */
  Indices(Indices&);
  /** @brief Destructor dari Indices
    * Mengembalikan alokasi memori Indices ke sistem
    */
  ~Indices();
  /** @brief Operator overloading = dari Indices
    * Memastikan bukan bitewise copy
    *
    * @param I menyatakan Indices yang ingin disalin
    */
  Indices& operator= (Indices& ind);
  /** @brief GetAbsis dari Indices
    * Mengembalikan nilai absis dari indeks
    *
    */
  int GetAbsis();
  /** @brief GetOrdinat dari Indices
    * Mengembalikan nilai ordinat dari indeks
    *
    */
  int GetOrdinat();
  /** @brief Prosedur SetAbsis dari Indices
    * I.S Indices sudah hidup dan masukan terdefinisi
    * F.S Absis indices nilai menjadi masukan
    *
    * @param x integer adalah nilai absis yang akan di set
    */
  void SetAbsis(int x);
  /** @brief Prosedur SetOrdinat dari Indices
    * I.S Indices sudah hidup dan masukan terdefinisi
    * F.S Ordinat indices nilai menjadi masukan
    *
    * @param y integer adalah nilai ordinat yang akan di set
    */
  void SetOrdinat(int y);
  /** @brief Mengembalikan nilai boolean apakah Indices masukan sama dengan current objek
    *
    * @param I Indices yang ingin dibandingkan dengan current objek
    */
  bool IsEqual(const Indices& ind);
protected:
  /** @brief Attribut x adalah nilai absis indeks
    */
  int x;
  /** @brief Attribut y adalah nilai ordinat indeks
    */
  int y;
};
#endif