#include "lion.h"
#include <iostream>
using namespace std;
  /** @brief Constructor dari Lion
    * Menghidupkan hewan Lion
    *
    * @param x integer adalah letak absis Lion yang dihidupkan
    * @param y integer adalah letak ordinat Lion yang dihidupkan
    * @param bb integer adalah berat badan Lion yang dihidupkan
    */
  Lion::Lion(int bb, int x, int y) : Carnivora (false, x, y) {
    SetBerat(bb);
  }
  /** @brief prosedur Interact dari objek Lion
    * I.S hewan telah dihidupkan
    * F.S interaksi hewan tercetak ke layar
    * Mencetak interaksi Lion ke layar
    */
  void Lion::Interact() {
    cout << "ROAR" << endl;
  }
  /** @brief Mengembalikan nilai character kode dari objek Lion
    * Character ini nantinya yang siap dicetak ke layar
    */
  char Lion::Render() {
    return 'I';
  }