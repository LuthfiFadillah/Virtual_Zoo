#include "animals.h"
#include <iostream>
using namespace std;
  /** @brief Constructor dari Hewan
    * Menghidupkan hewan
    *
    * @param makan integer adalah kode jenis makanan hewan dimana Herbivore=0, Omnivore=1, Carnivore=2
    * @param land bool menyatakan apakah hewan dapat hidup di darat
    * @param water bool menyatakan apakah hewan dapat hidup di air
    * @param air bool menyatakan apakah hewan dapat hidup di udara
    * @param kejinakan bool menyatakan jinak tidaknya hewan
    * @param x integer adalah letak absis hewan yang dihidupk
    * @param y integer adalah letak ordinat hewan yang dihidupkan
    */
  Animals::Animals(int makan, bool land, bool water, bool air, bool kejinakan,
                 int x, int y): Renderable(1), makanan(makan),
                 land_animal(land), water_animal(water), air_animal(air),
                 jinak(kejinakan) {
    Indices ind(x, y);
    koordinat = ind;
  }
  /** @brief Destructor dari Animals
    * Menghilangkan alokasi memori Animals
    */
  Animals::~Animals() {
    SetBerat(0);
  }
  /** @brief GetBerat dari hewan
    * Mengembalikan nilai integer berat dari hewan
    */
  int Animals::GetBerat() {
    return berat_badan;
  }
  /** @brief Prosedur SetBerat  dari hewan
    * I.S bb adalah berat badan yang valid yaitu lebih dari 0
    * F.S atribut berat badan hewan diubah menjadi bb
    * Merubah nilai berat dari hewan
    *
    * @param bb integer menyatakan input berat badan yang ingin di set
    */
  void Animals::SetBerat(int bb) {
    berat_badan = bb;
  }
  /** @brief GetKoordinat dari hewan
    * Mengembalikan nilai Indices ordinat hewan
    */
  Indices Animals::GetKoordinat() {
    return koordinat;
  }
  /** @brief Prosedur SetKoordinat  dari hewan
    * I.S x dan y adalah koordinat yang valid pada zoo
    * F.S atribut koordinat hewan memiliki absis x dan ordinat y
    * Merubah nilai Koordinat dari hewan
    *
    * @param x integer menyatakan absis yang ingin di set
    * @param y integer menyatakan ordinat yang ingin di set
    */
  void Animals::SetKoordinat(int x, int y) {
    koordinat.SetAbsis(x);
    koordinat.SetOrdinat(y);
  }
  /** @brief Mengembalikan nilai boolean apakah hewan dapat hidup di Land
    */
  bool Animals::IsLandAnimal() {
    return land_animal;
  }
  /** @brief Mengembalikan nilai boolean apakah hewan dapat hidup di Water
    */
  bool Animals::IsWaterAnimal() {
    return water_animal;
  }
  /** @brief Mengembalikan nilai boolean apakah hewan dapat hidup di Air
    */ 
  bool Animals::IsAirAnimal() {
    return air_animal;
  }
  /** @brief Mengembalikan nilai boolean apakah hewan jinak
    */
  bool Animals::IsJinak() {
    return jinak;
  }
  /** @brief Mengembalikan nilai boolean apakah hewan dapat tinggal pada Cell C
    * 
    * @param C Cell yang dicek untuk hewan dapat tinggal atau tidak
    */
  bool Animals::IsLivable(Cell c) {
    return (( ((c.GetCode() == 'l') && IsLandAnimal()) ||
           ((c.GetCode() == 'w') && IsWaterAnimal()) || ((c.GetCode() == 'a') &&
           IsAirAnimal()) ));
  }
  /** @brief Mengembalikan nilai integer keterangan makanan hewan
    */
  int Animals::GetMakanan() {
    return makanan;
  }