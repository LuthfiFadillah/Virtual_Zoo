//file Cell.h
#ifndef CELL_H
#define CELL_H
#include "Renderable.h"
#include "Indices.h"

class Cell: public Renderable {
public:
	Cell(Indices I, int t, char c);
	//Cell(Cell& C);
	~Cell();
	//Cell& operator= (Cell& C);
	char Render();
	Indices GetKoordinat();
	bool IsHabitat();
	bool IsFacility();
	char GetCode();
	
protected:
	Indices koordinat;
	const int type; //0 = Habitat, 1 = Facility
	const char code; // '
};

#endif
