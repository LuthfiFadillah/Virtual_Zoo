#include "Psittaciformes.h"
#include "Animals.h"
#include "Indices.h"


Psittaciformes::Psittaciformes(bool kejinakan, int x, int y) : Animals(1,false,false,true, kejinakan ,x,y) {}

//void move(bool water_habitat, bool land_habitat, bool air_habitat, point animal_koordinat, map);

