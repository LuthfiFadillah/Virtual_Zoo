#include "Zoo.h"
#include <iostream>
using namespace std;

int main() {
	/*try {
		Zoo Z;
	}
	catch (const std::bad_alloc&) {
		return -1;
	}*/
	Zoo Z;
    
    Z.Print();
    Z.Move();
    cout<<endl;
    Z.Print();
    
    Z.Move();
    cout<<endl;
    Z.Print();
    
    Z.Move();
    cout<<endl;
    Z.Print();
    
    Z.Move();
    cout<<endl;
    Z.Print();
    
    Z.HitungMakanan();
    
    Indices I(4,0);
    if (Z.IsInteractable(I, Z.GetKandang()[0])) {
		cout << "Yeay.." << endl;
	}
	if (!Z.IsInteractable(I, Z.GetKandang()[8])) {
		cout << "Yeay..again" << endl;
	}
    
	return 0;
}
