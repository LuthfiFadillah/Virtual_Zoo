#include "Python.h"
#include <iostream>
#include "Indices.h"
using namespace std;
//class Python: public Squamata{

	//ctor with param
	Python::Python(int bb, int x, int y) : Squamata(false,x,y) {
		SetBerat(bb);
	}
	
	//polymorphism interaksi
	void Python::Interact() {
		cout << "Ssshhh\n";
	}

	char Python::Render() {
		return 'V';
	}
